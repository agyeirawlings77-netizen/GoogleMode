# AndroidManifest Permissions

## Required Permissions
| Permission | Reason |
|---|---|
| INTERNET | All network operations |
| CAMERA | QR code scanning |
| RECORD_AUDIO | Voice calls |
| FOREGROUND_SERVICE | Background screen sharing |
| FOREGROUND_SERVICE_MEDIA_PROJECTION | Screen capture |
| ACCESS_FINE_LOCATION | GPS tracking |
| ACCESS_COARSE_LOCATION | Network location |
| VIBRATE | Alarm and notifications |
| WAKE_LOCK | Keep screen sharing active |
| READ/WRITE_EXTERNAL_STORAGE | File transfers |
| POST_NOTIFICATIONS | Android 13+ push notifications |

## Special Permissions (request at runtime)
- `MEDIA_PROJECTION` — Screen recording (via system dialog)
- `ACCESSIBILITY_SERVICE` — Remote control via gestures
- `BIND_ACCESSIBILITY_SERVICE` — Required for AccessibilityService
