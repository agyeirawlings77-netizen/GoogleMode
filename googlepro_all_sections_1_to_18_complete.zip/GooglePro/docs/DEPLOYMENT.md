# Deployment Guide

## Backend (Render.com)
1. Push backend/ to GitHub
2. Create new "Web Service" on render.com
3. Build command: `npm install`
4. Start command: `node src/index.js`
5. Environment variable: `FIREBASE_SERVICE_ACCOUNT=<json>`
6. URL: `https://googlepro-signaling.onrender.com`

## Android APK
```bash
cd GooglePro
flutter build apk --release
# APK: build/app/outputs/flutter-apk/app-release.apk
```

## Android App Bundle (for Play Store)
```bash
flutter build appbundle --release
# AAB: build/app/outputs/bundle/release/app-release.aab
```

## Google Play Console
1. Upload AAB to Production track
2. Package: com.rawlings.googlepro
3. Minimum SDK: 21 (Android 5.0)
4. Target SDK: 34 (Android 14)
