# Privacy Policy

**Last updated: 2024**

## Data We Collect
- Account information (email, display name)
- Device information (model, Android version)
- Location data (only when tracking is enabled)
- Usage analytics (sessions, feature usage)

## How We Use Your Data
- To provide remote device management features
- To improve app performance and features
- To send push notifications for connection requests

## Data Storage
- Account data: Firebase (Google Cloud)
- Device commands: Firebase Realtime DB (temporary)
- File transfers: Firebase Storage
- Location: Firebase RTDB (cleared after session)

## Data Security
- All connections encrypted with TLS/WebRTC
- PIN/biometric stored in Android Keystore
- No plaintext passwords stored

## Your Rights
- Delete account: Settings > Account > Delete Account
- Export data: Contact support
- Disable analytics: Settings > Advanced > Usage Analytics

## Contact
For privacy concerns: privacy@googlepro.app
