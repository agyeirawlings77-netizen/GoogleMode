# GooglePro Backend API

Base URL: `https://googlepro-signaling.onrender.com/api/v1`

## Authentication
All endpoints (except /health) require:
```
Authorization: Bearer <firebase-id-token>
```

## Endpoints

### GET /health
Health check (no auth required)

### WebSocket /ws
```
wss://googlepro-signaling.onrender.com/ws?deviceId=X&token=Y
```
Messages: offer, answer, iceCandidate, join, leave

### POST /signal
Forward signal to target device
```json
{ "toDeviceId": "...", "message": { "type": "offer", ... } }
```

### GET /devices/online
List currently connected device IDs

### POST /sessions
Create a new session

### POST /notify/connection
Send FCM push for incoming connection

### POST /files/upload-url
Get upload path for file transfer
