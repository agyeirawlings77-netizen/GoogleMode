# GooglePro Architecture

## Overview
GooglePro follows Clean Architecture with BLoC state management.

## Layers
```
lib/
  features/          # Feature modules (Clean Architecture)
    auth/
      model/         # Domain entities
      repository/    # Abstract + impl
      service/       # Data sources
      state/         # BLoC events & states
      viewmodel/     # BLoC
      ui/            # Screens & widgets
  core/
    di/              # Dependency injection (GetIt)
    router/          # GoRouter navigation
    services/        # App-wide services
    utils/           # Utilities
    widgets/         # Shared widgets
    theme/           # App theming
    extensions/      # Dart extensions
```

## State Management
- **BLoC** (flutter_bloc) for all features
- Each feature has: Event → BLoC → State
- Immutable states, one-directional data flow

## Navigation
- **GoRouter** with shell routes for bottom nav
- Auth guard redirects unauthenticated users

## Networking
- **WebRTC** (flutter_webrtc) for real-time screen sharing
- **WebSocket** (web_socket_channel) for signaling
- **Firebase Realtime DB** for commands & presence
- **Firestore** for persistent data

## Key Technologies
| Tech | Use |
|------|-----|
| Firebase Auth | Authentication |
| Firestore | User/device data |
| Firebase RTDB | Real-time commands |
| Firebase Storage | File transfers/backups |
| Firebase Messaging | Push notifications |
| WebRTC | Screen sharing |
| Gemini AI | AI assistant |
| GetIt | Dependency injection |
| GoRouter | Navigation |
