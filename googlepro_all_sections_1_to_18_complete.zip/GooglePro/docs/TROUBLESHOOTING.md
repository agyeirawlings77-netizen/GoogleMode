# Troubleshooting

## Screen sharing not working
1. Check FOREGROUND_SERVICE permission in manifest
2. Ensure startForegroundService() is called before MediaProjection
3. On Android 14+, service must be started before requestScreenCapture

## Remote control not responding
1. Accessibility service must be enabled in device settings
2. Settings > Accessibility > GooglePro Remote Control > Enable
3. Check Firebase RTDB rules allow read/write

## WebSocket disconnects
1. Backend uses 30s heartbeat ping — client must respond to pong
2. Check Render.com free tier sleep timeout
3. Reconnect logic is built into SignalingService

## Firebase permission denied
1. Check Firestore security rules
2. Ensure user is authenticated before any Firestore calls
3. Verify google-services.json matches project ID pro-c76ee

## QR pairing fails
1. Codes expire after 5 minutes — regenerate if expired
2. Both devices must be online and authenticated
3. Check Firestore `pairing_codes` collection exists
