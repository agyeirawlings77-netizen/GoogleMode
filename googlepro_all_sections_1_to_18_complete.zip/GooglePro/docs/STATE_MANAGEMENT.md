# State Management Guide

## Pattern
Every feature uses **BLoC (Business Logic Component)** pattern:
```
UI → Event → Bloc → State → UI
```

## File Structure
```
features/feature_name/
  viewmodel/feature_bloc.dart    # BLoC
  state/feature_event.dart       # Events
  state/feature_state.dart       # States
  repository/                    # Data layer
  service/                       # External data
  model/                         # Domain models
  ui/                            # Screens & widgets
```

## BLoC Best Practices
1. **One BLoC per feature** — don't share BLoCs between features
2. **Emit states from handlers** — never from constructors
3. **Use emit.forEach** for streams
4. **Close subscriptions** in `close()`
5. **Factory BLoCs** via GetIt for fresh instances

## Common Patterns
```dart
// Load data
on<LoadDevicesEvent>((event, emit) async {
  emit(DeviceLoading());
  try {
    final devices = await repository.getDevices(uid);
    emit(DeviceLoaded(devices));
  } catch (err) {
    emit(DeviceError(err.toString()));
  }
});

// Stream subscription
on<WatchDevicesEvent>((event, emit) async {
  await emit.forEach(
    repository.watchDevices(uid),
    onData: (devices) => DeviceLoaded(devices),
    onError: (err, _) => DeviceError(err.toString()),
  );
});
```
