# Contributing to GooglePro

## Setup
```bash
git clone https://github.com/agyeirawlings77-netizen/GoogleMode.git
cd GoogleMode/GooglePro
flutter pub get
```

## Branch Naming
- `feature/feature-name`
- `fix/bug-description`
- `chore/task-name`

## Code Style
- Follow Flutter/Dart style guide
- Use BLoC for state management
- Clean Architecture (model/service/repository/state/viewmodel/ui)
- Write tests for all blocs

## Commit Messages
- `feat: add feature name`
- `fix: describe bug fix`
- `chore: maintenance task`

## Pull Requests
1. Fork the repository
2. Create your feature branch
3. Add tests
4. Submit PR with description

## Testing
```bash
flutter test
```
