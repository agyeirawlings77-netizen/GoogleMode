# Firebase Setup

## Project: pro-c76ee

### Firestore Collections
| Collection | Description |
|---|---|
| `users` | User profiles |
| `devices` | Registered Android devices |
| `sessions` | Remote control sessions |
| `stream_sessions` | Screen sharing sessions |
| `calls` | Voice call records |
| `chats/{sessionId}/messages` | Chat messages |
| `notifications` | User notifications |
| `parental_controls` | Parental control configs |
| `backups` | Cloud backup records |
| `file_transfers` | File transfer records |
| `trusted_devices` | Trusted device pairs |
| `pairing_codes` | QR pairing codes (TTL 5min) |

### Firebase RTDB Paths
| Path | Description |
|---|---|
| `presence/{deviceId}` | Online status |
| `device_status/{deviceId}` | Battery, storage, RAM |
| `device_location/{deviceId}` | Live GPS |
| `remote_commands/{deviceId}` | Real-time commands |
| `focus_mode/{deviceId}` | Focus mode config |
| `signaling/{sessionId}` | WebRTC offer/answer/ICE |

### Security Rules (Firestore)
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
    match /devices/{deviceId} {
      allow read, write: if request.auth != null && resource.data.userId == request.auth.uid;
      allow create: if request.auth != null;
    }
    match /sessions/{sessionId} {
      allow read, write: if request.auth != null;
    }
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```
