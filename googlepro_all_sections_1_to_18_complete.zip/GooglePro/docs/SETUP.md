# GooglePro Setup Guide

## Prerequisites
- Flutter 3.19+
- Android Studio / VS Code
- Firebase project (pro-c76ee)
- Node.js 20+ (for backend)

## Quick Start

```bash
# 1. Clone
git clone https://github.com/agyeirawlings77-netizen/GoogleMode.git
cd GoogleMode/GooglePro

# 2. Install Flutter deps
flutter pub get

# 3. Run dev
flutter run

# 4. Backend (optional local)
cd backend && npm install && npm run dev
```

## Firebase Setup
The app uses Firebase project: **pro-c76ee**
- google-services.json is already configured
- Firestore rules must allow authenticated read/write

## Environment
All credentials are hardcoded for development.
For production, use environment variables.

## Build Release APK
```bash
flutter build apk --release --obfuscate --split-debug-info=debug_info/
```
