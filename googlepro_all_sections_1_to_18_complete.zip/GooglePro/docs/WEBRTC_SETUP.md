# WebRTC Setup Guide

## Overview
GooglePro uses WebRTC for real-time screen sharing between Android devices.

## Architecture
```
Device A (Viewer) ←── WebRTC ──→ Device B (Screen)
         ↕                              ↕
    Signaling Server (WebSocket)
         ↕
    Firebase RTDB (ICE candidates)
```

## TURN/STUN Configuration
```
STUN: relay.metered.ca:80
TURN: relay.metered.ca:443
Username: adf231e2b5e252e24c33b810
Credential: W6dyxkfDTN4XQHKM
```

## Flow
1. Viewer calls `StartLiveScreenEvent`
2. Backend creates stream session in Firestore
3. Viewer sends WebRTC offer via signaling WS
4. Target device accepts and creates answer
5. ICE candidates exchanged via signaling or Firebase RTDB
6. P2P connection established
7. Screen frames transmitted via DataChannels or WebRTC video track

## Fallback
If WebRTC fails (NAT issues), falls back to:
- TURN relay server for all traffic
- Or screen capture frames uploaded to Firebase Storage (polling mode)

## Quality Settings
| Mode | Resolution | FPS | Bitrate |
|------|-----------|-----|---------|
| auto | adaptive | 30 | auto |
| low  | 480p | 15 | 500kbps |
| medium | 720p | 24 | 1.5Mbps |
| high | 1080p | 30 | 4Mbps |
