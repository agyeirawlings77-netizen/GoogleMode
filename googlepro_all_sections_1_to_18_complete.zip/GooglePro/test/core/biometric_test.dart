import 'package:flutter_test/flutter_test.dart';
void main() { group('BiometricService', () { test('types list', () { expect(['fingerprint', 'face', 'iris'].isNotEmpty, isTrue); }); test('handles unavailable gracefully', () => expect(true, isTrue)); }); }
