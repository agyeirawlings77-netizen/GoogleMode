// test/core/utils_test.dart
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('String Extensions', () {
    test('capitalize works correctly', () {
      expect('hello'.substring(0, 1).toUpperCase() + 'hello'.substring(1), 'Hello');
    });

    test('isValidEmail returns true for valid emails', () {
      final emailRegex = RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
      expect(emailRegex.hasMatch('test@example.com'), isTrue);
      expect(emailRegex.hasMatch('invalid-email'), isFalse);
    });

    test('isValidPassword returns true for passwords >= 8 chars', () {
      expect('password123'.length >= 8, isTrue);
      expect('short'.length >= 8, isFalse);
    });
  });

  group('DateTime Extensions', () {
    test('timeAgo returns correct label for recent times', () {
      final now = DateTime.now();
      final diff = now.difference(now.subtract(const Duration(minutes: 5)));
      expect(diff.inMinutes, equals(5));
    });

    test('formatDuration works for minutes', () {
      const duration = Duration(minutes: 3, seconds: 45);
      final m = duration.inMinutes.toString().padLeft(2, '0');
      final s = (duration.inSeconds % 60).toString().padLeft(2, '0');
      expect('$m:$s', equals('03:45'));
    });
  });

  group('File Size Formatting', () {
    String formatBytes(int bytes) {
      if (bytes >= 1073741824) return '${(bytes / 1073741824).toStringAsFixed(1)} GB';
      if (bytes >= 1048576) return '${(bytes / 1048576).toStringAsFixed(1)} MB';
      if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
      return '$bytes B';
    }

    test('formats bytes correctly', () {
      expect(formatBytes(500), '500 B');
      expect(formatBytes(2048), '2 KB');
      expect(formatBytes(1572864), '1.5 MB');
      expect(formatBytes(1073741824), '1.0 GB');
    });
  });
}
