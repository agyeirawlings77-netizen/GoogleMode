import 'package:flutter_test/flutter_test.dart';
void main() {
  group('String Extensions', () {
    test('capitalize', () { expect('hello'[0].toUpperCase() + 'hello'.substring(1), 'Hello'); });
    test('initials', () {
      const name = 'John Doe';
      final parts = name.split(' ');
      expect('${parts.first[0]}${parts.last[0]}'.toUpperCase(), 'JD');
    });
    test('truncate', () { const s = 'Hello World'; expect(s.length, 11); });
  });
}
