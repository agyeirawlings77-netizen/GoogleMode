import 'package:flutter_test/flutter_test.dart';
void main() {
  group('Validators', () {
    test('email validates correctly', () {
      expect('test@example.com'.contains('@'), isTrue);
      expect('invalid'.contains('@'), isFalse);
    });
    test('PIN format', () {
      expect(RegExp(r"^\d{4}$").hasMatch('1234'), isTrue);
      expect(RegExp(r"^\d{4}$").hasMatch('123'), isFalse);
      expect(RegExp(r"^\d{4}$").hasMatch('12345'), isFalse);
    });
    test('empty check', () => expect(''.isEmpty, isTrue));
  });
}
