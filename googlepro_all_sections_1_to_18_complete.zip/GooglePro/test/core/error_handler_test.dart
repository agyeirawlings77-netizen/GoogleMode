import 'package:flutter_test/flutter_test.dart';
void main() {
  group('ErrorHandler', () {
    test('handles network errors', () { expect('network error'.contains('network'), isTrue); });
    test('handles generic errors', () { expect('unexpected error'.isNotEmpty, isTrue); });
  });
}
