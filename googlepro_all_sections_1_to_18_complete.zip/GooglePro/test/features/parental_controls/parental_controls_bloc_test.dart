// test/features/parental_controls/parental_controls_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:googlepro/lib/features/parental_controls/viewmodel/parental_controls_bloc.dart';
import 'package:googlepro/lib/features/parental_controls/state/parental_controls_event.dart';
import 'package:googlepro/lib/features/parental_controls/state/parental_controls_state.dart';
import 'package:googlepro/lib/features/parental_controls/repository/parental_controls_repository.dart';
import 'package:googlepro/lib/features/parental_controls/model/parental_control_model.dart';

@GenerateMocks([ParentalControlsRepository])
void main() {
  group('ParentalControlsBloc', () {
    late MockParentalControlsRepository mockRepo;

    setUp(() { mockRepo = MockParentalControlsRepository(); });

    test('initial state is ParentalControlsInitial', () {
      final bloc = ParentalControlsBloc(repository: mockRepo);
      expect(bloc.state, isA<ParentalControlsInitial>());
      bloc.close();
    });

    blocTest<ParentalControlsBloc, ParentalControlsState>(
      'emits NotSet when no controls found',
      build: () {
        when(mockRepo.get(any)).thenAnswer((_) async => null);
        return ParentalControlsBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(LoadControlsEvent('device_1')),
      expect: () => [isA<ParentalControlsLoading>(), isA<ParentalControlsNotSet>()],
    );

    blocTest<ParentalControlsBloc, ParentalControlsState>(
      'emits Loaded when controls found',
      build: () {
        when(mockRepo.get(any)).thenAnswer((_) async => ParentalControlModel(
          id: 'test', parentUserId: 'parent',
          childDeviceId: 'device_1', childDeviceName: 'Test Device',
        ));
        return ParentalControlsBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(LoadControlsEvent('device_1')),
      expect: () => [isA<ParentalControlsLoading>(), isA<ParentalControlsLoaded>()],
    );
  });
}
