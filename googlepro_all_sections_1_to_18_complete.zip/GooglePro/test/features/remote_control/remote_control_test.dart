import 'package:flutter_test/flutter_test.dart';
void main() { group('RemoteControlBloc', () { test('command types', () => expect(['tap','swipe','home','back','recent','type_text','key_event'].isNotEmpty, isTrue)); test('coordinates are valid', () { double x = 500; double y = 800; expect(x, greaterThan(0)); expect(y, greaterThan(0)); }); }); }
