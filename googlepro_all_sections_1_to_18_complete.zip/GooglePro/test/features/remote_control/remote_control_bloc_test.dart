// test/features/remote_control/remote_control_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';

void main() {
  group('Remote Control BLoC Tests', () {
    test('initial state', () {
      expect(true, isTrue);
    });
  });
}
