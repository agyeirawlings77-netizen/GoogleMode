// test/features/signaling/signaling_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:googlepro/lib/features/signaling/service/signaling_service.dart';

void main() {
  group('SignalingMessage', () {
    test('serializes to map correctly', () {
      final msg = SignalingMessage(
        type: SignalingMessageType.ping,
        sessionId: 'sess_1',
        fromDeviceId: 'dev_1',
        toDeviceId: 'dev_2',
      );
      final map = msg.toMap();
      expect(map['type'], 'ping');
      expect(map['sessionId'], 'sess_1');
    });

    test('deserializes from map correctly', () {
      final map = {'type': 'offer', 'sessionId': 'sess_1', 'fromDeviceId': 'dev_1', 'toDeviceId': 'dev_2', 'payload': null};
      final msg = SignalingMessage.fromMap(map);
      expect(msg.type, SignalingMessageType.offer);
      expect(msg.sessionId, 'sess_1');
    });

    test('unknown type falls back to error', () {
      final msg = SignalingMessage.fromMap({'type': 'unknown_type'});
      expect(msg.type, SignalingMessageType.error);
    });
  });
}
