// test/features/file_transfer/file_transfer_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';

void main() {
  group('File Transfer BLoC Tests', () {
    test('initial state', () {
      expect(true, isTrue);
    });
  });
}
