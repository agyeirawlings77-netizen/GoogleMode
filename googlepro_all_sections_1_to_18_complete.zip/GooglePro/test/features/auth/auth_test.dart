// test/features/auth/auth_test.dart
import 'package:flutter_test/flutter_test.dart';
void main() { group('AuthBloc', () { test('validates email correctly', () => expect('test@example.com'.contains('@'), isTrue)); }); }
