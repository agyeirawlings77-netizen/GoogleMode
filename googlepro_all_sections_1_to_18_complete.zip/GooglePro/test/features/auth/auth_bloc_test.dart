// test/features/auth/auth_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';

import 'package:googlepro/lib/features/auth/viewmodel/auth_bloc.dart';
import 'package:googlepro/lib/features/auth/state/auth_event.dart';
import 'package:googlepro/lib/features/auth/state/auth_state.dart';
import 'package:googlepro/lib/features/auth/repository/auth_repository.dart';

@GenerateMocks([AuthRepository])
void main() {
  group('AuthBloc', () {
    late MockAuthRepository mockRepo;

    setUp(() {
      mockRepo = MockAuthRepository();
    });

    test('initial state is AuthInitial', () {
      final bloc = AuthBloc(repository: mockRepo);
      expect(bloc.state, isA<AuthInitial>());
      bloc.close();
    });

    blocTest<AuthBloc, AuthState>(
      'emits [AuthLoading, AuthError] when login fails',
      build: () {
        when(mockRepo.signInWithEmail(any, any)).thenThrow(Exception('Invalid credentials'));
        return AuthBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(SignInEvent(email: 'test@test.com', password: 'wrong')),
      expect: () => [isA<AuthLoading>(), isA<AuthError>()],
    );
  });
}
