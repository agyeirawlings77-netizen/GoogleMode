import 'package:flutter_test/flutter_test.dart';
void main() { group('Auth Integration', () { test('email validation', () { expect('test@example.com'.contains('@'), isTrue); expect('invalid'.contains('@'), isFalse); }); test('password length', () { expect('12345678'.length, 8); expect('short'.length, lessThan(8)); }); }); }
