// test/features/ai/ai_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:googlepro/lib/features/ai_assistant/viewmodel/ai_bloc.dart';
import 'package:googlepro/lib/features/ai_assistant/state/ai_event.dart';
import 'package:googlepro/lib/features/ai_assistant/state/ai_state.dart';
import 'package:googlepro/lib/features/ai_assistant/repository/ai_repository.dart';

@GenerateMocks([AiRepository])
void main() {
  group('AiBloc', () {
    late MockAiRepository mockRepo;

    setUp(() { mockRepo = MockAiRepository(); });

    blocTest<AiBloc, AiState>(
      'emits history on load',
      build: () {
        when(mockRepo.loadHistory()).thenAnswer((_) async => []);
        return AiBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(LoadAiHistoryEvent()),
      expect: () => [isA<AiConversationLoaded>()],
    );

    blocTest<AiBloc, AiState>(
      'emits Thinking then ResponseReceived on send',
      build: () {
        when(mockRepo.loadHistory()).thenAnswer((_) async => []);
        when(mockRepo.sendMessage(any, history: anyNamed('history')))
            .thenAnswer((_) async => 'Here is how you connect devices in GooglePro...');
        when(mockRepo.getSuggestions(any)).thenAnswer((_) async => []);
        when(mockRepo.saveHistory(any)).thenAnswer((_) async {});
        return AiBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(SendAiMessageEvent('How do I connect?')),
      expect: () => [isA<AiThinking>(), isA<AiResponseReceived>()],
    );

    blocTest<AiBloc, AiState>(
      'clears history on ClearAiHistoryEvent',
      build: () {
        when(mockRepo.loadHistory()).thenAnswer((_) async => []);
        when(mockRepo.clearHistory()).thenAnswer((_) async {});
        return AiBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(ClearAiHistoryEvent()),
      expect: () => [isA<AiHistoryCleared>(), isA<AiConversationLoaded>()],
    );
  });
}
