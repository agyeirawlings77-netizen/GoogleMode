import 'package:flutter_test/flutter_test.dart';
void main() { group('Location', () { test('coordinates format', () { double lat = 37.4219; double lng = -122.0840; expect(lat, lessThan(90)); expect(lng, greaterThan(-180)); }); test('history is list', () => expect(<dynamic>[], isA<List>())); }); }
