// test/features/location/location_test.dart
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('LocationModel', () {
    test('formattedCoords returns correct format', () {
      const lat = 40.7128;
      const lon = -74.0060;
      final formatted = '${lat.toStringAsFixed(4)}° N, ${lon.toStringAsFixed(4)}° E';
      expect(formatted, '40.7128° N, -74.0060° E');
    });
  });
}
