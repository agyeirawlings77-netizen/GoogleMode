// test/features/feature_1_test.dart
import 'package:flutter_test/flutter_test.dart';
void main() { group('Feature 1 Tests', () { test('passes', () => expect(true, isTrue)); }); }
