// test/features/wearable/wearable_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:googlepro/lib/features/wearable/viewmodel/wearable_bloc.dart';
import 'package:googlepro/lib/features/wearable/state/wearable_event.dart';
import 'package:googlepro/lib/features/wearable/state/wearable_state.dart';
import 'package:googlepro/lib/features/wearable/repository/wearable_repository.dart';

@GenerateMocks([WearableRepository])
void main() {
  group('WearableBloc', () {
    late MockWearableRepository mockRepo;

    setUp(() { mockRepo = MockWearableRepository(); });

    test('initial state is WearableInitial', () {
      final bloc = WearableBloc(repository: mockRepo);
      expect(bloc.state, isA<WearableInitial>());
      bloc.close();
    });

    blocTest<WearableBloc, WearableState>(
      'emits [Loading, Loaded] on LoadWearableNodesEvent',
      build: () {
        when(mockRepo.getConnectedNodes()).thenAnswer((_) async => []);
        return WearableBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(LoadWearableNodesEvent()),
      expect: () => [isA<WearableLoading>(), isA<WearableLoaded>()],
    );
  });
}
