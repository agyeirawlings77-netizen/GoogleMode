// test/features/trusted_device/trusted_device_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:googlepro/lib/features/trusted_device/viewmodel/trusted_device_bloc.dart';
import 'package:googlepro/lib/features/trusted_device/state/trusted_device_event.dart';
import 'package:googlepro/lib/features/trusted_device/state/trusted_device_state.dart';
import 'package:googlepro/lib/features/trusted_device/repository/trusted_device_repository.dart';

@GenerateMocks([TrustedDeviceRepository])
void main() {
  group('TrustedDeviceBloc', () {
    late MockTrustedDeviceRepository mockRepo;

    setUp(() { mockRepo = MockTrustedDeviceRepository(); });

    test('initial state is TrustedDeviceInitial', () {
      final bloc = TrustedDeviceBloc(repository: mockRepo);
      expect(bloc.state, isA<TrustedDeviceInitial>());
      bloc.close();
    });

    blocTest<TrustedDeviceBloc, TrustedDeviceState>(
      'emits [Loading, Loaded] on LoadTrustedDevicesEvent',
      build: () {
        when(mockRepo.getAll()).thenAnswer((_) async => []);
        return TrustedDeviceBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(LoadTrustedDevicesEvent()),
      expect: () => [isA<TrustedDeviceLoading>(), isA<TrustedDevicesLoaded>()],
    );

    blocTest<TrustedDeviceBloc, TrustedDeviceState>(
      'emits TrustCheckResult on CheckTrustEvent',
      build: () {
        when(mockRepo.isTrusted(any)).thenAnswer((_) async => true);
        return TrustedDeviceBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(CheckTrustEvent('device_1')),
      expect: () => [isA<TrustCheckResult>()],
    );
  });
}
