// test/features/analytics/analytics_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:googlepro/lib/features/analytics/viewmodel/analytics_bloc.dart';
import 'package:googlepro/lib/features/analytics/state/analytics_event.dart';
import 'package:googlepro/lib/features/analytics/state/analytics_state.dart';
import 'package:googlepro/lib/features/analytics/repository/analytics_repository.dart';
import 'package:googlepro/lib/features/analytics/service/analytics_tracker_service.dart';
import 'package:googlepro/lib/features/analytics/model/analytics_model.dart';

@GenerateMocks([AnalyticsRepository, AnalyticsTrackerService])
void main() {
  group('AnalyticsBloc', () {
    late MockAnalyticsRepository mockRepo;
    late MockAnalyticsTrackerService mockService;

    setUp(() {
      mockRepo = MockAnalyticsRepository();
      mockService = MockAnalyticsTrackerService();
    });

    test('initial state is AnalyticsInitial', () {
      final bloc = AnalyticsBloc(repository: mockRepo, service: mockService);
      expect(bloc.state, isA<AnalyticsInitial>());
      bloc.close();
    });

    blocTest<AnalyticsBloc, AnalyticsState>(
      'emits [Loading, Loaded] on LoadAnalyticsEvent',
      build: () {
        when(mockRepo.getAnalytics()).thenAnswer((_) async => const AnalyticsData(
          totalSessions: 10, totalDevices: 3, totalMinutes: 120,
        ));
        return AnalyticsBloc(repository: mockRepo, service: mockService);
      },
      act: (bloc) => bloc.add(LoadAnalyticsEvent()),
      expect: () => [isA<AnalyticsLoading>(), isA<AnalyticsLoaded>()],
    );
  });
}
