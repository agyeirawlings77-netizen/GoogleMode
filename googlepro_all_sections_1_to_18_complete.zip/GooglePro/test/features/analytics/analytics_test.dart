import 'package:flutter_test/flutter_test.dart';
void main() { group('AnalyticsBloc', () { test('initial state', () => expect(true, isTrue)); test('session types', () => expect(['screenShare','remoteControl','voiceCall','fileTransfer'].length, 4)); test('total time label', () { int minutes = 90; int h = minutes ~/ 60; int m = minutes % 60; expect(h, 1); expect(m, 30); }); }); }
