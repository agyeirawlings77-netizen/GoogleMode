// test/features/live_screen/live_screen_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';

void main() {
  group('Live Screen BLoC Tests', () {
    test('initial state', () {
      expect(true, isTrue);
    });
  });
}
