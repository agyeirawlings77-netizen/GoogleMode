// test/features/session/session_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';

import 'package:googlepro/lib/features/session/viewmodel/session_bloc.dart';
import 'package:googlepro/lib/features/session/state/session_event.dart';
import 'package:googlepro/lib/features/session/state/session_state.dart';
import 'package:googlepro/lib/features/session/repository/session_repository.dart';

@GenerateMocks([SessionRepository])
void main() {
  group('SessionBloc', () {
    late MockSessionRepository mockRepo;

    setUp(() {
      mockRepo = MockSessionRepository();
    });

    test('initial state is SessionInitial', () {
      final bloc = SessionBloc(repository: mockRepo);
      expect(bloc.state, isA<SessionInitial>());
      bloc.close();
    });

    blocTest<SessionBloc, SessionState>(
      'emits [SessionLoading, SessionHistoryLoaded] when history loaded',
      build: () {
        when(mockRepo.getSessionHistory(any)).thenAnswer((_) async => []);
        return SessionBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(LoadSessionHistoryEvent()),
      expect: () => [isA<SessionLoading>(), isA<SessionHistoryLoaded>()],
    );
  });
}
