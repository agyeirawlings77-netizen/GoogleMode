// test/features/connection/connection_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:googlepro/lib/features/connection/viewmodel/connection_bloc.dart';
import 'package:googlepro/lib/features/connection/state/connection_event.dart';
import 'package:googlepro/lib/features/connection/state/connection_state.dart';
import 'package:googlepro/lib/features/connection/repository/connection_repository.dart';
import 'package:googlepro/lib/features/connection/model/connection_model.dart';

@GenerateMocks([ConnectionRepository])
void main() {
  group('ConnectionBloc', () {
    late MockConnectionRepository mockRepo;

    setUp(() { mockRepo = MockConnectionRepository(); });

    test('initial state is ConnectionIdle', () {
      final bloc = ConnectionBloc(repository: mockRepo);
      expect(bloc.state, isA<ConnectionIdle>());
      bloc.close();
    });

    blocTest<ConnectionBloc, ConnectionState>(
      'emits ConnectionRequesting when SendConnectionRequestEvent is added',
      build: () {
        when(mockRepo.sendRequest(
          initiatorDeviceId: anyNamed('initiatorDeviceId'),
          targetDeviceId: anyNamed('targetDeviceId'),
          targetUserId: anyNamed('targetUserId'),
          targetDeviceName: anyNamed('targetDeviceName'),
        )).thenAnswer((_) async => ConnectionModel(
          requestId: 'req_1', initiatorDeviceId: 'dev_1', initiatorUserId: 'user_1',
          targetDeviceId: 'dev_2', targetUserId: 'user_2', targetDeviceName: 'Test',
          createdAt: DateTime.now(),
        ));
        when(mockRepo.watchRequest(any)).thenAnswer((_) => const Stream.empty());
        return ConnectionBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(SendConnectionRequestEvent(
        targetDeviceId: 'dev_2', targetUserId: 'user_2', targetDeviceName: 'Test',
      )),
      expect: () => [isA<ConnectionRequesting>(), isA<ConnectionPending>()],
    );
  });
}
