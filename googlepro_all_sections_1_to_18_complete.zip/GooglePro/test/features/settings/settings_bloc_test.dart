// test/features/settings/settings_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';

void main() {
  group('Settings BLoC Tests', () {
    test('initial state', () {
      expect(true, isTrue);
    });
  });
}
