// test/features/device/device_bloc_test.dart
import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';

import 'package:googlepro/lib/features/device_management/viewmodel/device_bloc.dart';
import 'package:googlepro/lib/features/device_management/state/device_event.dart';
import 'package:googlepro/lib/features/device_management/state/device_state.dart';
import 'package:googlepro/lib/features/device_management/repository/device_repository.dart';
import 'package:googlepro/lib/features/device_management/model/device_model.dart';

@GenerateMocks([DeviceRepository])
void main() {
  group('DeviceBloc', () {
    late MockDeviceRepository mockRepo;

    setUp(() {
      mockRepo = MockDeviceRepository();
    });

    test('initial state is DeviceInitial', () {
      final bloc = DeviceBloc(repository: mockRepo);
      expect(bloc.state, isA<DeviceInitial>());
      bloc.close();
    });

    blocTest<DeviceBloc, DeviceState>(
      'emits [DeviceLoading, DeviceLoaded] when devices loaded',
      build: () {
        when(mockRepo.getDevices(any)).thenAnswer((_) async => []);
        return DeviceBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(LoadDevicesEvent()),
      expect: () => [isA<DeviceLoading>(), isA<DeviceLoaded>()],
    );

    blocTest<DeviceBloc, DeviceState>(
      'emits [DeviceLoading, DeviceError] when loading fails',
      build: () {
        when(mockRepo.getDevices(any)).thenThrow(Exception('Network error'));
        return DeviceBloc(repository: mockRepo);
      },
      act: (bloc) => bloc.add(LoadDevicesEvent()),
      expect: () => [isA<DeviceLoading>(), isA<DeviceError>()],
    );
  });
}
