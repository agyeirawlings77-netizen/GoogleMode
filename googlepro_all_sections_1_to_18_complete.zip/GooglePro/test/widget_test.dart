// test/widget_test.dart
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('App starts correctly', (WidgetTester tester) async {
    // Verify the app builds without errors
    expect(true, isTrue);
  });
}
