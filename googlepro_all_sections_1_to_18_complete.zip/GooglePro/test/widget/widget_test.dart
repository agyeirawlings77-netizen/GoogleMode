import 'package:flutter_test/flutter_test.dart';
void main() {
  group('Widget Tests', () {
    testWidgets('StatCard renders', (tester) async {
      expect(find.byType(Exception), findsNothing);
    });
    testWidgets('EmptyState renders', (tester) async {
      expect(true, isTrue);
    });
  });
}
