// lib/features/connection/widget/connection_progress_widget.dart
import 'package:flutter/material.dart';

class ConnectionProgressWidget extends StatelessWidget {
  final String deviceName;
  const ConnectionProgressWidget({super.key, required this.deviceName});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(
            width: 80, height: 80,
            child: CircularProgressIndicator(strokeWidth: 6, color: Colors.blue),
          ),
          const SizedBox(height: 24),
          Text('Connecting to $deviceName',
              style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          const Text('Establishing secure connection...',
              style: TextStyle(color: Colors.white60, fontSize: 13)),
        ],
      ),
    );
  }
}
