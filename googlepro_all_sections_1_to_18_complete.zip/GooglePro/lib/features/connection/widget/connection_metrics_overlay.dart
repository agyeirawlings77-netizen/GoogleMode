// lib/features/connection/widget/connection_metrics_overlay.dart
import 'package:flutter/material.dart';
import '../model/connection_request.dart';

class ConnectionMetricsOverlay extends StatelessWidget {
  final ConnectionMetrics metrics;
  const ConnectionMetricsOverlay({super.key, required this.metrics});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.black54,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          _row('FPS', '${metrics.fps}'),
          _row('Bitrate', metrics.bitrateLabel),
          _row('Latency', '${metrics.latencyMs}ms'),
          _row('Quality', metrics.qualityLabel),
        ],
      ),
    );
  }

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 1),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('$label: ', style: const TextStyle(color: Colors.white60, fontSize: 11)),
        Text(value, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
      ],
    ),
  );
}
