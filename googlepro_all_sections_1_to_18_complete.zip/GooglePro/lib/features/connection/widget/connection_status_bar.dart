// lib/features/connection/widget/connection_status_bar.dart
import 'package:flutter/material.dart';

class ConnectionStatusBar extends StatelessWidget {
  final String deviceName;
  final VoidCallback onDisconnect;

  const ConnectionStatusBar({
    super.key,
    required this.deviceName,
    required this.onDisconnect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.black87, Colors.transparent],
        ),
      ),
      padding: EdgeInsets.fromLTRB(16, MediaQuery.of(context).padding.top + 8, 16, 16),
      child: Row(
        children: [
          const Icon(Icons.circle, color: Colors.green, size: 10),
          const SizedBox(width: 8),
          Expanded(
            child: Text(deviceName,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
          IconButton(
            icon: const Icon(Icons.call_end, color: Colors.red),
            onPressed: onDisconnect,
          ),
        ],
      ),
    );
  }
}
