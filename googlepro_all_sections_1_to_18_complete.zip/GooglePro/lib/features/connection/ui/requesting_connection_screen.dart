// lib/features/connection/ui/requesting_connection_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../viewmodel/connection_bloc.dart';
import '../state/connection_event.dart';
import '../state/connection_state.dart';

class RequestingConnectionScreen extends StatefulWidget {
  final String targetDeviceId;
  final String targetUserId;
  final String targetDeviceName;
  const RequestingConnectionScreen({
    super.key,
    required this.targetDeviceId,
    required this.targetUserId,
    required this.targetDeviceName,
  });

  @override
  State<RequestingConnectionScreen> createState() => _RequestingConnectionScreenState();
}

class _RequestingConnectionScreenState extends State<RequestingConnectionScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 1))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.85, end: 1.1).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
    context.read<ConnectionBloc>().add(SendConnectionRequestEvent(
      targetDeviceId: widget.targetDeviceId,
      targetUserId: widget.targetUserId,
      targetDeviceName: widget.targetDeviceName,
    ));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2A),
      body: BlocListener<ConnectionBloc, ConnectionState>(
        listener: (context, state) {
          if (state is ConnectionActive) context.go('/session/${state.model.requestId}');
          if (state is ConnectionRejected) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('${widget.targetDeviceName} rejected the request'), backgroundColor: Colors.red),
            );
            context.pop();
          }
          if (state is ConnectionFailed) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.reason), backgroundColor: Colors.red),
            );
            context.pop();
          }
        },
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              ScaleTransition(
                scale: _pulse,
                child: Container(
                  width: 130, height: 130,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.blue.withOpacity(0.5), width: 3),
                    color: Colors.blue.withOpacity(0.15),
                  ),
                  child: const Icon(Icons.phone_android, size: 64, color: Colors.blue),
                ),
              ),
              const SizedBox(height: 32),
              Text(widget.targetDeviceName,
                  style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Waiting for response...',
                  style: TextStyle(color: Colors.white54, fontSize: 15)),
              const SizedBox(height: 40),
              const CircularProgressIndicator(color: Colors.blue),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.all(32),
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.call_end),
                  label: const Text('Cancel'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red, foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 52),
                  ),
                  onPressed: () {
                    context.read<ConnectionBloc>().add(DisconnectEvent());
                    context.pop();
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
