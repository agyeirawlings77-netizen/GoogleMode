// lib/features/connection/ui/connection_history_screen.dart
import 'package:flutter/material.dart';

class ConnectionHistoryScreen extends StatelessWidget {
  const ConnectionHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Connection History')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: 0,
        itemBuilder: (_, __) => const SizedBox(),
      ),
    );
  }
}
