// lib/features/connection/ui/incoming_connection_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../viewmodel/connection_bloc.dart';
import '../state/connection_event.dart';
import '../state/connection_state.dart';

class IncomingConnectionScreen extends StatefulWidget {
  final String requestId;
  final String callerName;
  final String callerDeviceId;

  const IncomingConnectionScreen({
    super.key,
    required this.requestId,
    required this.callerName,
    required this.callerDeviceId,
  });

  @override
  State<IncomingConnectionScreen> createState() => _IncomingConnectionScreenState();
}

class _IncomingConnectionScreenState extends State<IncomingConnectionScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 1))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.9, end: 1.1).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _pulseCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D1B2A),
      body: BlocListener<ConnectionBloc, ConnectionState>(
        listener: (context, state) {
          if (state is ConnectionActive) context.go('/dashboard');
          if (state is ConnectionRejected) context.go('/dashboard');
        },
        child: SafeArea(
          child: Column(
            children: [
              const Spacer(),
              const Text('Incoming Connection Request',
                  style: TextStyle(color: Colors.white70, fontSize: 16)),
              const SizedBox(height: 32),
              ScaleTransition(
                scale: _pulse,
                child: Container(
                  width: 120, height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.blue.withOpacity(0.5), width: 3),
                    color: Colors.blue.withOpacity(0.2),
                  ),
                  child: const Icon(Icons.phone_android, size: 60, color: Colors.blue),
                ),
              ),
              const SizedBox(height: 24),
              Text(widget.callerName,
                  style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Wants to connect to your device',
                  style: TextStyle(color: Colors.white54, fontSize: 15)),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 32),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _actionBtn(
                      icon: Icons.call_end,
                      label: 'Reject',
                      color: Colors.red,
                      onTap: () => context.read<ConnectionBloc>().add(
                        RejectConnectionEvent(widget.requestId, widget.callerDeviceId),
                      ),
                    ),
                    _actionBtn(
                      icon: Icons.call,
                      label: 'Accept',
                      color: Colors.green,
                      onTap: () => context.read<ConnectionBloc>().add(
                        AcceptConnectionEvent(widget.requestId, widget.callerDeviceId),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _actionBtn({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return Column(
      children: [
        GestureDetector(
          onTap: onTap,
          child: CircleAvatar(
            radius: 36,
            backgroundColor: color,
            child: Icon(icon, color: Colors.white, size: 32),
          ),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(color: Colors.white70)),
      ],
    );
  }
}
