// lib/features/connection/ui/connection_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../viewmodel/connection_bloc.dart';
import '../state/connection_event.dart';
import '../state/connection_state.dart' as cs;
import '../widget/connection_request_dialog.dart';
import '../widget/connection_progress_widget.dart';
import '../widget/connection_status_bar.dart';
import '../widget/connection_metrics_overlay.dart';

class ConnectionScreen extends StatefulWidget {
  final String targetDeviceId;
  final String targetUserId;
  final String targetDeviceName;
  final bool isTrusted;

  const ConnectionScreen({
    super.key,
    required this.targetDeviceId,
    required this.targetUserId,
    required this.targetDeviceName,
    this.isTrusted = false,
  });

  @override
  State<ConnectionScreen> createState() => _ConnectionScreenState();
}

class _ConnectionScreenState extends State<ConnectionScreen> {
  @override
  void initState() {
    super.initState();
    if (widget.isTrusted) {
      context.read<ConnectionBloc>().add(AutoConnectTrustedEvent(
        targetDeviceId: widget.targetDeviceId,
        targetUserId: widget.targetUserId,
      ));
    } else {
      context.read<ConnectionBloc>().add(RequestConnectionEvent(
        targetDeviceId: widget.targetDeviceId,
        targetUserId: widget.targetUserId,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: BlocConsumer<ConnectionBloc, cs.ConnectionState>(
        listener: (context, state) {
          if (state is cs.ConnectionDisconnected) {
            Navigator.of(context).pop();
          }
          if (state is cs.ConnectionFailed && !state.canRetry) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.error), backgroundColor: Colors.red),
            );
            Navigator.of(context).pop();
          }
        },
        builder: (context, state) {
          if (state is cs.ConnectionRequesting) {
            return _buildRequesting(context);
          }
          if (state is cs.ConnectionIncoming) {
            return ConnectionRequestDialog(
              request: state.request,
              onAccept: () => context.read<ConnectionBloc>().add(AcceptConnectionEvent(state.request)),
              onReject: () => context.read<ConnectionBloc>().add(RejectConnectionEvent(state.request.requestId)),
            );
          }
          if (state is cs.ConnectionConnecting || state is cs.AutoConnecting) {
            return ConnectionProgressWidget(deviceName: widget.targetDeviceName);
          }
          if (state is cs.ConnectionConnected) {
            return _buildConnected(context, state);
          }
          if (state is cs.ConnectionReconnecting) {
            return _buildReconnecting(context, state.attempt);
          }
          if (state is cs.ConnectionFailed) {
            return _buildFailed(context, state.error, state.canRetry);
          }
          return _buildRequesting(context);
        },
      ),
    );
  }

  Widget _buildRequesting(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(color: Colors.blue),
          const SizedBox(height: 20),
          Text('Connecting to ${widget.targetDeviceName}...',
              style: const TextStyle(color: Colors.white, fontSize: 16)),
          const SizedBox(height: 16),
          TextButton(
            onPressed: () {
              context.read<ConnectionBloc>().add(DisconnectEvent());
              Navigator.pop(context);
            },
            child: const Text('Cancel', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _buildConnected(BuildContext context, cs.ConnectionConnected state) {
    return Stack(
      children: [
        const Center(child: Text('Connected', style: TextStyle(color: Colors.white))),
        Positioned(
          top: 0, left: 0, right: 0,
          child: ConnectionStatusBar(
            deviceName: widget.targetDeviceName,
            onDisconnect: () => context.read<ConnectionBloc>().add(DisconnectEvent()),
          ),
        ),
        Positioned(
          bottom: 16, left: 16,
          child: ConnectionMetricsOverlay(metrics: state.metrics),
        ),
      ],
    );
  }

  Widget _buildReconnecting(BuildContext context, int attempt) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(color: Colors.orange),
          const SizedBox(height: 16),
          Text('Reconnecting... (attempt $attempt)',
              style: const TextStyle(color: Colors.white)),
          const SizedBox(height: 16),
          TextButton(
            onPressed: () => context.read<ConnectionBloc>().add(DisconnectEvent()),
            child: const Text('Cancel', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _buildFailed(BuildContext context, String error, bool canRetry) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, color: Colors.red, size: 64),
          const SizedBox(height: 16),
          Text(error, style: const TextStyle(color: Colors.white), textAlign: TextAlign.center),
          const SizedBox(height: 24),
          if (canRetry)
            ElevatedButton(
              onPressed: () => context.read<ConnectionBloc>().add(ReconnectEvent()),
              child: const Text('Retry'),
            ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Go Back', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
