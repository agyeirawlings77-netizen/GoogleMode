// lib/features/connection/manager/device_connection_manager.dart
import 'dart:async';
import 'package:flutter/foundation.dart';
import '../model/connection_model.dart';
import '../service/connection_service.dart';
import '../../trusted_device/service/trusted_pairing_service.dart';

class DeviceConnectionManager {
  final ConnectionService _service;

  ConnectionModel? _activeConnection;
  DateTime? _connectionStartTime;
  int _reconnectAttempts = 0;
  static const int _maxReconnectAttempts = 5;

  final _connectionController = StreamController<ConnectionModel?>.broadcast();
  Stream<ConnectionModel?> get connectionStream => _connectionController.stream;
  ConnectionModel? get activeConnection => _activeConnection;
  bool get isConnected => _activeConnection?.status == ConnectionStatus.connected;

  DeviceConnectionManager({required ConnectionService service})
      : _service = service;

  Future<String> initiateConnection({
    required String fromDeviceId,
    required String fromUserId,
    required String fromDeviceName,
    required String toDeviceId,
    required String toUserId,
    required String sessionType,
    bool isTrusted = false,
  }) async {
    final requestId = await _service.sendConnectionRequest(
      fromDeviceId: fromDeviceId,
      fromUserId: fromUserId,
      fromDeviceName: fromDeviceName,
      toDeviceId: toDeviceId,
      toUserId: toUserId,
      sessionType: sessionType,
      autoAccept: isTrusted,
    );

    _activeConnection = ConnectionModel(
      connectionId: requestId,
      initiatorDeviceId: fromDeviceId,
      initiatorUserId: fromUserId,
      targetDeviceId: toDeviceId,
      targetUserId: toUserId,
      status: ConnectionStatus.requesting,
      type: _parseType(sessionType),
      createdAt: DateTime.now(),
      isTrusted: isTrusted,
    );
    _connectionController.add(_activeConnection);
    return requestId;
  }

  void onConnectionEstablished(ConnectionModel connection) {
    _connectionStartTime = DateTime.now();
    _reconnectAttempts = 0;
    _activeConnection = connection.copyWith(
      status: ConnectionStatus.connected,
      connectedAt: DateTime.now(),
    );
    _connectionController.add(_activeConnection);
    debugPrint('Connection established: ${connection.connectionId}');
  }

  Future<void> disconnect({String? reason}) async {
    if (_activeConnection == null) return;
    _activeConnection = _activeConnection!.copyWith(
      status: ConnectionStatus.disconnecting,
      disconnectedAt: DateTime.now(),
    );
    _connectionController.add(_activeConnection);
    await _service.endConnection(_activeConnection!.connectionId);
    _activeConnection = null;
    _connectionController.add(null);
    debugPrint('Disconnected: $reason');
  }

  bool shouldAutoReconnect() => _reconnectAttempts < _maxReconnectAttempts;

  void incrementReconnectAttempts() => _reconnectAttempts++;

  Duration? get sessionDuration {
    if (_connectionStartTime == null) return null;
    return DateTime.now().difference(_connectionStartTime!);
  }

  ConnectionType _parseType(String type) {
    switch (type) {
      case 'remote_control': return ConnectionType.remoteControl;
      case 'voice_call': return ConnectionType.voiceCall;
      case 'file_transfer': return ConnectionType.fileTransfer;
      default: return ConnectionType.screenShare;
    }
  }

  void dispose() {
    _connectionController.close();
  }
}
