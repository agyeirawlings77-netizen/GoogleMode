// lib/features/connection/model/connection_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

enum ConnectionStatus { idle, requesting, connecting, connected, disconnecting, disconnected, failed }
enum ConnectionType { screenShare, remoteControl, voiceCall, fileTransfer }

class ConnectionModel {
  final String connectionId;
  final String initiatorDeviceId;
  final String initiatorUserId;
  final String targetDeviceId;
  final String targetUserId;
  final ConnectionStatus status;
  final ConnectionType type;
  final DateTime createdAt;
  final DateTime? connectedAt;
  final DateTime? disconnectedAt;
  final Map<String, dynamic> config;
  final bool isTrusted;

  const ConnectionModel({
    required this.connectionId,
    required this.initiatorDeviceId,
    required this.initiatorUserId,
    required this.targetDeviceId,
    required this.targetUserId,
    this.status = ConnectionStatus.idle,
    this.type = ConnectionType.screenShare,
    required this.createdAt,
    this.connectedAt,
    this.disconnectedAt,
    this.config = const {},
    this.isTrusted = false,
  });

  Duration? get duration {
    if (connectedAt == null) return null;
    final end = disconnectedAt ?? DateTime.now();
    return end.difference(connectedAt!);
  }

  ConnectionModel copyWith({
    ConnectionStatus? status,
    DateTime? connectedAt,
    DateTime? disconnectedAt,
    bool? isTrusted,
    Map<String, dynamic>? config,
  }) {
    return ConnectionModel(
      connectionId: connectionId,
      initiatorDeviceId: initiatorDeviceId,
      initiatorUserId: initiatorUserId,
      targetDeviceId: targetDeviceId,
      targetUserId: targetUserId,
      status: status ?? this.status,
      type: type,
      createdAt: createdAt,
      connectedAt: connectedAt ?? this.connectedAt,
      disconnectedAt: disconnectedAt ?? this.disconnectedAt,
      config: config ?? this.config,
      isTrusted: isTrusted ?? this.isTrusted,
    );
  }

  factory ConnectionModel.fromMap(Map<String, dynamic> map) {
    return ConnectionModel(
      connectionId: map['connectionId'] ?? '',
      initiatorDeviceId: map['initiatorDeviceId'] ?? '',
      initiatorUserId: map['initiatorUserId'] ?? '',
      targetDeviceId: map['targetDeviceId'] ?? '',
      targetUserId: map['targetUserId'] ?? '',
      status: ConnectionStatus.values.firstWhere(
        (e) => e.name == (map['status'] ?? 'idle'),
        orElse: () => ConnectionStatus.idle,
      ),
      type: ConnectionType.values.firstWhere(
        (e) => e.name == (map['type'] ?? 'screenShare'),
        orElse: () => ConnectionType.screenShare,
      ),
      createdAt: (map['createdAt'] is Timestamp)
          ? (map['createdAt'] as Timestamp).toDate()
          : DateTime.tryParse(map['createdAt']?.toString() ?? '') ?? DateTime.now(),
      connectedAt: map['connectedAt'] != null
          ? DateTime.tryParse(map['connectedAt'].toString())
          : null,
      disconnectedAt: map['disconnectedAt'] != null
          ? DateTime.tryParse(map['disconnectedAt'].toString())
          : null,
      config: Map<String, dynamic>.from(map['config'] ?? {}),
      isTrusted: map['isTrusted'] ?? false,
    );
  }

  Map<String, dynamic> toMap() => {
    'connectionId': connectionId,
    'initiatorDeviceId': initiatorDeviceId,
    'initiatorUserId': initiatorUserId,
    'targetDeviceId': targetDeviceId,
    'targetUserId': targetUserId,
    'status': status.name,
    'type': type.name,
    'createdAt': Timestamp.fromDate(createdAt),
    'connectedAt': connectedAt?.toIso8601String(),
    'disconnectedAt': disconnectedAt?.toIso8601String(),
    'config': config,
    'isTrusted': isTrusted,
  };
}
