// lib/features/connection/model/connection_request.dart

class ConnectionRequest {
  final String requestId;
  final String fromDeviceId;
  final String fromUserId;
  final String fromDeviceName;
  final String toDeviceId;
  final String toUserId;
  final String sessionType;
  final DateTime requestedAt;
  final bool autoAccept;

  const ConnectionRequest({
    required this.requestId,
    required this.fromDeviceId,
    required this.fromUserId,
    required this.fromDeviceName,
    required this.toDeviceId,
    required this.toUserId,
    required this.sessionType,
    required this.requestedAt,
    this.autoAccept = false,
  });

  factory ConnectionRequest.fromMap(Map<String, dynamic> map) => ConnectionRequest(
    requestId: map['requestId'] ?? '',
    fromDeviceId: map['fromDeviceId'] ?? '',
    fromUserId: map['fromUserId'] ?? '',
    fromDeviceName: map['fromDeviceName'] ?? 'Unknown Device',
    toDeviceId: map['toDeviceId'] ?? '',
    toUserId: map['toUserId'] ?? '',
    sessionType: map['sessionType'] ?? 'screen_share',
    requestedAt: DateTime.tryParse(map['requestedAt']?.toString() ?? '') ?? DateTime.now(),
    autoAccept: map['autoAccept'] ?? false,
  );

  Map<String, dynamic> toMap() => {
    'requestId': requestId,
    'fromDeviceId': fromDeviceId,
    'fromUserId': fromUserId,
    'fromDeviceName': fromDeviceName,
    'toDeviceId': toDeviceId,
    'toUserId': toUserId,
    'sessionType': sessionType,
    'requestedAt': requestedAt.toIso8601String(),
    'autoAccept': autoAccept,
  };
}

class ConnectionConfig {
  final String quality;
  final int maxBitrate;
  final int maxFps;
  final bool enableAudio;
  final bool enableRemoteControl;
  final bool encryptData;

  const ConnectionConfig({
    this.quality = 'auto',
    this.maxBitrate = 2000000,
    this.maxFps = 30,
    this.enableAudio = false,
    this.enableRemoteControl = false,
    this.encryptData = true,
  });

  Map<String, dynamic> toMap() => {
    'quality': quality,
    'maxBitrate': maxBitrate,
    'maxFps': maxFps,
    'enableAudio': enableAudio,
    'enableRemoteControl': enableRemoteControl,
    'encryptData': encryptData,
  };

  factory ConnectionConfig.fromMap(Map<String, dynamic> map) => ConnectionConfig(
    quality: map['quality'] ?? 'auto',
    maxBitrate: map['maxBitrate'] ?? 2000000,
    maxFps: map['maxFps'] ?? 30,
    enableAudio: map['enableAudio'] ?? false,
    enableRemoteControl: map['enableRemoteControl'] ?? false,
    encryptData: map['encryptData'] ?? true,
  );
}

class ConnectionMetrics {
  final int fps;
  final int bitrateBps;
  final int latencyMs;
  final double packetLoss;
  final String resolution;
  final DateTime timestamp;

  const ConnectionMetrics({
    this.fps = 0,
    this.bitrateBps = 0,
    this.latencyMs = 0,
    this.packetLoss = 0.0,
    this.resolution = '',
    required this.timestamp,
  });

  String get bitrateLabel {
    if (bitrateBps >= 1000000) return '${(bitrateBps / 1000000).toStringAsFixed(1)} Mbps';
    return '${(bitrateBps / 1000).toStringAsFixed(0)} Kbps';
  }

  String get qualityLabel {
    if (latencyMs < 50 && packetLoss < 1) return 'Excellent';
    if (latencyMs < 150 && packetLoss < 3) return 'Good';
    if (latencyMs < 300 && packetLoss < 5) return 'Fair';
    return 'Poor';
  }

  factory ConnectionMetrics.empty() => ConnectionMetrics(timestamp: DateTime.now());
}
