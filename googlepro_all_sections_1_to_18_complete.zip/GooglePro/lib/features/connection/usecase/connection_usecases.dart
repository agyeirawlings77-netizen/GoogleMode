// lib/features/connection/usecase/connection_usecases.dart
import '../model/connection_model.dart';
import '../model/connection_request.dart';
import '../repository/connection_repository.dart';

class ConnectToDeviceUseCase {
  final ConnectionRepository repository;
  ConnectToDeviceUseCase(this.repository);
  Future<String> execute({
    required String fromDeviceId, required String fromUserId,
    required String fromDeviceName, required String toDeviceId,
    required String toUserId, String sessionType = 'screen_share',
    bool autoAccept = false,
  }) => repository.sendRequest(
    fromDeviceId: fromDeviceId, fromUserId: fromUserId,
    fromDeviceName: fromDeviceName, toDeviceId: toDeviceId,
    toUserId: toUserId, sessionType: sessionType, autoAccept: autoAccept,
  );
}

class DisconnectDeviceUseCase {
  final ConnectionRepository repository;
  DisconnectDeviceUseCase(this.repository);
  Future<void> execute(String connectionId) => repository.endConnection(connectionId);
}

class WatchIncomingRequestsUseCase {
  final ConnectionRepository repository;
  WatchIncomingRequestsUseCase(this.repository);
  Stream<ConnectionRequest?> execute(String myDeviceId) => repository.watchIncoming(myDeviceId);
}

class AcceptConnectionUseCase {
  final ConnectionRepository repository;
  AcceptConnectionUseCase(this.repository);
  Future<void> execute(String myDeviceId, String requestId) =>
      repository.acceptRequest(myDeviceId, requestId);
}

class RejectConnectionUseCase {
  final ConnectionRepository repository;
  RejectConnectionUseCase(this.repository);
  Future<void> execute(String myDeviceId) => repository.rejectRequest(myDeviceId);
}
