// lib/features/connection/viewmodel/connection_bloc.dart
import 'dart:async';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../manager/device_connection_manager.dart';
import '../model/connection_model.dart';
import '../model/connection_request.dart';
import '../repository/connection_repository.dart';
import '../state/connection_event.dart';
import '../state/connection_state.dart' as cs;

class ConnectionBloc extends Bloc<ConnectionEvent, cs.ConnectionState> {
  final ConnectionRepository repository;
  final DeviceConnectionManager manager;

  StreamSubscription? _incomingSub;
  StreamSubscription? _statusSub;
  StreamSubscription? _managerSub;

  String? _myDeviceId;
  String? _myUserId;
  String? _myDeviceName;

  ConnectionBloc({required this.repository, required this.manager})
      : super(cs.ConnectionInitial()) {
    on<RequestConnectionEvent>(_onRequest);
    on<AcceptConnectionEvent>(_onAccept);
    on<RejectConnectionEvent>(_onReject);
    on<DisconnectEvent>(_onDisconnect);
    on<ConnectionEstablishedEvent>(_onEstablished);
    on<ConnectionFailedEvent>(_onFailed);
    on<IncomingConnectionRequestEvent>(_onIncoming);
    on<UpdateMetricsEvent>(_onUpdateMetrics);
    on<ReconnectEvent>(_onReconnect);
    on<WatchIncomingRequestsEvent>(_onWatchIncoming);
    on<AutoConnectTrustedEvent>(_onAutoConnect);
  }

  void setDeviceInfo(String deviceId, String userId, String deviceName) {
    _myDeviceId = deviceId;
    _myUserId = userId;
    _myDeviceName = deviceName;
  }

  Future<void> _onRequest(RequestConnectionEvent event, Emitter<cs.ConnectionState> emit) async {
    emit(cs.ConnectionRequesting(
      targetDeviceId: event.targetDeviceId,
      targetDeviceName: event.targetDeviceId,
    ));
    try {
      await manager.initiateConnection(
        fromDeviceId: _myDeviceId ?? '',
        fromUserId: _myUserId ?? '',
        fromDeviceName: _myDeviceName ?? 'My Device',
        toDeviceId: event.targetDeviceId,
        toUserId: event.targetUserId,
        sessionType: event.type.name,
        isTrusted: event.isTrusted,
      );

      // Watch for acceptance
      await _statusSub?.cancel();
      _statusSub = repository.watchRequestStatus(event.targetDeviceId).listen((status) {
        if (status == 'accepted') {
          emit(cs.ConnectionConnecting(event.targetDeviceId));
        }
      });
    } catch (e) {
      emit(cs.ConnectionFailed(error: e.toString()));
    }
  }

  Future<void> _onAccept(AcceptConnectionEvent event, Emitter<cs.ConnectionState> emit) async {
    emit(cs.ConnectionConnecting(event.request.fromDeviceId));
    try {
      await repository.acceptRequest(_myDeviceId ?? '', event.request.requestId);
      await repository.clearRequest(_myDeviceId ?? '');
    } catch (e) {
      emit(cs.ConnectionFailed(error: e.toString()));
    }
  }

  Future<void> _onReject(RejectConnectionEvent event, Emitter<cs.ConnectionState> emit) async {
    await repository.rejectRequest(_myDeviceId ?? '');
    emit(cs.ConnectionIdle());
  }

  Future<void> _onDisconnect(DisconnectEvent event, Emitter<cs.ConnectionState> emit) async {
    emit(cs.ConnectionDisconnecting());
    final duration = manager.sessionDuration;
    await manager.disconnect(reason: event.reason);
    emit(cs.ConnectionDisconnected(reason: event.reason, sessionDuration: duration));
  }

  void _onEstablished(ConnectionEstablishedEvent event, Emitter<cs.ConnectionState> emit) {
    manager.onConnectionEstablished(event.connection);
    emit(cs.ConnectionConnected(
      connection: event.connection,
      metrics: ConnectionMetrics.empty(),
    ));
  }

  void _onFailed(ConnectionFailedEvent event, Emitter<cs.ConnectionState> emit) {
    emit(cs.ConnectionFailed(
      error: event.error,
      canRetry: manager.shouldAutoReconnect(),
    ));
  }

  void _onIncoming(IncomingConnectionRequestEvent event, Emitter<cs.ConnectionState> emit) {
    if (event.request.autoAccept) {
      add(AcceptConnectionEvent(event.request));
    } else {
      emit(cs.ConnectionIncoming(event.request));
    }
  }

  void _onUpdateMetrics(UpdateMetricsEvent event, Emitter<cs.ConnectionState> emit) {
    if (state is cs.ConnectionConnected) {
      final s = state as cs.ConnectionConnected;
      emit(s.copyWith(metrics: event.metrics));
    }
  }

  Future<void> _onReconnect(ReconnectEvent event, Emitter<cs.ConnectionState> emit) async {
    if (!manager.shouldAutoReconnect()) {
      emit(cs.ConnectionFailed(error: 'Max reconnect attempts reached', canRetry: false));
      return;
    }
    manager.incrementReconnectAttempts();
    emit(cs.ConnectionReconnecting(1));
  }

  Future<void> _onWatchIncoming(WatchIncomingRequestsEvent event, Emitter<cs.ConnectionState> emit) async {
    await _incomingSub?.cancel();
    _incomingSub = repository.watchIncoming(event.myDeviceId).listen((request) {
      if (request != null) add(IncomingConnectionRequestEvent(request));
    });
  }

  Future<void> _onAutoConnect(AutoConnectTrustedEvent event, Emitter<cs.ConnectionState> emit) async {
    emit(cs.AutoConnecting(event.targetDeviceId));
    add(RequestConnectionEvent(
      targetDeviceId: event.targetDeviceId,
      targetUserId: event.targetUserId,
      isTrusted: true,
    ));
  }

  @override
  Future<void> close() async {
    await _incomingSub?.cancel();
    await _statusSub?.cancel();
    await _managerSub?.cancel();
    manager.dispose();
    return super.close();
  }
}
