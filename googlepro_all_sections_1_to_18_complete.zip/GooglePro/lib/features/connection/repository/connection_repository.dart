// lib/features/connection/repository/connection_repository.dart
import '../model/connection_model.dart';
import '../model/connection_request.dart';
import '../service/connection_service.dart';

class ConnectionRepository {
  final ConnectionService _service;
  ConnectionRepository({ConnectionService? service})
      : _service = service ?? ConnectionService();

  Future<String> sendRequest({
    required String fromDeviceId, required String fromUserId,
    required String fromDeviceName, required String toDeviceId,
    required String toUserId, required String sessionType,
    bool autoAccept = false,
  }) => _service.sendConnectionRequest(
    fromDeviceId: fromDeviceId, fromUserId: fromUserId,
    fromDeviceName: fromDeviceName, toDeviceId: toDeviceId,
    toUserId: toUserId, sessionType: sessionType, autoAccept: autoAccept,
  );

  Stream<ConnectionRequest?> watchIncoming(String myDeviceId) =>
      _service.watchIncomingRequests(myDeviceId);

  Future<void> acceptRequest(String myDeviceId, String requestId) =>
      _service.acceptRequest(myDeviceId, requestId);

  Future<void> rejectRequest(String myDeviceId) =>
      _service.rejectRequest(myDeviceId);

  Future<void> clearRequest(String deviceId) =>
      _service.clearRequest(deviceId);

  Stream<String?> watchRequestStatus(String targetDeviceId) =>
      _service.watchRequestStatus(targetDeviceId);

  Future<void> saveConnection(ConnectionModel connection) =>
      _service.saveActiveConnection(connection);

  Future<void> endConnection(String connectionId) =>
      _service.endConnection(connectionId);
}
