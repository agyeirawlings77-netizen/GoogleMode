// lib/features/connection/state/connection_event.dart
import '../model/connection_model.dart';
import '../model/connection_request.dart';

abstract class ConnectionEvent {}

class RequestConnectionEvent extends ConnectionEvent {
  final String targetDeviceId;
  final String targetUserId;
  final ConnectionType type;
  final ConnectionConfig config;
  final bool isTrusted;
  RequestConnectionEvent({
    required this.targetDeviceId,
    required this.targetUserId,
    this.type = ConnectionType.screenShare,
    this.config = const ConnectionConfig(),
    this.isTrusted = false,
  });
}

class AcceptConnectionEvent extends ConnectionEvent {
  final ConnectionRequest request;
  AcceptConnectionEvent(this.request);
}

class RejectConnectionEvent extends ConnectionEvent {
  final String requestId;
  RejectConnectionEvent(this.requestId);
}

class DisconnectEvent extends ConnectionEvent {
  final String? reason;
  DisconnectEvent({this.reason});
}

class ConnectionEstablishedEvent extends ConnectionEvent {
  final ConnectionModel connection;
  ConnectionEstablishedEvent(this.connection);
}

class ConnectionFailedEvent extends ConnectionEvent {
  final String error;
  ConnectionFailedEvent(this.error);
}

class IncomingConnectionRequestEvent extends ConnectionEvent {
  final ConnectionRequest request;
  IncomingConnectionRequestEvent(this.request);
}

class UpdateMetricsEvent extends ConnectionEvent {
  final ConnectionMetrics metrics;
  UpdateMetricsEvent(this.metrics);
}

class ReconnectEvent extends ConnectionEvent {}

class WatchIncomingRequestsEvent extends ConnectionEvent {
  final String myDeviceId;
  WatchIncomingRequestsEvent(this.myDeviceId);
}

class AutoConnectTrustedEvent extends ConnectionEvent {
  final String targetDeviceId;
  final String targetUserId;
  AutoConnectTrustedEvent({required this.targetDeviceId, required this.targetUserId});
}
