// lib/features/connection/state/connection_state.dart
import '../model/connection_model.dart';
import '../model/connection_request.dart';

abstract class ConnectionState {}

class ConnectionInitial extends ConnectionState {}
class ConnectionIdle extends ConnectionState {}

class ConnectionRequesting extends ConnectionState {
  final String targetDeviceId;
  final String targetDeviceName;
  ConnectionRequesting({required this.targetDeviceId, required this.targetDeviceName});
}

class ConnectionIncoming extends ConnectionState {
  final ConnectionRequest request;
  ConnectionIncoming(this.request);
}

class ConnectionConnecting extends ConnectionState {
  final String targetDeviceId;
  ConnectionConnecting(this.targetDeviceId);
}

class ConnectionConnected extends ConnectionState {
  final ConnectionModel connection;
  final ConnectionMetrics metrics;
  ConnectionConnected({required this.connection, required this.metrics});

  ConnectionConnected copyWith({ConnectionModel? connection, ConnectionMetrics? metrics}) {
    return ConnectionConnected(
      connection: connection ?? this.connection,
      metrics: metrics ?? this.metrics,
    );
  }
}

class ConnectionDisconnecting extends ConnectionState {}

class ConnectionDisconnected extends ConnectionState {
  final String? reason;
  final Duration? sessionDuration;
  ConnectionDisconnected({this.reason, this.sessionDuration});
}

class ConnectionFailed extends ConnectionState {
  final String error;
  final bool canRetry;
  ConnectionFailed({required this.error, this.canRetry = true});
}

class ConnectionReconnecting extends ConnectionState {
  final int attempt;
  ConnectionReconnecting(this.attempt);
}

class AutoConnecting extends ConnectionState {
  final String targetDeviceId;
  AutoConnecting(this.targetDeviceId);
}
