// lib/features/connection/service/connection_service.dart
import 'dart:async';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import '../model/connection_model.dart';
import '../model/connection_request.dart';

class ConnectionService {
  final FirebaseDatabase _db;
  StreamSubscription? _requestSub;

  ConnectionService({FirebaseDatabase? db})
      : _db = db ?? FirebaseDatabase.instance;

  // Send connection request to target device
  Future<String> sendConnectionRequest({
    required String fromDeviceId,
    required String fromUserId,
    required String fromDeviceName,
    required String toDeviceId,
    required String toUserId,
    required String sessionType,
    bool autoAccept = false,
  }) async {
    final requestId = 'req_${DateTime.now().millisecondsSinceEpoch}';
    final request = ConnectionRequest(
      requestId: requestId,
      fromDeviceId: fromDeviceId,
      fromUserId: fromUserId,
      fromDeviceName: fromDeviceName,
      toDeviceId: toDeviceId,
      toUserId: toUserId,
      sessionType: sessionType,
      requestedAt: DateTime.now(),
      autoAccept: autoAccept,
    );
    await _db.ref('connection_requests/$toDeviceId').set(request.toMap());
    debugPrint('Connection request sent to $toDeviceId');
    return requestId;
  }

  // Watch for incoming connection requests
  Stream<ConnectionRequest?> watchIncomingRequests(String myDeviceId) {
    return _db.ref('connection_requests/$myDeviceId').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return null;
      try {
        return ConnectionRequest.fromMap(Map<String, dynamic>.from(data as Map));
      } catch (e) {
        debugPrint('Error parsing connection request: $e');
        return null;
      }
    });
  }

  // Accept connection request
  Future<void> acceptRequest(String myDeviceId, String requestId) async {
    await _db.ref('connection_requests/$myDeviceId').update({
      'status': 'accepted',
      'acceptedAt': DateTime.now().toIso8601String(),
    });
  }

  // Reject connection request
  Future<void> rejectRequest(String myDeviceId) async {
    await _db.ref('connection_requests/$myDeviceId').remove();
  }

  // Clear request after processing
  Future<void> clearRequest(String deviceId) async {
    await _db.ref('connection_requests/$deviceId').remove();
  }

  // Watch request status from sender side
  Stream<String?> watchRequestStatus(String targetDeviceId) {
    return _db.ref('connection_requests/$targetDeviceId/status').onValue.map(
      (event) => event.snapshot.value?.toString(),
    );
  }

  // Save active connection info
  Future<void> saveActiveConnection(ConnectionModel connection) async {
    await _db.ref('active_connections/${connection.connectionId}').set(connection.toMap());
  }

  // End active connection
  Future<void> endConnection(String connectionId) async {
    await _db.ref('active_connections/$connectionId').update({
      'status': ConnectionStatus.disconnected.name,
      'disconnectedAt': DateTime.now().toIso8601String(),
    });
    await Future.delayed(const Duration(seconds: 5));
    await _db.ref('active_connections/$connectionId').remove();
  }

  void dispose() {
    _requestSub?.cancel();
  }
}
