// lib/features/remote_control/repository/remote_control_repository.dart
import '../model/remote_control_model.dart';
import '../service/remote_control_service.dart';

class RemoteControlRepository {
  final RemoteControlService _service;
  RemoteControlRepository({RemoteControlService? service}) : _service = service ?? RemoteControlService();

  Future<void> sendTouch({required String targetDeviceId, required TouchEvent event}) =>
      _service.sendTouchEvent(targetDeviceId: targetDeviceId, event: event);

  Future<void> sendKey({required String targetDeviceId, required KeyEvent event}) =>
      _service.sendKeyEvent(targetDeviceId: targetDeviceId, event: event);

  Future<void> sendScroll({required String targetDeviceId, required double dx, required double dy}) =>
      _service.sendScrollEvent(targetDeviceId: targetDeviceId, dx: dx, dy: dy);

  Future<void> rotateScreen(String deviceId) => _service.rotateScreen(deviceId);

  Future<void> sendText({required String targetDeviceId, required String text}) =>
      _service.sendText(targetDeviceId: targetDeviceId, text: text);
}
