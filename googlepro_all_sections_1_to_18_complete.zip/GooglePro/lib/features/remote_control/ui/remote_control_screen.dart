// lib/features/remote_control/ui/remote_control_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../viewmodel/remote_control_bloc.dart';
import '../state/remote_control_event.dart';
import '../state/remote_control_state.dart';
import '../widget/remote_touch_surface.dart';
import '../widget/virtual_keyboard.dart';
import '../widget/system_buttons_bar.dart';

class RemoteControlScreen extends StatefulWidget {
  final String? targetDeviceId;
  final String? targetDeviceName;

  const RemoteControlScreen({
    super.key,
    this.targetDeviceId,
    this.targetDeviceName,
  });

  @override
  State<RemoteControlScreen> createState() => _RemoteControlScreenState();
}

class _RemoteControlScreenState extends State<RemoteControlScreen> {
  bool _showKeyboard = false;
  bool _controlsVisible = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: BlocConsumer<RemoteControlBloc, RemoteControlState>(
        listener: (context, state) {
          if (state is RemoteControlError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.message), backgroundColor: Colors.red),
            );
          }
        },
        builder: (context, state) {
          return Stack(
            children: [
              // Remote touch surface (full screen)
              RemoteTouchSurface(
                onTap: (x, y) => context.read<RemoteControlBloc>()
                    .add(SendTouchEvent(x: x, y: y, action: 'tap')),
                onScroll: (dx, dy) => context.read<RemoteControlBloc>()
                    .add(SendScrollEvent(dx: dx, dy: dy)),
                onLongPress: (x, y) => context.read<RemoteControlBloc>()
                    .add(SendTouchEvent(x: x, y: y, action: 'longPress')),
              ),

              // Top toolbar
              if (_controlsVisible)
                Positioned(
                  top: 0, left: 0, right: 0,
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter, end: Alignment.bottomCenter,
                        colors: [Colors.black87, Colors.transparent],
                      ),
                    ),
                    padding: EdgeInsets.fromLTRB(8, MediaQuery.of(context).padding.top + 8, 8, 16),
                    child: Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () => Navigator.pop(context),
                        ),
                        Expanded(
                          child: Text(
                            widget.targetDeviceName ?? 'Remote Control',
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                        ),
                        IconButton(
                          icon: Icon(_showKeyboard ? Icons.keyboard_hide : Icons.keyboard, color: Colors.white),
                          onPressed: () => setState(() => _showKeyboard = !_showKeyboard),
                        ),
                        IconButton(
                          icon: const Icon(Icons.screen_rotation, color: Colors.white),
                          onPressed: () => context.read<RemoteControlBloc>().add(RotateScreenEvent()),
                        ),
                      ],
                    ),
                  ),
                ),

              // System buttons at bottom
              if (_controlsVisible)
                Positioned(
                  bottom: 0, left: 0, right: 0,
                  child: SystemButtonsBar(
                    onBack: () => context.read<RemoteControlBloc>().add(SendKeyEvent(key: 'BACK')),
                    onHome: () => context.read<RemoteControlBloc>().add(SendKeyEvent(key: 'HOME')),
                    onRecents: () => context.read<RemoteControlBloc>().add(SendKeyEvent(key: 'RECENTS')),
                  ),
                ),

              // Virtual keyboard
              if (_showKeyboard)
                Positioned(
                  bottom: 60, left: 0, right: 0,
                  child: VirtualKeyboard(
                    onKey: (key) => context.read<RemoteControlBloc>().add(SendKeyEvent(key: key)),
                    onClose: () => setState(() => _showKeyboard = false),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
