// lib/features/remote_control/state/remote_control_state.dart
abstract class RemoteControlState {}
class RemoteControlIdle extends RemoteControlState {}
class RemoteControlActive extends RemoteControlState { final String targetDeviceId; RemoteControlActive(this.targetDeviceId); }
class RemoteControlEnded extends RemoteControlState {}
class RemoteControlError extends RemoteControlState { final String message; RemoteControlError(this.message); }
