// lib/features/remote_control/state/remote_control_event.dart
import '../model/remote_control_model.dart';
abstract class RemoteControlEvent {}
class InitRemoteControlEvent extends RemoteControlEvent { final String targetDeviceId; InitRemoteControlEvent(this.targetDeviceId); }
class SendTouchEvent extends RemoteControlEvent { final double x; final double y; final String action; SendTouchEvent({required this.x, required this.y, required this.action}); }
class SendScrollEvent extends RemoteControlEvent { final double dx; final double dy; SendScrollEvent({required this.dx, required this.dy}); }
class SendKeyEvent extends RemoteControlEvent { final String key; SendKeyEvent({required this.key}); }
class SendTextEvent extends RemoteControlEvent { final String text; SendTextEvent(this.text); }
class RotateScreenEvent extends RemoteControlEvent {}
class EndRemoteControlEvent extends RemoteControlEvent {}
