// lib/features/remote_control/model/remote_control_model.dart

enum TouchAction { tap, longPress, swipe, scroll, doubleTap }

class TouchEvent {
  final TouchAction action;
  final double x;
  final double y;
  final double? dx;
  final double? dy;
  final DateTime timestamp;

  const TouchEvent({
    required this.action,
    required this.x,
    required this.y,
    this.dx,
    this.dy,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
    'action': action.name, 'x': x, 'y': y,
    'dx': dx, 'dy': dy,
    'timestamp': timestamp.millisecondsSinceEpoch,
  };
}

class KeyEvent {
  final String key;
  final bool isSpecial;
  final DateTime timestamp;

  const KeyEvent({required this.key, this.isSpecial = false, required this.timestamp});

  Map<String, dynamic> toMap() => {
    'key': key, 'isSpecial': isSpecial,
    'timestamp': timestamp.millisecondsSinceEpoch,
  };
}

class RemoteControlSession {
  final String sessionId;
  final String controllerDeviceId;
  final String targetDeviceId;
  final bool isActive;
  final DateTime startedAt;

  const RemoteControlSession({
    required this.sessionId,
    required this.controllerDeviceId,
    required this.targetDeviceId,
    this.isActive = true,
    required this.startedAt,
  });
}
