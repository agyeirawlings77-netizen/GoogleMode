// lib/features/remote_control/viewmodel/remote_control_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import '../model/remote_control_model.dart';
import '../repository/remote_control_repository.dart';
import '../state/remote_control_event.dart';
import '../state/remote_control_state.dart';

class RemoteControlBloc extends Bloc<RemoteControlEvent, RemoteControlState> {
  final RemoteControlRepository repository;
  String? _targetDeviceId;

  RemoteControlBloc({required this.repository}) : super(RemoteControlIdle()) {
    on<InitRemoteControlEvent>(_onInit);
    on<SendTouchEvent>(_onTouch);
    on<SendScrollEvent>(_onScroll);
    on<SendKeyEvent>(_onKey);
    on<SendTextEvent>(_onText);
    on<RotateScreenEvent>(_onRotate);
    on<EndRemoteControlEvent>(_onEnd);
  }

  void _onInit(InitRemoteControlEvent e, Emitter<RemoteControlState> emit) {
    _targetDeviceId = e.targetDeviceId;
    emit(RemoteControlActive(e.targetDeviceId));
  }

  Future<void> _onTouch(SendTouchEvent e, Emitter<RemoteControlState> emit) async {
    if (_targetDeviceId == null) return;
    try {
      await repository.sendTouch(
        targetDeviceId: _targetDeviceId!,
        event: TouchEvent(
          action: TouchAction.values.firstWhere((a) => a.name == e.action, orElse: () => TouchAction.tap),
          x: e.x, y: e.y, timestamp: DateTime.now(),
        ),
      );
    } catch (err) { emit(RemoteControlError(err.toString())); }
  }

  Future<void> _onScroll(SendScrollEvent e, Emitter<RemoteControlState> emit) async {
    if (_targetDeviceId == null) return;
    try {
      await repository.sendScroll(targetDeviceId: _targetDeviceId!, dx: e.dx, dy: e.dy);
    } catch (err) { emit(RemoteControlError(err.toString())); }
  }

  Future<void> _onKey(SendKeyEvent e, Emitter<RemoteControlState> emit) async {
    if (_targetDeviceId == null) return;
    try {
      await repository.sendKey(
        targetDeviceId: _targetDeviceId!,
        event: KeyEvent(key: e.key, isSpecial: true, timestamp: DateTime.now()),
      );
    } catch (err) { emit(RemoteControlError(err.toString())); }
  }

  Future<void> _onText(SendTextEvent e, Emitter<RemoteControlState> emit) async {
    if (_targetDeviceId == null) return;
    try {
      await repository.sendText(targetDeviceId: _targetDeviceId!, text: e.text);
    } catch (err) { emit(RemoteControlError(err.toString())); }
  }

  Future<void> _onRotate(RotateScreenEvent e, Emitter<RemoteControlState> emit) async {
    if (_targetDeviceId == null) return;
    try {
      await repository.rotateScreen(_targetDeviceId!);
    } catch (err) { emit(RemoteControlError(err.toString())); }
  }

  void _onEnd(EndRemoteControlEvent e, Emitter<RemoteControlState> emit) {
    _targetDeviceId = null;
    emit(RemoteControlEnded());
  }
}
