// lib/features/remote_control/widget/virtual_keyboard.dart
import 'package:flutter/material.dart';

class VirtualKeyboard extends StatelessWidget {
  final void Function(String key) onKey;
  final VoidCallback onClose;

  const VirtualKeyboard({super.key, required this.onKey, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.grey[900],
      padding: const EdgeInsets.all(8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: onClose),
            ],
          ),
          TextField(
            autofocus: true,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              hintText: 'Type to send to remote device...',
              hintStyle: TextStyle(color: Colors.white54),
              filled: true,
              fillColor: Colors.black26,
              border: OutlineInputBorder(),
            ),
            onSubmitted: (v) { if (v.isNotEmpty) onKey(v); },
          ),
          const SizedBox(height: 8),
          // Special keys
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _specialKey('ESC', 'ESCAPE'),
              _specialKey('TAB', 'TAB'),
              _specialKey('⌫', 'BACKSPACE'),
              _specialKey('↵', 'ENTER'),
              _specialKey('⌘', 'HOME'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _specialKey(String label, String key) {
    return Builder(builder: (context) => GestureDetector(
      onTap: () => onKey(key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.grey[700],
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    ));
  }
}
