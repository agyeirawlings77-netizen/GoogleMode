// lib/features/remote_control/widget/remote_touch_surface.dart
import 'package:flutter/material.dart';

class RemoteTouchSurface extends StatelessWidget {
  final void Function(double x, double y) onTap;
  final void Function(double dx, double dy) onScroll;
  final void Function(double x, double y) onLongPress;

  const RemoteTouchSurface({
    super.key,
    required this.onTap,
    required this.onScroll,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapUp: (d) {
        final box = context.findRenderObject() as RenderBox?;
        if (box != null) {
          final size = box.size;
          onTap(d.localPosition.dx / size.width, d.localPosition.dy / size.height);
        }
      },
      onLongPressStart: (d) {
        final box = context.findRenderObject() as RenderBox?;
        if (box != null) {
          final size = box.size;
          onLongPress(d.localPosition.dx / size.width, d.localPosition.dy / size.height);
        }
      },
      onPanUpdate: (d) {
        onScroll(d.delta.dx, d.delta.dy);
      },
      child: Container(
        color: Colors.black,
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.touch_app, size: 64, color: Colors.white12),
              SizedBox(height: 8),
              Text('Touch to control', style: TextStyle(color: Colors.white12)),
            ],
          ),
        ),
      ),
    );
  }
}
