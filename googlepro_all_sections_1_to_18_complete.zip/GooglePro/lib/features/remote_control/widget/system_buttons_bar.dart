// lib/features/remote_control/widget/system_buttons_bar.dart
import 'package:flutter/material.dart';

class SystemButtonsBar extends StatelessWidget {
  final VoidCallback onBack;
  final VoidCallback onHome;
  final VoidCallback onRecents;

  const SystemButtonsBar({
    super.key,
    required this.onBack,
    required this.onHome,
    required this.onRecents,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [Colors.black87, Colors.transparent],
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _navBtn(Icons.arrow_back, 'Back', onBack),
          _navBtn(Icons.circle_outlined, 'Home', onHome),
          _navBtn(Icons.crop_square, 'Recents', onRecents),
        ],
      ),
    );
  }

  Widget _navBtn(IconData icon, String label, VoidCallback onTap) {
    return IconButton(
      icon: Icon(icon, color: Colors.white, size: 28),
      onPressed: onTap,
      tooltip: label,
    );
  }
}
