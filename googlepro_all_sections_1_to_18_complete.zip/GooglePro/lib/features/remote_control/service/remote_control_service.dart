// lib/features/remote_control/service/remote_control_service.dart
import 'dart:convert';
import 'package:firebase_database/firebase_database.dart';
import '../model/remote_control_model.dart';

class RemoteControlService {
  final FirebaseDatabase _db;
  RemoteControlService({FirebaseDatabase? db}) : _db = db ?? FirebaseDatabase.instance;

  Future<void> sendTouchEvent({required String targetDeviceId, required TouchEvent event}) async {
    await _db.ref('remote_control/$targetDeviceId/touch').push().set(event.toMap());
  }

  Future<void> sendKeyEvent({required String targetDeviceId, required KeyEvent event}) async {
    await _db.ref('remote_control/$targetDeviceId/key').set(event.toMap());
  }

  Future<void> sendScrollEvent({required String targetDeviceId, required double dx, required double dy}) async {
    await _db.ref('remote_control/$targetDeviceId/scroll').set({
      'dx': dx, 'dy': dy,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<void> rotateScreen(String targetDeviceId) async {
    await _db.ref('remote_control/$targetDeviceId/command').set({
      'type': 'rotate', 'timestamp': ServerValue.timestamp,
    });
  }

  Future<void> sendText({required String targetDeviceId, required String text}) async {
    await _db.ref('remote_control/$targetDeviceId/text').set({
      'text': text, 'timestamp': ServerValue.timestamp,
    });
  }

  Future<void> clearRemoteControl(String deviceId) async {
    await _db.ref('remote_control/$deviceId').remove();
  }

  Stream<Map<String, dynamic>?> watchCommands(String myDeviceId) {
    return _db.ref('remote_control/$myDeviceId').onChildAdded.map((event) {
      final data = event.snapshot.value;
      if (data == null) return null;
      return {'key': event.snapshot.key, 'data': Map<String, dynamic>.from(data as Map)};
    });
  }
}
