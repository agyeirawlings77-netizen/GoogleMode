// lib/features/analytics/viewmodel/analytics_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import '../service/analytics_tracker_service.dart';
import '../state/analytics_event.dart';
import '../state/analytics_state.dart';

class AnalyticsBloc extends Bloc<AnalyticsEvent, AnalyticsState> {
  final AnalyticsTrackerService service;

  AnalyticsBloc({required this.service}) : super(AnalyticsInitial()) {
    on<LoadAnalyticsEvent>(_onLoad);
    on<RefreshAnalyticsEvent>(_onRefresh);
    on<ClearAnalyticsEvent>(_onClear);
  }

  Future<void> _onLoad(
      LoadAnalyticsEvent event, Emitter<AnalyticsState> emit) async {
    emit(AnalyticsLoading());
    try {
      final stats = await service.getUsageStats();
      final events = await service.getRecentEvents();
      emit(AnalyticsLoaded(stats: stats, recentEvents: events));
    } catch (e) {
      emit(AnalyticsError(e.toString()));
    }
  }

  Future<void> _onRefresh(
      RefreshAnalyticsEvent event, Emitter<AnalyticsState> emit) async {
    try {
      final stats = await service.getUsageStats();
      final events = await service.getRecentEvents();
      emit(AnalyticsLoaded(stats: stats, recentEvents: events));
    } catch (e) {
      emit(AnalyticsError(e.toString()));
    }
  }

  Future<void> _onClear(
      ClearAnalyticsEvent event, Emitter<AnalyticsState> emit) async {
    await service.clearAllData();
    emit(AnalyticsCleared());
  }
}
