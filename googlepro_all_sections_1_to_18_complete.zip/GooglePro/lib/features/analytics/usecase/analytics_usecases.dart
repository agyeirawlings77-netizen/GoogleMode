// lib/features/analytics/usecase/analytics_usecases.dart
import '../model/analytics_event_model.dart';
import '../model/usage_stats_model.dart';
import '../repository/analytics_repository.dart';
import '../service/analytics_tracker_service.dart';

class TrackEventUseCase {
  final AnalyticsTrackerService service;
  final AnalyticsRepository repository;

  TrackEventUseCase({required this.service, required this.repository});

  Future<void> execute(AnalyticsEventModel event) async {
    service.track(event);
    await repository.saveEvent(event);
  }
}

class GetEventsUseCase {
  final AnalyticsRepository repository;
  GetEventsUseCase(this.repository);
  Future<List<AnalyticsEventModel>> execute({int limit = 50}) =>
      repository.getEvents(limit: limit);
}

class GetUsageStatsUseCase {
  final AnalyticsRepository repository;
  GetUsageStatsUseCase(this.repository);
  Future<UsageStatsModel?> execute() => repository.getUsageStats();
}

class ClearAnalyticsUseCase {
  final AnalyticsRepository repository;
  ClearAnalyticsUseCase(this.repository);
  Future<void> execute() => repository.clearAll();
}
