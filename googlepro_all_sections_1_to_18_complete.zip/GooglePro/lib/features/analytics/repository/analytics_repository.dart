// lib/features/analytics/repository/analytics_repository.dart
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../model/analytics_event_model.dart';
import '../model/usage_stats_model.dart';

class AnalyticsRepository {
  static const _eventsKey = 'analytics_events';
  static const _statsKey = 'analytics_stats';

  Future<void> saveEvent(AnalyticsEventModel event) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_eventsKey);
    final List<dynamic> list = raw != null ? jsonDecode(raw) : [];
    list.insert(0, event.toMap());
    if (list.length > 500) list.removeLast();
    await prefs.setString(_eventsKey, jsonEncode(list));
  }

  Future<List<AnalyticsEventModel>> getEvents({int limit = 50}) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_eventsKey);
    if (raw == null) return [];
    final List<dynamic> list = jsonDecode(raw);
    return list
        .take(limit)
        .map((e) =>
            AnalyticsEventModel.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> saveUsageStats(UsageStatsModel stats) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_statsKey, jsonEncode(stats.toMap()));
  }

  Future<UsageStatsModel?> getUsageStats() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_statsKey);
    if (raw == null) return null;
    return UsageStatsModel.fromMap(jsonDecode(raw));
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_eventsKey);
    await prefs.remove(_statsKey);
  }
}
