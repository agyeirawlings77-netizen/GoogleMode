// lib/features/analytics/ui/analytics_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../viewmodel/analytics_bloc.dart';
import '../state/analytics_event.dart';
import '../state/analytics_state.dart';
import '../model/usage_stats_model.dart';
import '../model/analytics_event_model.dart';
import '../widget/stats_overview_card.dart';
import '../widget/feature_usage_chart.dart';
import '../widget/recent_events_list.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  @override
  void initState() {
    super.initState();
    context.read<AnalyticsBloc>().add(LoadAnalyticsEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Analytics & Usage'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () =>
                context.read<AnalyticsBloc>().add(RefreshAnalyticsEvent()),
          ),
          PopupMenuButton(
            itemBuilder: (_) => [
              const PopupMenuItem(
                value: 'clear',
                child: Row(
                  children: [
                    Icon(Icons.delete_outline, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Clear Data', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
            onSelected: (v) {
              if (v == 'clear') _confirmClear(context);
            },
          ),
        ],
      ),
      body: BlocBuilder<AnalyticsBloc, AnalyticsState>(
        builder: (context, state) {
          if (state is AnalyticsLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state is AnalyticsError) {
            return Center(child: Text(state.message));
          }
          if (state is AnalyticsLoaded) {
            return _buildContent(state.stats, state.recentEvents);
          }
          return const Center(child: CircularProgressIndicator());
        },
      ),
    );
  }

  Widget _buildContent(
      UsageStatsModel stats, List<AnalyticsEventModel> events) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        StatsOverviewCard(stats: stats),
        const SizedBox(height: 12),
        if (stats.featureUsageCount.isNotEmpty) ...[
          FeatureUsageChart(featureUsage: stats.featureUsageCount),
          const SizedBox(height: 12),
        ],
        RecentEventsList(events: events),
      ],
    );
  }

  void _confirmClear(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear Analytics'),
        content: const Text(
            'This will delete all local analytics data. Are you sure?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.read<AnalyticsBloc>().add(ClearAnalyticsEvent());
            },
            child: const Text('Clear', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
