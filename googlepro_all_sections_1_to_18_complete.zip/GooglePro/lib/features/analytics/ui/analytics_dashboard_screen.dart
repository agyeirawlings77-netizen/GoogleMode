// lib/features/analytics/ui/analytics_dashboard_screen.dart
import "package:flutter/material.dart";
class AnalyticsDashboardScreen extends StatelessWidget { const AnalyticsDashboardScreen({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("Analytics")), body: const Center(child: Text("Analytics coming soon"))); }