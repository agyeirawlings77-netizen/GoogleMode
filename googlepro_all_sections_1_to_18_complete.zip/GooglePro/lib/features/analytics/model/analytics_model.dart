// lib/features/analytics/model/analytics_model.dart

class AnalyticsData {
  final int totalSessions;
  final int totalDevices;
  final int totalMinutes;
  final int totalFileTransfers;
  final Map<String, int> sessionsByType;
  final Map<String, int> sessionsByDay;
  final List<Map<String, dynamic>> recentActivity;
  final DateTime? lastUpdated;

  const AnalyticsData({
    this.totalSessions = 0, this.totalDevices = 0,
    this.totalMinutes = 0, this.totalFileTransfers = 0,
    this.sessionsByType = const {}, this.sessionsByDay = const {},
    this.recentActivity = const [], this.lastUpdated,
  });

  String get totalTimeLabel {
    final h = totalMinutes ~/ 60;
    final m = totalMinutes % 60;
    if (h > 0) return '${h}h ${m}m';
    return '${m}m';
  }

  factory AnalyticsData.fromMap(Map<String, dynamic> m) => AnalyticsData(
    totalSessions: m['totalSessions'] ?? 0,
    totalDevices: m['totalDevices'] ?? 0,
    totalMinutes: m['totalMinutes'] ?? 0,
    totalFileTransfers: m['totalFileTransfers'] ?? 0,
    sessionsByType: Map<String, int>.from(m['sessionsByType'] ?? {}),
    sessionsByDay: Map<String, int>.from(m['sessionsByDay'] ?? {}),
    lastUpdated: m['lastUpdated'] != null ? DateTime.tryParse(m['lastUpdated'].toString()) : null,
  );
}
