// lib/features/analytics/model/analytics_event_model.dart

enum AnalyticsEventType {
  sessionStarted,
  sessionEnded,
  deviceConnected,
  deviceDisconnected,
  screenShareStarted,
  screenShareStopped,
  fileTransferred,
  messageSent,
  alarmTriggered,
  locationShared,
  loginSuccess,
  loginFailed,
  appOpened,
  featureUsed,
  errorOccurred,
}

class AnalyticsEventModel {
  final String eventId;
  final AnalyticsEventType type;
  final String userId;
  final String? deviceId;
  final Map<String, dynamic> parameters;
  final DateTime timestamp;
  final String? sessionId;

  const AnalyticsEventModel({
    required this.eventId,
    required this.type,
    required this.userId,
    this.deviceId,
    this.parameters = const {},
    required this.timestamp,
    this.sessionId,
  });

  factory AnalyticsEventModel.create({
    required AnalyticsEventType type,
    required String userId,
    String? deviceId,
    Map<String, dynamic> parameters = const {},
    String? sessionId,
  }) {
    return AnalyticsEventModel(
      eventId: DateTime.now().microsecondsSinceEpoch.toString(),
      type: type,
      userId: userId,
      deviceId: deviceId,
      parameters: parameters,
      timestamp: DateTime.now(),
      sessionId: sessionId,
    );
  }

  Map<String, dynamic> toMap() => {
        'eventId': eventId,
        'type': type.name,
        'userId': userId,
        'deviceId': deviceId,
        'parameters': parameters,
        'timestamp': timestamp.toIso8601String(),
        'sessionId': sessionId,
      };

  factory AnalyticsEventModel.fromMap(Map<String, dynamic> map) {
    return AnalyticsEventModel(
      eventId: map['eventId'] ?? '',
      type: AnalyticsEventType.values.firstWhere(
        (e) => e.name == map['type'],
        orElse: () => AnalyticsEventType.featureUsed,
      ),
      userId: map['userId'] ?? '',
      deviceId: map['deviceId'],
      parameters: Map<String, dynamic>.from(map['parameters'] ?? {}),
      timestamp: map['timestamp'] != null
          ? DateTime.parse(map['timestamp'])
          : DateTime.now(),
      sessionId: map['sessionId'],
    );
  }
}
