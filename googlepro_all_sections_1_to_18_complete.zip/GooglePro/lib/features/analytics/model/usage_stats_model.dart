// lib/features/analytics/model/usage_stats_model.dart

class UsageStatsModel {
  final int totalSessions;
  final Duration totalSessionTime;
  final int totalDevicesConnected;
  final int totalFilesTransferred;
  final int totalMessagesSent;
  final int totalAlarmsTriggered;
  final Map<String, int> featureUsageCount;
  final DateTime periodStart;
  final DateTime periodEnd;

  const UsageStatsModel({
    this.totalSessions = 0,
    this.totalSessionTime = Duration.zero,
    this.totalDevicesConnected = 0,
    this.totalFilesTransferred = 0,
    this.totalMessagesSent = 0,
    this.totalAlarmsTriggered = 0,
    this.featureUsageCount = const {},
    required this.periodStart,
    required this.periodEnd,
  });

  String get totalTimeFormatted {
    final h = totalSessionTime.inHours;
    final m = totalSessionTime.inMinutes % 60;
    return '${h}h ${m}m';
  }

  int get mostUsedFeatureCount {
    if (featureUsageCount.isEmpty) return 0;
    return featureUsageCount.values
        .reduce((a, b) => a > b ? a : b);
  }

  String get mostUsedFeature {
    if (featureUsageCount.isEmpty) return 'None';
    return featureUsageCount.entries
        .reduce((a, b) => a.value > b.value ? a : b)
        .key;
  }

  factory UsageStatsModel.empty() => UsageStatsModel(
        periodStart: DateTime.now().subtract(const Duration(days: 30)),
        periodEnd: DateTime.now(),
      );

  factory UsageStatsModel.fromMap(Map<String, dynamic> map) {
    return UsageStatsModel(
      totalSessions: map['totalSessions'] ?? 0,
      totalSessionTime:
          Duration(seconds: map['totalSessionSeconds'] ?? 0),
      totalDevicesConnected: map['totalDevicesConnected'] ?? 0,
      totalFilesTransferred: map['totalFilesTransferred'] ?? 0,
      totalMessagesSent: map['totalMessagesSent'] ?? 0,
      totalAlarmsTriggered: map['totalAlarmsTriggered'] ?? 0,
      featureUsageCount: Map<String, int>.from(
          map['featureUsageCount'] ?? {}),
      periodStart: map['periodStart'] != null
          ? DateTime.parse(map['periodStart'])
          : DateTime.now().subtract(const Duration(days: 30)),
      periodEnd: map['periodEnd'] != null
          ? DateTime.parse(map['periodEnd'])
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => {
        'totalSessions': totalSessions,
        'totalSessionSeconds': totalSessionTime.inSeconds,
        'totalDevicesConnected': totalDevicesConnected,
        'totalFilesTransferred': totalFilesTransferred,
        'totalMessagesSent': totalMessagesSent,
        'totalAlarmsTriggered': totalAlarmsTriggered,
        'featureUsageCount': featureUsageCount,
        'periodStart': periodStart.toIso8601String(),
        'periodEnd': periodEnd.toIso8601String(),
      };
}
