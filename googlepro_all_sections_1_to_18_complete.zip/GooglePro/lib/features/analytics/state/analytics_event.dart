// lib/features/analytics/state/analytics_event.dart
abstract class AnalyticsEvent {}

class LoadAnalyticsEvent extends AnalyticsEvent {}
class RefreshAnalyticsEvent extends AnalyticsEvent {}
class ClearAnalyticsEvent extends AnalyticsEvent {}
class ExportAnalyticsEvent extends AnalyticsEvent {}
