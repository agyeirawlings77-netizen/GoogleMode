// lib/features/analytics/state/analytics_state.dart
import '../model/usage_stats_model.dart';
import '../model/analytics_event_model.dart';

abstract class AnalyticsState {}

class AnalyticsInitial extends AnalyticsState {}
class AnalyticsLoading extends AnalyticsState {}

class AnalyticsLoaded extends AnalyticsState {
  final UsageStatsModel stats;
  final List<AnalyticsEventModel> recentEvents;
  AnalyticsLoaded({required this.stats, required this.recentEvents});
}

class AnalyticsCleared extends AnalyticsState {}
class AnalyticsError extends AnalyticsState {
  final String message;
  AnalyticsError(this.message);
}
