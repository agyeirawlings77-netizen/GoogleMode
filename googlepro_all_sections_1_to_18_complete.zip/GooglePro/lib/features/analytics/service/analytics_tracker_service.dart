// lib/features/analytics/service/analytics_tracker_service.dart
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../model/analytics_event_model.dart';
import '../model/usage_stats_model.dart';

class AnalyticsTrackerService {
  final FirebaseAnalytics _firebase;
  static const _statsKey = 'local_usage_stats';
  static const _eventsKey = 'local_events';

  AnalyticsTrackerService({FirebaseAnalytics? firebase})
      : _firebase = firebase ?? FirebaseAnalytics.instance;

  /// Track event to Firebase + local storage
  Future<void> trackEvent(AnalyticsEventModel event) async {
    try {
      // Firebase Analytics
      await _firebase.logEvent(
        name: event.type.name,
        parameters: {
          'user_id': event.userId,
          if (event.deviceId != null) 'device_id': event.deviceId!,
          if (event.sessionId != null) 'session_id': event.sessionId!,
          ...event.parameters.map(
              (k, v) => MapEntry(k, v.toString())),
        },
      );

      // Save locally
      await _saveEventLocally(event);

      // Update usage stats
      await _updateLocalStats(event);
    } catch (e) {
      // Never crash the app due to analytics
    }
  }

  Future<void> _saveEventLocally(AnalyticsEventModel event) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_eventsKey);
    final List<dynamic> events =
        raw != null ? jsonDecode(raw) : [];
    events.insert(0, event.toMap());
    if (events.length > 200) events.removeLast();
    await prefs.setString(_eventsKey, jsonEncode(events));
  }

  Future<void> _updateLocalStats(AnalyticsEventModel event) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_statsKey);
    Map<String, dynamic> stats =
        raw != null ? jsonDecode(raw) : {};

    switch (event.type) {
      case AnalyticsEventType.sessionStarted:
        stats['totalSessions'] = (stats['totalSessions'] ?? 0) + 1;
        break;
      case AnalyticsEventType.sessionEnded:
        final secs =
            event.parameters['durationSeconds'] as int? ?? 0;
        stats['totalSessionSeconds'] =
            (stats['totalSessionSeconds'] ?? 0) + secs;
        break;
      case AnalyticsEventType.deviceConnected:
        stats['totalDevicesConnected'] =
            (stats['totalDevicesConnected'] ?? 0) + 1;
        break;
      case AnalyticsEventType.fileTransferred:
        stats['totalFilesTransferred'] =
            (stats['totalFilesTransferred'] ?? 0) + 1;
        break;
      case AnalyticsEventType.messageSent:
        stats['totalMessagesSent'] =
            (stats['totalMessagesSent'] ?? 0) + 1;
        break;
      case AnalyticsEventType.alarmTriggered:
        stats['totalAlarmsTriggered'] =
            (stats['totalAlarmsTriggered'] ?? 0) + 1;
        break;
      case AnalyticsEventType.featureUsed:
        final feature = event.parameters['feature'] as String? ?? 'unknown';
        final featureMap = Map<String, dynamic>.from(
            stats['featureUsageCount'] ?? {});
        featureMap[feature] = (featureMap[feature] ?? 0) + 1;
        stats['featureUsageCount'] = featureMap;
        break;
      default:
        break;
    }

    stats['periodStart'] ??= DateTime.now()
        .subtract(const Duration(days: 30))
        .toIso8601String();
    stats['periodEnd'] = DateTime.now().toIso8601String();

    await prefs.setString(_statsKey, jsonEncode(stats));
  }

  Future<UsageStatsModel> getUsageStats() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_statsKey);
    if (raw == null) return UsageStatsModel.empty();
    return UsageStatsModel.fromMap(jsonDecode(raw));
  }

  Future<List<AnalyticsEventModel>> getRecentEvents(
      {int limit = 50}) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_eventsKey);
    if (raw == null) return [];
    final List<dynamic> list = jsonDecode(raw);
    return list
        .take(limit)
        .map((e) =>
            AnalyticsEventModel.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> clearAllData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_statsKey);
    await prefs.remove(_eventsKey);
  }

  // Convenience methods
  Future<void> trackScreenShare(
          String userId, String deviceId, bool started) =>
      trackEvent(AnalyticsEventModel.create(
        type: started
            ? AnalyticsEventType.screenShareStarted
            : AnalyticsEventType.screenShareStopped,
        userId: userId,
        deviceId: deviceId,
      ));

  Future<void> trackSession(
          String userId, String deviceId, String sessionId,
          {int? durationSeconds}) =>
      trackEvent(AnalyticsEventModel.create(
        type: durationSeconds != null
            ? AnalyticsEventType.sessionEnded
            : AnalyticsEventType.sessionStarted,
        userId: userId,
        deviceId: deviceId,
        sessionId: sessionId,
        parameters: durationSeconds != null
            ? {'durationSeconds': durationSeconds}
            : {},
      ));

  Future<void> trackFeatureUsed(String userId, String featureName) =>
      trackEvent(AnalyticsEventModel.create(
        type: AnalyticsEventType.featureUsed,
        userId: userId,
        parameters: {'feature': featureName},
      ));
}
