// lib/features/analytics/widget/recent_events_list.dart
import 'package:flutter/material.dart';
import '../model/analytics_event_model.dart';

class RecentEventsList extends StatelessWidget {
  final List<AnalyticsEventModel> events;
  const RecentEventsList({super.key, required this.events});

  IconData _iconFor(AnalyticsEventType type) {
    switch (type) {
      case AnalyticsEventType.sessionStarted:
      case AnalyticsEventType.sessionEnded:
        return Icons.screen_share;
      case AnalyticsEventType.deviceConnected:
      case AnalyticsEventType.deviceDisconnected:
        return Icons.devices;
      case AnalyticsEventType.fileTransferred:
        return Icons.folder;
      case AnalyticsEventType.messageSent:
        return Icons.chat;
      case AnalyticsEventType.alarmTriggered:
        return Icons.alarm;
      case AnalyticsEventType.locationShared:
        return Icons.location_on;
      case AnalyticsEventType.loginSuccess:
      case AnalyticsEventType.loginFailed:
        return Icons.login;
      default:
        return Icons.analytics;
    }
  }

  Color _colorFor(AnalyticsEventType type) {
    switch (type) {
      case AnalyticsEventType.loginFailed:
      case AnalyticsEventType.errorOccurred:
        return Colors.red;
      case AnalyticsEventType.sessionStarted:
      case AnalyticsEventType.deviceConnected:
      case AnalyticsEventType.loginSuccess:
        return Colors.green;
      case AnalyticsEventType.alarmTriggered:
        return Colors.orange;
      default:
        return Colors.blue;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (events.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Center(
              child: Text('No recent events',
                  style: TextStyle(color: Colors.grey))),
        ),
      );
    }
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text('Recent Events',
                style: TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 18)),
          ),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: events.length > 20 ? 20 : events.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final event = events[index];
              return ListTile(
                dense: true,
                leading: CircleAvatar(
                  radius: 16,
                  backgroundColor:
                      _colorFor(event.type).withOpacity(0.15),
                  child: Icon(_iconFor(event.type),
                      size: 16, color: _colorFor(event.type)),
                ),
                title: Text(
                  event.type.name
                      .replaceAllMapped(RegExp(r'[A-Z]'),
                          (m) => ' ${m.group(0)}')
                      .trim(),
                  style: const TextStyle(fontSize: 13),
                ),
                subtitle: Text(
                  _formatTime(event.timestamp),
                  style:
                      const TextStyle(fontSize: 11, color: Colors.grey),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}
