// lib/features/analytics/widget/stats_overview_card.dart
import 'package:flutter/material.dart';
import '../model/usage_stats_model.dart';

class StatsOverviewCard extends StatelessWidget {
  final UsageStatsModel stats;
  const StatsOverviewCard({super.key, required this.stats});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Overview',
                style: TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 1.2,
              children: [
                _statItem('Sessions', '${stats.totalSessions}',
                    Icons.screen_share, Colors.blue),
                _statItem('Time', stats.totalTimeFormatted,
                    Icons.access_time, Colors.green),
                _statItem('Devices', '${stats.totalDevicesConnected}',
                    Icons.devices, Colors.orange),
                _statItem('Files', '${stats.totalFilesTransferred}',
                    Icons.folder, Colors.purple),
                _statItem('Messages', '${stats.totalMessagesSent}',
                    Icons.chat, Colors.teal),
                _statItem('Alarms', '${stats.totalAlarmsTriggered}',
                    Icons.alarm, Colors.red),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statItem(
      String label, String value, IconData icon, Color color) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color, size: 24),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(
                fontWeight: FontWeight.bold, fontSize: 16)),
        Text(label,
            style: const TextStyle(fontSize: 11, color: Colors.grey)),
      ],
    );
  }
}
