// lib/features/dashboard/viewmodel/dashboard_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import '../model/dashboard_stats.dart';
import '../state/dashboard_event.dart';
import '../state/dashboard_state.dart';

class DashboardBloc extends Bloc<DashboardEvent, DashboardState> {
  DashboardBloc() : super(DashboardInitial()) {
    on<LoadDashboardEvent>(_onLoad);
    on<RefreshDashboardEvent>(_onRefresh);
    on<UpdateDashboardStatsEvent>(_onUpdate);
  }

  Future<void> _onLoad(LoadDashboardEvent event, Emitter<DashboardState> emit) async {
    emit(DashboardLoading());
    await Future.delayed(const Duration(milliseconds: 600));
    emit(DashboardLoaded(
      stats: const DashboardStats(
        totalDevices: 3,
        onlineDevices: 1,
        totalSessions: 24,
        totalTime: '12h 34m',
        unreadNotifications: 2,
        trustedDevices: 2,
      ),
      recentSessions: [
        {'targetDeviceName': 'Samsung S23', 'sessionType': 'screen_share', 'durationSeconds': 320, 'status': 'ended', 'createdAt': DateTime.now().subtract(const Duration(minutes: 5)).toIso8601String()},
        {'targetDeviceName': 'iPhone 15', 'sessionType': 'remote_control', 'durationSeconds': 120, 'status': 'ended', 'createdAt': DateTime.now().subtract(const Duration(hours: 2)).toIso8601String()},
        {'targetDeviceName': 'Xiaomi Note', 'sessionType': 'voice_call', 'durationSeconds': 60, 'status': 'ended', 'createdAt': DateTime.now().subtract(const Duration(days: 1)).toIso8601String()},
      ],
    ));
  }

  Future<void> _onRefresh(RefreshDashboardEvent event, Emitter<DashboardState> emit) async {
    add(LoadDashboardEvent());
  }

  void _onUpdate(UpdateDashboardStatsEvent event, Emitter<DashboardState> emit) {
    if (state is DashboardLoaded) {
      final current = state as DashboardLoaded;
      emit(DashboardLoaded(
        stats: DashboardStats.fromMap(event.stats),
        recentSessions: current.recentSessions,
      ));
    }
  }
}
