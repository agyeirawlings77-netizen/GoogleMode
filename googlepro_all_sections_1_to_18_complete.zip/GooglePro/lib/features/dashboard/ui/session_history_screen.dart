// lib/features/dashboard/ui/session_history_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../session/viewmodel/session_bloc.dart';
import '../../session/state/session_event.dart';
import '../../session/state/session_state.dart';

class SessionHistoryScreen extends StatefulWidget {
  const SessionHistoryScreen({super.key});
  @override
  State<SessionHistoryScreen> createState() => _SessionHistoryScreenState();
}

class _SessionHistoryScreenState extends State<SessionHistoryScreen> {
  @override
  void initState() {
    super.initState();
    context.read<SessionBloc>().add(LoadSessionHistoryEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Session History')),
      body: BlocBuilder<SessionBloc, SessionState>(
        builder: (context, state) {
          if (state is SessionLoading) return const Center(child: CircularProgressIndicator());
          if (state is SessionHistoryLoaded && state.sessions.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.history, size: 80, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('No sessions yet', style: TextStyle(fontSize: 18, color: Colors.grey)),
                ],
              ),
            );
          }
          if (state is SessionHistoryLoaded) {
            return ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: state.sessions.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final s = state.sessions[i];
                final duration = s.durationSeconds != null
                    ? _fmt(Duration(seconds: s.durationSeconds!))
                    : 'Unknown';
                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.blue.withOpacity(0.1),
                    child: const Icon(Icons.screen_share, color: Colors.blue, size: 20),
                  ),
                  title: Text(s.targetDeviceName),
                  subtitle: Text('$duration • ${_ago(s.startedAt ?? s.createdAt)}',
                      style: const TextStyle(fontSize: 12)),
                  trailing: Text(
                    s.status.name,
                    style: TextStyle(
                      color: s.status.name == 'ended' ? Colors.grey : Colors.green,
                      fontSize: 12,
                    ),
                  ),
                );
              },
            );
          }
          return const SizedBox();
        },
      ),
    );
  }

  String _fmt(Duration d) {
    if (d.inHours > 0) return '${d.inHours}h ${d.inMinutes % 60}m';
    if (d.inMinutes > 0) return '${d.inMinutes}m ${d.inSeconds % 60}s';
    return '${d.inSeconds}s';
  }

  String _ago(DateTime? dt) {
    if (dt == null) return '';
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}
