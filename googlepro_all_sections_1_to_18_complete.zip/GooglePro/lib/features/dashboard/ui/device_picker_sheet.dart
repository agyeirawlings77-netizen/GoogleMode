// lib/features/dashboard/ui/device_picker_sheet.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../device_management/model/device_model.dart';

class DevicePickerSheet extends StatelessWidget {
  final List<DeviceModel> devices;
  final String action;
  final String route;
  const DevicePickerSheet({super.key, required this.devices, required this.action, required this.route});

  static Future<void> show(BuildContext context, {required List<DeviceModel> devices, required String action, required String route}) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => DevicePickerSheet(devices: devices, action: action, route: route),
    );
  }

  @override
  Widget build(BuildContext context) {
    final online = devices.where((d) => d.isOnline).toList();
    final offline = devices.where((d) => !d.isOnline).toList();
    return DraggableScrollableSheet(
      expand: false, initialChildSize: 0.5, maxChildSize: 0.9, minChildSize: 0.3,
      builder: (_, ctrl) => Column(
        children: [
          Container(margin: const EdgeInsets.only(top: 12, bottom: 8), width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey.withOpacity(0.4), borderRadius: BorderRadius.circular(2))),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), child: Text('Select device for $action', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
          if (online.isEmpty && offline.isEmpty)
            const Expanded(child: Center(child: Text('No devices available', style: TextStyle(color: Colors.grey)))),
          Expanded(child: ListView(controller: ctrl, children: [
            if (online.isNotEmpty) ...[
              const Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 4), child: Text('Online', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))),
              ...online.map((d) => ListTile(
                leading: const CircleAvatar(backgroundColor: Colors.green, child: Icon(Icons.phone_android, color: Colors.white, size: 18)),
                title: Text(d.deviceName),
                subtitle: Text(d.model ?? 'Android Device'),
                onTap: () { Navigator.pop(context); context.push('$route/${d.deviceId}'); },
              )),
            ],
            if (offline.isNotEmpty) ...[
              const Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 4), child: Text('Offline', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold))),
              ...offline.map((d) => ListTile(
                enabled: false,
                leading: const CircleAvatar(backgroundColor: Colors.grey, child: Icon(Icons.phone_android, color: Colors.white, size: 18)),
                title: Text(d.deviceName),
                subtitle: const Text('Offline'),
              )),
            ],
          ])),
        ],
      ),
    );
  }
}
