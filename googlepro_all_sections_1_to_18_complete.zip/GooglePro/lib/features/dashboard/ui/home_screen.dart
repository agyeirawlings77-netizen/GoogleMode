// lib/features/dashboard/ui/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../viewmodel/dashboard_bloc.dart';
import '../state/dashboard_event.dart';
import '../state/dashboard_state.dart';
import '../widget/greeting_header.dart';
import '../widget/device_card.dart';
import '../widget/quick_action_grid.dart';
import '../widget/connection_status_bar.dart';
import '../widget/recent_session_tile.dart';
import '../widget/stats_row.dart';
import '../../device_management/state/device_event.dart';
import '../../device_management/viewmodel/device_bloc.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    context.read<DashboardBloc>().add(LoadDashboardEvent());
    context.read<DeviceBloc>().add(LoadDevicesEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: RefreshIndicator(
        onRefresh: () async {
          context.read<DashboardBloc>().add(RefreshDashboardEvent());
          context.read<DeviceBloc>().add(LoadDevicesEvent());
        },
        child: CustomScrollView(
          slivers: [
            // App Bar
            SliverAppBar(
              floating: true,
              snap: true,
              title: const Text('GooglePro'),
              actions: [
                IconButton(
                  icon: const Icon(Icons.notifications_outlined),
                  onPressed: () => context.push('/notifications'),
                ),
                IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () {},
                ),
              ],
            ),

            SliverToBoxAdapter(
              child: BlocBuilder<DashboardBloc, DashboardState>(
                builder: (context, state) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Greeting
                      const GreetingHeader(),
                      const SizedBox(height: 8),

                      // Stats row
                      if (state is DashboardLoaded)
                        StatsRow(stats: state.stats),

                      // Connection status
                      const ConnectionStatusBar(),
                      const SizedBox(height: 16),

                      // Quick Actions
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Text('Quick Actions',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            )),
                      ),
                      const SizedBox(height: 8),
                      const QuickActionGrid(),
                      const SizedBox(height: 24),

                      // Devices
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('My Devices',
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                )),
                            TextButton(
                              onPressed: () => context.push('/devices'),
                              child: const Text('See All'),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      _buildDevicesList(),
                      const SizedBox(height: 24),

                      // Recent Sessions
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Recent Sessions',
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                )),
                            TextButton(
                              onPressed: () => context.push('/session/history'),
                              child: const Text('See All'),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      if (state is DashboardLoaded)
                        ...state.recentSessions.take(3).map(
                          (s) => Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            child: RecentSessionTile(session: s),
                          ),
                        )
                      else
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text('No recent sessions',
                                style: TextStyle(color: Colors.grey)),
                          ),
                        ),
                      const SizedBox(height: 80),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push('/devices/add'),
        icon: const Icon(Icons.add),
        label: const Text('Add Device'),
      ),
    );
  }

  Widget _buildDevicesList() {
    return BlocBuilder<DeviceBloc, DeviceState>(
      builder: (context, state) {
        if (state is DeviceLoading) {
          return const Center(child: CircularProgressIndicator());
        }
        if (state is DeviceLoaded && state.devices.isNotEmpty) {
          return SizedBox(
            height: 160,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: state.devices.length,
              itemBuilder: (context, index) {
                return DeviceCard(device: state.devices[index]);
              },
            ),
          );
        }
        return Padding(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: Column(
              children: [
                const Icon(Icons.devices, size: 48, color: Colors.grey),
                const SizedBox(height: 8),
                const Text('No devices yet', style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () => context.push('/devices/add'),
                  child: const Text('Add Device'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
