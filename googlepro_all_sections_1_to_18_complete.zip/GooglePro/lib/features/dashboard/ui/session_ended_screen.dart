// lib/features/dashboard/ui/session_ended_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SessionEndedScreen extends StatelessWidget {
  final Duration? duration;
  final String? deviceName;
  const SessionEndedScreen({super.key, this.duration, this.deviceName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircleAvatar(
                  radius: 48, backgroundColor: Colors.blue,
                  child: Icon(Icons.check_circle, size: 60, color: Colors.white),
                ),
                const SizedBox(height: 24),
                const Text('Session Ended', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                if (deviceName != null) ...[
                  const SizedBox(height: 8),
                  Text('Device: $deviceName', style: const TextStyle(color: Colors.grey)),
                ],
                if (duration != null) ...[
                  const SizedBox(height: 8),
                  Text('Duration: ${_format(duration!)}', style: const TextStyle(color: Colors.grey)),
                ],
                const SizedBox(height: 40),
                ElevatedButton.icon(
                  icon: const Icon(Icons.home),
                  label: const Text('Back to Dashboard'),
                  onPressed: () => context.go('/dashboard'),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  icon: const Icon(Icons.history),
                  label: const Text('View Session History'),
                  onPressed: () => context.push('/sessions/history'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _format(Duration d) {
    if (d.inHours > 0) return '${d.inHours}h ${d.inMinutes % 60}m ${d.inSeconds % 60}s';
    if (d.inMinutes > 0) return '${d.inMinutes}m ${d.inSeconds % 60}s';
    return '${d.inSeconds}s';
  }
}
