// lib/features/dashboard/state/dashboard_event.dart
abstract class DashboardEvent {}
class LoadDashboardEvent extends DashboardEvent {}
class RefreshDashboardEvent extends DashboardEvent {}
class UpdateDashboardStatsEvent extends DashboardEvent {
  final Map<String, dynamic> stats;
  UpdateDashboardStatsEvent(this.stats);
}
