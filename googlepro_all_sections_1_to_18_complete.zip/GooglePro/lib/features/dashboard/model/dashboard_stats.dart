// lib/features/dashboard/model/dashboard_stats.dart

class DashboardStats {
  final int totalDevices;
  final int onlineDevices;
  final int totalSessions;
  final String totalTime;
  final int unreadNotifications;
  final int trustedDevices;

  const DashboardStats({
    this.totalDevices = 0,
    this.onlineDevices = 0,
    this.totalSessions = 0,
    this.totalTime = '0m',
    this.unreadNotifications = 0,
    this.trustedDevices = 0,
  });

  factory DashboardStats.fromMap(Map<String, dynamic> map) => DashboardStats(
    totalDevices: map['totalDevices'] ?? 0,
    onlineDevices: map['onlineDevices'] ?? 0,
    totalSessions: map['totalSessions'] ?? 0,
    totalTime: map['totalTime'] ?? '0m',
    unreadNotifications: map['unreadNotifications'] ?? 0,
    trustedDevices: map['trustedDevices'] ?? 0,
  );

  DashboardStats copyWith({
    int? totalDevices, int? onlineDevices, int? totalSessions,
    String? totalTime, int? unreadNotifications, int? trustedDevices,
  }) => DashboardStats(
    totalDevices: totalDevices ?? this.totalDevices,
    onlineDevices: onlineDevices ?? this.onlineDevices,
    totalSessions: totalSessions ?? this.totalSessions,
    totalTime: totalTime ?? this.totalTime,
    unreadNotifications: unreadNotifications ?? this.unreadNotifications,
    trustedDevices: trustedDevices ?? this.trustedDevices,
  );
}
