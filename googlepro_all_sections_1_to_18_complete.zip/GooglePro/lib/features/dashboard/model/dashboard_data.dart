// lib/features/dashboard/model/dashboard_data.dart
import '../../device_management/model/device_model.dart';

class DashboardData {
  final List<DeviceModel> recentDevices;
  final int totalDevices;
  final int onlineDevices;
  final int activeSessions;
  final bool hasActiveSession;
  final String? activeSessionDeviceName;
  final Map<String, int> stats;
  final DateTime? lastUpdated;

  const DashboardData({
    this.recentDevices = const [],
    this.totalDevices = 0,
    this.onlineDevices = 0,
    this.activeSessions = 0,
    this.hasActiveSession = false,
    this.activeSessionDeviceName,
    this.stats = const {},
    this.lastUpdated,
  });

  DashboardData copyWith({
    List<DeviceModel>? recentDevices,
    int? totalDevices,
    int? onlineDevices,
    int? activeSessions,
    bool? hasActiveSession,
    String? activeSessionDeviceName,
    Map<String, int>? stats,
    DateTime? lastUpdated,
  }) => DashboardData(
    recentDevices: recentDevices ?? this.recentDevices,
    totalDevices: totalDevices ?? this.totalDevices,
    onlineDevices: onlineDevices ?? this.onlineDevices,
    activeSessions: activeSessions ?? this.activeSessions,
    hasActiveSession: hasActiveSession ?? this.hasActiveSession,
    activeSessionDeviceName: activeSessionDeviceName ?? this.activeSessionDeviceName,
    stats: stats ?? this.stats,
    lastUpdated: lastUpdated ?? this.lastUpdated,
  );
}
