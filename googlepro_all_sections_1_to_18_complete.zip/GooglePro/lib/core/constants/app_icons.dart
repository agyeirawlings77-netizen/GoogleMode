// lib/core/constants/app_icons.dart
import 'package:flutter/material.dart';
class AppIcons {
  static const screenShare = Icons.screen_share_rounded;
  static const remoteControl = Icons.touch_app_rounded;
  static const fileTransfer = Icons.folder_shared_rounded;
  static const location = Icons.location_on_rounded;
  static const alarm = Icons.alarm_rounded;
  static const security = Icons.security_rounded;
  static const devices = Icons.devices_rounded;
  static const profile = Icons.person_rounded;
  static const ai = Icons.auto_awesome_rounded;
  static const backup = Icons.backup_rounded;
}
