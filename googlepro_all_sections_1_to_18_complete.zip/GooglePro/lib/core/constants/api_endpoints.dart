// lib/core/constants/api_endpoints.dart

class ApiEndpoints {
  static const _baseUrl       = 'https://googlepro-signaling.onrender.com/api/v1';
  static const _wsUrl         = 'wss://googlepro-signaling.onrender.com/ws';

  static String get baseUrl   => _baseUrl;
  static String get wsUrl     => _wsUrl;

  // Auth
  static const auth           = '$_baseUrl/auth';
  static const verifyToken    = '$auth/verify';
  static const registerDevice = '$auth/register-device';
  static const logout         = '$auth/logout';
  static const me             = '$auth/me';
  static const refreshFcm     = '$auth/refresh-fcm';

  // Devices
  static const devices        = '$_baseUrl/devices';
  static String deviceById(String id)  => '$devices/$id';
  static String deviceStatus(String id)=> '$devices/$id/status';
  static String trustDevice(String id) => '$devices/$id/trust';
  static const trustedDevices = '$devices/trusted/list';

  // Sessions
  static const sessions         = '$_baseUrl/sessions';
  static String sessionById(String id) => '$sessions/$id';
  static String endSession(String id)  => '$sessions/$id/end';
  static const sessionHistory   = '$sessions/history/list';
  static const activeSessions   = '$sessions/active/list';

  // Signaling
  static const signaling        = '$_baseUrl/signaling';
  static const iceServers       = '$signaling/ice-servers';
  static const sendOffer        = '$signaling/offer';
  static const sendAnswer       = '$signaling/answer';
  static const sendIceCandidate = '$signaling/ice-candidate';
  static const callEnd          = '$signaling/call-end';

  // Users
  static const users            = '$_baseUrl/users';
  static const userProfile      = '$users/profile';
  static const linkedDevices    = '$users/linked-devices';
  static String removeDevice(String id) => '$users/linked-devices/$id';

  // Status
  static const status           = '$_baseUrl/status';
  static String deviceStatusById(String id) => '$status/$id';

  // Files
  static const files            = '$_baseUrl/files';
  static const uploadUrl        = '$files/upload-url';
  static const transferRequest  = '$files/transfer-request';
  static const transfers        = '$files/transfers';

  // Notifications
  static const notifications    = '$_baseUrl/notifications';
  static const sendNotification = '$notifications/send';
  static const sendToDevice     = '$notifications/send-to-device';
}
