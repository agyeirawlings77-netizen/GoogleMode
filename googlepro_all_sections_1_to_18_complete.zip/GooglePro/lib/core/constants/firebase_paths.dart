// lib/core/constants/firebase_paths.dart

class FirebasePaths {
  FirebasePaths._();

  // Firestore collections
  static const String users = 'users';
  static const String devices = 'devices';
  static const String sessions = 'sessions';
  static const String trustedDevices = 'trusted_devices';
  static const String notifications = 'notifications';
  static const String chatMessages = 'chat_messages';
  static const String fileTransfers = 'file_transfers';
  static const String locationHistory = 'location_history';
  static const String parentalProfiles = 'parental_profiles';
  static const String securityEvents = 'security_events';
  static const String backups = 'backups';
  static const String feedback = 'feedback';
  static const String appSettings = 'app_settings';

  // Realtime Database paths
  static const String presence = 'presence';
  static const String signaling = 'signaling';
  static const String deviceStatus = 'device_status';
  static const String remoteAlarms = 'remote_alarms';
  static const String focusMode = 'focus_mode';
  static const String connectionRequests = 'connection_requests';
  static const String autoConnect = 'auto_connect';

  // Realtime DB sub-paths
  static String presencePath(String deviceId) => '$presence/$deviceId';
  static String signalingPath(String deviceId) => '$signaling/$deviceId';
  static String signalingOfferPath(String deviceId) => '$signaling/$deviceId/offer';
  static String signalingAnswerPath(String deviceId) => '$signaling/$deviceId/answer';
  static String signalingCandidatesPath(String deviceId) =>
      '$signaling/$deviceId/candidates';
  static String deviceStatusPath(String deviceId) =>
      '$deviceStatus/$deviceId';
  static String remoteAlarmPath(String deviceId) =>
      '$remoteAlarms/$deviceId';
  static String focusModePath(String deviceId) =>
      '$focusMode/$deviceId';
  static String connectionRequestPath(String deviceId) =>
      '$connectionRequests/$deviceId';

  // Firestore document paths
  static String userDoc(String userId) => '$users/$userId';
  static String deviceDoc(String deviceId) => '$devices/$deviceId';
  static String sessionDoc(String sessionId) => '$sessions/$sessionId';
  static String trustedDeviceDoc(String userId, String deviceId) =>
      '$trustedDevices/${userId}_$deviceId';
  static String notificationDoc(String userId, String notifId) =>
      '$users/$userId/$notifications/$notifId';

  // Firestore sub-collections
  static String userDevices(String userId) => '$users/$userId/$devices';
  static String userNotifications(String userId) =>
      '$users/$userId/$notifications';
  static String userSessions(String userId) => '$users/$userId/sessions';
  static String backupHistory(String userId) =>
      '$backups/$userId/history';

  // Storage paths
  static String avatarPath(String userId) => 'avatars/$userId/profile.jpg';
  static String backupPath(String userId, String backupId) =>
      'backups/$userId/$backupId.json';
  static String screenshotPath(String userId, String fileName) =>
      'screenshots/$userId/$fileName';
  static String fileTransferPath(String transferId, String fileName) =>
      'transfers/$transferId/$fileName';
}
