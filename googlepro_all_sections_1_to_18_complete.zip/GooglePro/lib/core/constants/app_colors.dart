// lib/core/constants/app_colors.dart
import 'package:flutter/material.dart';
class AppColors {
  static const primary = Color(0xFF1565C0);
  static const primaryDark = Color(0xFF0D47A1);
  static const online = Color(0xFF4CAF50);
  static const offline = Color(0xFF9E9E9E);
  static const error = Color(0xFFF44336);
  static const warning = Color(0xFFFF9800);
  static const success = Color(0xFF4CAF50);
  static const live = Color(0xFFF44336);
}
