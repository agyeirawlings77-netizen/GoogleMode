// lib/core/constants/webrtc_constants.dart

class WebRTCConstants {
  // ICE Servers
  static const stunUrl      = 'stun:relay.metered.ca:80';
  static const turnUrl      = 'turn:relay.metered.ca:80';
  static const turnUrl443   = 'turn:relay.metered.ca:443';
  static const turnUrlTcp   = 'turn:relay.metered.ca:443?transport=tcp';
  static const turnUsername = 'adf231e2b5e252e24c33b810';
  static const turnCredential = 'W6dyxkfDTN4XQHKM';

  static Map<String, dynamic> get iceServers => {
    'iceServers': [
      {'urls': stunUrl},
      {'urls': turnUrl,    'username': turnUsername, 'credential': turnCredential},
      {'urls': turnUrl443, 'username': turnUsername, 'credential': turnCredential},
      {'urls': turnUrlTcp, 'username': turnUsername, 'credential': turnCredential},
    ],
    'sdpSemantics': 'unified-plan',
    'iceCandidatePoolSize': 10,
  };

  // Video constraints
  static const videoConstraints = {
    'audio': false,
    'video': {
      'mandatory': {
        'minWidth': '640',
        'minHeight': '360',
        'minFrameRate': '15',
      },
      'facingMode': 'user',
    }
  };

  // Screen capture constraints
  static const screenConstraints = {
    'audio': false,
    'video': true,
  };

  // Quality presets
  static const qualityLow    = {'width': 640,  'height': 360,  'fps': 15, 'bitrate': 500000};
  static const qualityMedium = {'width': 1280, 'height': 720,  'fps': 24, 'bitrate': 1500000};
  static const qualityHigh   = {'width': 1920, 'height': 1080, 'fps': 30, 'bitrate': 3000000};

  // Firebase signaling paths
  static const signalingPath  = 'signaling';
  static const offerPath      = 'offer';
  static const answerPath     = 'answer';
  static const candidatesPath = 'candidates';
  static const presencePath   = 'presence';

  // Timeouts
  static const connectionTimeoutMs  = 30000;
  static const iceGatheringTimeoutMs = 10000;
  static const reconnectDelayMs      = 2000;
  static const maxReconnectAttempts  = 5;

  // Data channel
  static const dataChannelLabel  = 'googlepro_data';
  static const maxMessageSizeBytes = 65536;
}
