// lib/core/constants/app_constants.dart

class AppConstants {
  AppConstants._();

  // App info
  static const String appName = 'GooglePro';
  static const String appVersion = '1.0.0';
  static const String appBuildNumber = '1';
  static const String packageName = 'com.rawlings.googlepro';

  // API
  static const String signalingApiUrl =
      'https://googlepro-signaling.onrender.com/api/v1';
  static const String signalingWsUrl =
      'wss://googlepro-signaling.onrender.com/ws';

  // Firebase
  static const String firebaseProjectId = 'pro-c76ee';
  static const String firebaseStorageBucket = 'pro-c76ee.firebasestorage.app';
  static const String firebaseDatabaseUrl =
      'https://pro-c76ee-default-rtdb.firebaseio.com';

  // TURN/STUN
  static const String stunUrl = 'stun:relay.metered.ca:80';
  static const String turnUrl = 'turn:relay.metered.ca:80';
  static const String turnUrl443 = 'turn:relay.metered.ca:443';
  static const String turnUrlTcp = 'turn:relay.metered.ca:443?transport=tcp';
  static const String turnUsername = 'adf231e2b5e252e24c33b810';
  static const String turnCredential = 'W6dyxkfDTN4XQHKM';

  // Gemini AI
  static const String geminiApiKey =
      'AIzaSyCA8KgvQApHxw6SkYCLU60ghmUMC4ZW51o';
  static const String geminiModel = 'gemini-pro';

  // Timeouts
  static const Duration connectionTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);
  static const Duration webSocketPingInterval = Duration(seconds: 25);
  static const Duration webSocketPongTimeout = Duration(seconds: 60);
  static const Duration autoConnectCheckInterval = Duration(seconds: 10);
  static const Duration presenceUpdateInterval = Duration(seconds: 30);
  static const Duration sessionTimeout = Duration(hours: 2);

  // Reconnection
  static const int maxReconnectAttempts = 5;
  static const Duration reconnectDelay = Duration(seconds: 2);
  static const Duration maxReconnectDelay = Duration(seconds: 30);

  // Screen capture
  static const int defaultFps = 30;
  static const int defaultBitrate = 2000000; // 2 Mbps
  static const int maxBitrate = 5000000;     // 5 Mbps
  static const int minBitrate = 300000;      // 300 Kbps

  // File transfer
  static const int chunkSizeBytes = 65536;   // 64 KB
  static const int maxFileSizeMb = 500;
  static const Duration transferTimeout = Duration(minutes: 10);

  // Chat
  static const int maxMessageLength = 4096;
  static const int maxAttachmentSizeMb = 50;

  // Pagination
  static const int defaultPageSize = 20;
  static const int maxPageSize = 100;

  // Cache
  static const Duration cacheExpiry = Duration(hours: 1);
  static const int maxCacheItems = 500;

  // Storage keys
  static const String keyOnboardingComplete = 'onboarding_complete';
  static const String keyUserToken = 'user_token';
  static const String keyDeviceId = 'device_id';
  static const String keyThemeMode = 'theme_mode';
  static const String keyLanguage = 'language';
  static const String keyAutoConnect = 'auto_connect_enabled';
  static const String keyBiometricEnabled = 'biometric_enabled';
  static const String keyNotificationsEnabled = 'notifications_enabled';
  static const String keyViewerConfig = 'viewer_config';
  static const String keyAppSettings = 'app_settings';
  static const String keyTrustedDevices = 'trusted_devices';
  static const String keySessionHistory = 'viewer_sessions';
  static const String keyFocusSession = 'active_focus_session';

  // Deep links
  static const String deepLinkScheme = 'googlepro';
  static const String deepLinkDashboard = 'googlepro://dashboard';
  static const String deepLinkDevices = 'googlepro://dashboard/devices';
  static const String deepLinkScreenShare = 'googlepro://screen-share';
  static const String deepLinkChat = 'googlepro://chat';
  static const String deepLinkTrustedDevices = 'googlepro://trusted-devices';

  // Notification IDs
  static const int notifIdForeground = 1;
  static const int notifIdConnection = 2;
  static const int notifIdScreenShare = 3;
  static const int notifIdAlarm = 4;
  static const int notifIdChat = 5;
  static const int notifIdFileTransfer = 6;
  static const int notifIdLocation = 7;

  // Method channels
  static const String channelMain = 'com.rawlings.googlepro/main';
  static const String channelScreenCapture = 'com.rawlings.googlepro/screen_capture';
  static const String channelBattery = 'com.rawlings.googlepro/battery';
  static const String channelDeviceInfo = 'com.rawlings.googlepro/device_info';
  static const String channelAutoStart = 'com.rawlings.googlepro/auto_start';
  static const String channelNotification = 'com.rawlings.googlepro/notifications';
  static const String channelWearable = 'com.rawlings.googlepro/wearable';
  static const String channelHomeWidget = 'com.rawlings.googlepro/home_widget';
}
