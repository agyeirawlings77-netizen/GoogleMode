// lib/core/mixins/loading_mixin.dart
import 'package:flutter/material.dart';

mixin LoadingMixin<T extends StatefulWidget> on State<T> {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  void setLoading(bool value) {
    if (mounted) setState(() => _isLoading = value);
  }

  Future<R?> withLoading<R>(Future<R> Function() action) async {
    setLoading(true);
    try {
      return await action();
    } finally {
      setLoading(false);
    }
  }

  Widget buildWithLoading({required Widget child, String? message}) {
    if (!_isLoading) return child;
    return Stack(
      children: [
        child,
        Container(
          color: Colors.black.withOpacity(0.3),
          child: Center(
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircularProgressIndicator(),
                    if (message != null) ...[
                      const SizedBox(height: 16),
                      Text(message),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
