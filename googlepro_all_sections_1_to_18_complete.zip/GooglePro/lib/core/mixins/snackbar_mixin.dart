// lib/core/mixins/snackbar_mixin.dart
import 'package:flutter/material.dart';

mixin SnackbarMixin<T extends StatefulWidget> on State<T> {
  void showSuccess(String message) => _show(message, Colors.green, Icons.check_circle);
  void showError(String message) => _show(message, Colors.red, Icons.error_outline);
  void showWarning(String message) => _show(message, Colors.orange, Icons.warning_amber);
  void showInfo(String message) => _show(message, Colors.blue, Icons.info_outline);

  void _show(String message, Color color, IconData icon) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(message, style: const TextStyle(color: Colors.white))),
        ]),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 3),
      ),
    );
  }
}
