// lib/core/mixins/form_mixin.dart
import 'package:flutter/material.dart';

mixin FormMixin<T extends StatefulWidget> on State<T> {
  final formKey = GlobalKey<FormState>();

  bool validateForm() => formKey.currentState?.validate() ?? false;
  void resetForm() => formKey.currentState?.reset();
  void saveForm() => formKey.currentState?.save();

  bool validateAndSave() {
    if (formKey.currentState?.validate() ?? false) {
      formKey.currentState?.save();
      return true;
    }
    return false;
  }
}
