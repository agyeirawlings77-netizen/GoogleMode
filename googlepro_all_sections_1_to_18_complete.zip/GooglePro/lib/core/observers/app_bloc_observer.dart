// lib/core/observers/app_bloc_observer.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/foundation.dart';

class AppBlocObserver extends BlocObserver {
  @override
  void onCreate(BlocBase bloc) { super.onCreate(bloc); debugPrint('BLoC Created: ${bloc.runtimeType}'); }
  @override
  void onEvent(Bloc bloc, Object? event) { super.onEvent(bloc, event); debugPrint('BLoC Event: ${bloc.runtimeType} -> ${event.runtimeType}'); }
  @override
  void onError(BlocBase bloc, Object error, StackTrace stackTrace) { super.onError(bloc, error, stackTrace); debugPrint('BLoC Error: ${bloc.runtimeType} -> $error'); }
  @override
  void onClose(BlocBase bloc) { super.onClose(bloc); debugPrint('BLoC Closed: ${bloc.runtimeType}'); }
}
