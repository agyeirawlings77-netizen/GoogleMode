// lib/core/services/platform_channel_service.dart
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import '../constants/app_constants.dart';

class PlatformChannelService {
  static const _mainChannel =
      MethodChannel(AppConstants.channelMain);
  static const _screenCaptureChannel =
      MethodChannel(AppConstants.channelScreenCapture);
  static const _batteryChannel =
      MethodChannel(AppConstants.channelBattery);
  static const _deviceInfoChannel =
      MethodChannel(AppConstants.channelDeviceInfo);
  static const _autoStartChannel =
      MethodChannel(AppConstants.channelAutoStart);
  static const _notificationChannel =
      MethodChannel(AppConstants.channelNotification);

  // ── Main ─────────────────────────────────────────────────────
  Future<void> openAppSettings() async {
    try {
      await _mainChannel.invokeMethod('openAppSettings');
    } on PlatformException catch (e) {
      debugPrint('openAppSettings error: $e');
    }
  }

  Future<bool> isIgnoringBatteryOptimizations() async {
    try {
      return await _mainChannel.invokeMethod<bool>(
              'isIgnoringBatteryOptimizations') ??
          false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> requestIgnoreBatteryOptimizations() async {
    try {
      await _mainChannel
          .invokeMethod('requestIgnoreBatteryOptimizations');
    } on PlatformException catch (e) {
      debugPrint('requestIgnoreBattery error: $e');
    }
  }

  Future<bool> canDrawOverlays() async {
    try {
      return await _mainChannel.invokeMethod<bool>('canDrawOverlays') ??
          false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> requestOverlayPermission() async {
    try {
      await _mainChannel.invokeMethod('requestOverlayPermission');
    } on PlatformException catch (e) {
      debugPrint('requestOverlay error: $e');
    }
  }

  Future<void> keepScreenOn(bool keep) async {
    try {
      await _mainChannel.invokeMethod('keepScreenOn', {'keep': keep});
    } on PlatformException catch (e) {
      debugPrint('keepScreenOn error: $e');
    }
  }

  // ── Screen Capture ──────────────────────────────────────────
  Future<bool> requestScreenCapturePermission() async {
    try {
      return await _screenCaptureChannel
              .invokeMethod<bool>('requestPermission') ??
          false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> stopScreenCapture() async {
    try {
      await _screenCaptureChannel.invokeMethod('stopCapture');
    } on PlatformException catch (e) {
      debugPrint('stopCapture error: $e');
    }
  }

  Future<bool> isScreenCapturing() async {
    try {
      return await _screenCaptureChannel
              .invokeMethod<bool>('isCapturing') ??
          false;
    } on PlatformException {
      return false;
    }
  }

  // ── Battery ─────────────────────────────────────────────────
  Future<int> getBatteryLevel() async {
    try {
      return await _batteryChannel
              .invokeMethod<int>('getBatteryLevel') ??
          0;
    } on PlatformException {
      return 0;
    }
  }

  Future<bool> isCharging() async {
    try {
      return await _batteryChannel.invokeMethod<bool>('isCharging') ??
          false;
    } on PlatformException {
      return false;
    }
  }

  // ── Device Info ─────────────────────────────────────────────
  Future<Map<String, dynamic>> getDeviceInfo() async {
    try {
      final result = await _deviceInfoChannel
          .invokeMethod<Map>('getDeviceInfo');
      return Map<String, dynamic>.from(result ?? {});
    } on PlatformException {
      return {};
    }
  }

  Future<String> getAndroidId() async {
    try {
      return await _deviceInfoChannel
              .invokeMethod<String>('getAndroidId') ??
          '';
    } on PlatformException {
      return '';
    }
  }

  // ── Auto Start ───────────────────────────────────────────────
  Future<bool> isAutoStartSupported() async {
    try {
      return await _autoStartChannel
              .invokeMethod<bool>('isAutoStartSupported') ??
          false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> openAutoStartSettings() async {
    try {
      await _autoStartChannel.invokeMethod('openAutoStartSettings');
    } on PlatformException catch (e) {
      debugPrint('openAutoStart error: $e');
    }
  }

  // ── Notifications ────────────────────────────────────────────
  Future<void> createNotificationChannels() async {
    try {
      await _notificationChannel.invokeMethod('createChannels');
    } on PlatformException catch (e) {
      debugPrint('createChannels error: $e');
    }
  }

  Future<bool> areNotificationsEnabled() async {
    try {
      return await _notificationChannel
              .invokeMethod<bool>('areNotificationsEnabled') ??
          false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> openNotificationSettings() async {
    try {
      await _notificationChannel
          .invokeMethod('openNotificationSettings');
    } on PlatformException catch (e) {
      debugPrint('openNotificationSettings error: $e');
    }
  }
}
