// lib/core/services/local_notification_service.dart
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class LocalNotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    await _plugin.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ));
  }

  static Future<void> show({required int id, required String title, required String body, String channelId = 'googlepro_general', String channelName = 'General'}) async {
    await _plugin.show(id, title, body,
      NotificationDetails(android: AndroidNotificationDetails(channelId, channelName, importance: Importance.high, priority: Priority.high)));
  }

  static Future<void> cancel(int id) async => _plugin.cancel(id);
  static Future<void> cancelAll() async => _plugin.cancelAll();
}
