// lib/core/services/deep_link_service.dart
import 'package:flutter/foundation.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';

class DeepLinkService {
  static Future<void> initialize(void Function(String) onLink) async {
    try {
      final initial = await FirebaseDynamicLinks.instance.getInitialLink();
      if (initial != null) onLink(initial.link.toString());
      FirebaseDynamicLinks.instance.onLink.listen((data) => onLink(data.link.toString()));
    } catch (e) { debugPrint('DeepLink init error: $e'); }
  }

  static Future<Uri?> createDevicePairingLink(String pairingCode) async {
    try {
      final params = DynamicLinkParameters(
        uriPrefix: 'https://googlepro.page.link',
        link: Uri.parse('https://googlepro.app/pair?code=$pairingCode'),
        androidParameters: const AndroidParameters(packageName: 'com.rawlings.googlepro'),
      );
      final link = await FirebaseDynamicLinks.instance.buildShortLink(params);
      return link.shortUrl;
    } catch (e) { debugPrint('DeepLink create error: $e'); return null; }
  }
}
