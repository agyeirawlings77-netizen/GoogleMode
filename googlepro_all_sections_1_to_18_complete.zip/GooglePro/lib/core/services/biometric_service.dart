// lib/core/services/biometric_service.dart
import 'package:local_auth/local_auth.dart';
import 'package:flutter/foundation.dart';

class BiometricService {
  static final _auth = LocalAuthentication();

  static Future<bool> isAvailable() async {
    try {
      return await _auth.canCheckBiometrics && (await _auth.getAvailableBiometrics()).isNotEmpty;
    } catch (e) { debugPrint('Biometric check error: $e'); return false; }
  }

  static Future<bool> authenticate({String reason = 'Authenticate to access GooglePro'}) async {
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false, useErrorDialogs: true),
      );
    } catch (e) { debugPrint('Biometric auth error: $e'); return false; }
  }

  static Future<List<BiometricType>> getAvailableTypes() async {
    try { return await _auth.getAvailableBiometrics(); }
    catch (_) { return []; }
  }

  static Future<bool> hasFingerprint() async {
    final types = await getAvailableTypes();
    return types.contains(BiometricType.fingerprint);
  }

  static Future<bool> hasFaceId() async {
    final types = await getAvailableTypes();
    return types.contains(BiometricType.face);
  }
}
