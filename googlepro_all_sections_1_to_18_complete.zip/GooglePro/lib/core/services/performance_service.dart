// lib/core/services/performance_service.dart
import 'package:firebase_performance/firebase_performance.dart';
import 'package:flutter/foundation.dart';

class PerformanceService {
  static final _perf = FirebasePerformance.instance;

  static Future<void> initialize() async {
    await _perf.setPerformanceCollectionEnabled(!kDebugMode);
  }

  static Trace startTrace(String name) {
    final trace = _perf.newTrace(name);
    trace.start();
    return trace;
  }

  static Future<void> stopTrace(Trace trace) async => trace.stop();

  static HttpMetric startHttpMetric(String url, HttpMethod method) {
    return _perf.newHttpMetric(url, method)..start();
  }
}
