// lib/core/services/device_info_service.dart
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';

class DeviceInfoService {
  static final _plugin = DeviceInfoPlugin();
  static AndroidDeviceInfo? _androidInfo;

  static Future<AndroidDeviceInfo> getAndroidInfo() async {
    _androidInfo ??= await _plugin.androidInfo;
    return _androidInfo!;
  }

  static Future<String> getDeviceId() async {
    try {
      final info = await getAndroidInfo();
      return info.id;
    } catch (e) { debugPrint('DeviceInfo error: $e'); return 'unknown_${DateTime.now().millisecondsSinceEpoch}'; }
  }

  static Future<String> getDeviceName() async {
    try {
      final info = await getAndroidInfo();
      return '${info.manufacturer} ${info.model}';
    } catch (_) { return 'Android Device'; }
  }

  static Future<String> getAndroidVersion() async {
    try {
      final info = await getAndroidInfo();
      return info.version.release;
    } catch (_) { return 'Unknown'; }
  }

  static Future<Map<String, String>> getDeviceMetadata() async {
    try {
      final info = await getAndroidInfo();
      return {
        'manufacturer': info.manufacturer, 'model': info.model,
        'brand': info.brand, 'androidVersion': info.version.release,
        'sdkInt': info.version.sdkInt.toString(), 'device': info.device,
      };
    } catch (_) { return {}; }
  }
}
