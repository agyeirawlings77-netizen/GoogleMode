// lib/core/services/push_notification_service.dart
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/foundation.dart';

class PushNotificationService {
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    const androidSettings = AndroidInitializationSettings('@drawable/ic_notification');
    const initSettings = InitializationSettings(android: androidSettings);
    await _plugin.initialize(initSettings, onDidReceiveNotificationResponse: _onTap);
    _initialized = true;
  }

  void _onTap(NotificationResponse response) {
    debugPrint('Notification tapped: ${response.payload}');
  }

  Future<void> showNotification({
    required int id,
    required String title,
    required String body,
    String channelId = 'googlepro_general',
    String channelName = 'General',
    String? payload,
    bool ongoing = false,
    bool silent = false,
  }) async {
    await initialize();
    final androidDetails = AndroidNotificationDetails(
      channelId, channelName,
      importance: silent ? Importance.low : Importance.high,
      priority: silent ? Priority.low : Priority.high,
      ongoing: ongoing,
      autoCancel: !ongoing,
    );
    final details = NotificationDetails(android: androidDetails);
    await _plugin.show(id, title, body, details, payload: payload);
  }

  Future<void> showProgressNotification({
    required int id,
    required String title,
    required String body,
    required int progress,
    required int maxProgress,
  }) async {
    await initialize();
    final androidDetails = AndroidNotificationDetails(
      'googlepro_file_transfer', 'File Transfer',
      importance: Importance.low,
      priority: Priority.low,
      showProgress: true,
      maxProgress: maxProgress,
      progress: progress,
      ongoing: true,
      autoCancel: false,
    );
    await _plugin.show(id, title, body, NotificationDetails(android: androidDetails));
  }

  Future<void> cancel(int id) => _plugin.cancel(id);
  Future<void> cancelAll() => _plugin.cancelAll();
}
