// lib/core/services/fcm_service.dart
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class FCMService {
  static final _fcm = FirebaseMessaging.instance;
  static final _localNotifications = FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    await _fcm.requestPermission(alert: true, badge: true, sound: true);
    FirebaseMessaging.onMessage.listen(_handleForeground);
    FirebaseMessaging.onMessageOpenedApp.listen(_handleOpen);
    FirebaseMessaging.onBackgroundMessage(_handleBackground);
    await _localNotifications.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
    );
  }

  static Future<String?> getToken() async {
    try { return await _fcm.getToken(); }
    catch (e) { debugPrint('FCM token error: $e'); return null; }
  }

  static void _handleForeground(RemoteMessage message) {
    debugPrint('FCM foreground: ${message.notification?.title}');
    _showLocalNotification(message);
  }

  static void _handleOpen(RemoteMessage message) {
    debugPrint('FCM opened: ${message.data}');
  }

  @pragma('vm:entry-point')
  static Future<void> _handleBackground(RemoteMessage message) async {
    debugPrint('FCM background: ${message.notification?.title}');
  }

  static Future<void> _showLocalNotification(RemoteMessage message) async {
    final n = message.notification;
    if (n == null) return;
    await _localNotifications.show(0, n.title, n.body,
      const NotificationDetails(android: AndroidNotificationDetails('googlepro_general', 'General', importance: Importance.high, priority: Priority.high)));
  }
}
