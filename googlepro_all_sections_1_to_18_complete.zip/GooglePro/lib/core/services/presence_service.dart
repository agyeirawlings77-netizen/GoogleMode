// lib/core/services/presence_service.dart
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

class PresenceService {
  static final _rtdb = FirebaseDatabase.instance;
  static String? _deviceId;

  static Future<void> initialize(String deviceId) async {
    _deviceId = deviceId;
    await _setOnline();
    _rtdb.ref().onDisconnect().cancel();
    FirebaseAuth.instance.authStateChanges().listen((user) {
      if (user != null) _setOnline();
      else _setOffline();
    });
  }

  static Future<void> _setOnline() async {
    if (_deviceId == null) return;
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    try {
      final ref = _rtdb.ref('presence/$_deviceId');
      await ref.set({'online': true, 'userId': uid, 'lastSeen': ServerValue.timestamp});
      await ref.onDisconnect().update({'online': false, 'lastSeen': ServerValue.timestamp});
    } catch (e) { debugPrint('Presence online error: $e'); }
  }

  static Future<void> _setOffline() async {
    if (_deviceId == null) return;
    try { await _rtdb.ref('presence/$_deviceId').update({'online': false, 'lastSeen': ServerValue.timestamp}); }
    catch (e) { debugPrint('Presence offline error: $e'); }
  }

  static Stream<bool> watchDevice(String deviceId) {
    return _rtdb.ref('presence/$deviceId/online').onValue.map((e) => e.snapshot.value == true);
  }

  static Future<bool> isOnline(String deviceId) async {
    try {
      final snap = await _rtdb.ref('presence/$deviceId/online').get();
      return snap.value == true;
    } catch (_) { return false; }
  }
}
