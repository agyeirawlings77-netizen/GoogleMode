// lib/core/services/notification_channel_service.dart
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationChannelService {
  static final _plugin = FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));
    await _createChannels();
  }

  static Future<void> _createChannels() async {
    const channels = [
      AndroidNotificationChannel('googlepro_general', 'General', importance: Importance.defaultImportance),
      AndroidNotificationChannel('googlepro_connection', 'Connection Alerts', importance: Importance.high),
      AndroidNotificationChannel('googlepro_alarm', 'Remote Alarm', importance: Importance.max),
      AndroidNotificationChannel('googlepro_service', 'Background Service', importance: Importance.low),
      AndroidNotificationChannel('googlepro_file_transfer', 'File Transfer', importance: Importance.defaultImportance),
    ];
    for (final ch in channels) {
      await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(ch);
    }
  }

  static Future<void> showConnectionRequest({required String callerName, required String requestId}) async {
    await _plugin.show(1001, 'Connection Request', '$callerName wants to connect to your screen',
      const NotificationDetails(android: AndroidNotificationDetails('googlepro_connection', 'Connection Alerts', importance: Importance.high, priority: Priority.high)));
  }

  static Future<void> showAlarm({required String callerName}) async {
    await _plugin.show(1002, 'Remote Alarm', '$callerName triggered an alarm',
      const NotificationDetails(android: AndroidNotificationDetails('googlepro_alarm', 'Remote Alarm', importance: Importance.max, priority: Priority.max)));
  }

  static Future<void> showFileReceived({required String fileName, required String senderName}) async {
    await _plugin.show(1003, 'File Received', '$senderName sent $fileName',
      const NotificationDetails(android: AndroidNotificationDetails('googlepro_file_transfer', 'File Transfer')));
  }

  static Future<void> cancelAll() => _plugin.cancelAll();
}
