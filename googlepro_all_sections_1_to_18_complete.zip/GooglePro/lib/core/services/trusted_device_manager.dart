// lib/core/services/trusted_device_manager.dart
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class TrustedDeviceManager {
  static const _key = 'trusted_devices_local';

  Future<List<Map<String, dynamic>>> getTrustedDevices() async {
    final prefs = await SharedPreferences.getInstance();
    final json = prefs.getString(_key);
    if (json == null) return [];
    try {
      final list = jsonDecode(json) as List;
      return list.cast<Map<String, dynamic>>();
    } catch (_) {
      return [];
    }
  }

  Future<void> addTrustedDevice({
    required String deviceId,
    required String deviceName,
    required String ownerUserId,
  }) async {
    final devices = await getTrustedDevices();
    if (devices.any((d) => d['deviceId'] == deviceId)) return;
    devices.add({
      'deviceId': deviceId,
      'deviceName': deviceName,
      'ownerUserId': ownerUserId,
      'trustedAt': DateTime.now().toIso8601String(),
      'autoConnectEnabled': true,
    });
    await _save(devices);
  }

  Future<void> removeTrustedDevice(String deviceId) async {
    final devices = await getTrustedDevices();
    devices.removeWhere((d) => d['deviceId'] == deviceId);
    await _save(devices);
  }

  Future<bool> isDeviceTrusted(String deviceId) async {
    final devices = await getTrustedDevices();
    return devices.any((d) => d['deviceId'] == deviceId);
  }

  Future<void> toggleAutoConnect(String deviceId, bool enabled) async {
    final devices = await getTrustedDevices();
    final index = devices.indexWhere((d) => d['deviceId'] == deviceId);
    if (index != -1) {
      devices[index]['autoConnectEnabled'] = enabled;
      await _save(devices);
    }
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  Future<void> _save(List<Map<String, dynamic>> devices) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(devices));
  }
}
