// lib/core/services/local_storage_service.dart
import 'package:shared_preferences/shared_preferences.dart';

class LocalStorageService {
  static SharedPreferences? _prefs;

  Future<SharedPreferences> get _instance async {
    _prefs ??= await SharedPreferences.getInstance();
    return _prefs!;
  }

  Future<void> setString(String key, String value) async =>
      (await _instance).setString(key, value);
  Future<String?> getString(String key) async =>
      (await _instance).getString(key);

  Future<void> setBool(String key, bool value) async =>
      (await _instance).setBool(key, value);
  Future<bool?> getBool(String key) async =>
      (await _instance).getBool(key);

  Future<void> setInt(String key, int value) async =>
      (await _instance).setInt(key, value);
  Future<int?> getInt(String key) async =>
      (await _instance).getInt(key);

  Future<void> setDouble(String key, double value) async =>
      (await _instance).setDouble(key, value);
  Future<double?> getDouble(String key) async =>
      (await _instance).getDouble(key);

  Future<void> setStringList(String key, List<String> value) async =>
      (await _instance).setStringList(key, value);
  Future<List<String>?> getStringList(String key) async =>
      (await _instance).getStringList(key);

  Future<bool> remove(String key) async => (await _instance).remove(key);
  Future<bool> clear() async => (await _instance).clear();
  Future<bool> containsKey(String key) async => (await _instance).containsKey(key);

  // Convenience: user session
  Future<void> saveUserSession(String userId, String deviceId) async {
    await setString('user_id', userId);
    await setString('device_id', deviceId);
    await setBool('is_logged_in', true);
  }

  Future<Map<String, String?>> getUserSession() async {
    return {
      'userId': await getString('user_id'),
      'deviceId': await getString('device_id'),
    };
  }

  Future<bool> isLoggedIn() async => (await getBool('is_logged_in')) ?? false;

  Future<void> clearUserSession() async {
    await remove('user_id');
    await remove('device_id');
    await setBool('is_logged_in', false);
  }
}
