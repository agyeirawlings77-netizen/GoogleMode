// lib/core/services/connectivity_service.dart
import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';

class ConnectivityService {
  final Connectivity _connectivity = Connectivity();
  ConnectivityResult _currentResult = ConnectivityResult.none;
  StreamSubscription? _sub;

  final _controller = StreamController<ConnectivityResult>.broadcast();
  Stream<ConnectivityResult> get stream => _controller.stream;
  ConnectivityResult get current => _currentResult;
  bool get isConnected => _currentResult != ConnectivityResult.none;
  bool get isWifi => _currentResult == ConnectivityResult.wifi;
  bool get isMobile => _currentResult == ConnectivityResult.mobile;

  Future<void> initialize() async {
    _currentResult = await _connectivity.checkConnectivity();
    _sub = _connectivity.onConnectivityChanged.listen((result) {
      _currentResult = result;
      _controller.add(result);
      debugPrint('Connectivity changed: $result');
    });
  }

  Future<bool> checkConnectivity() async {
    _currentResult = await _connectivity.checkConnectivity();
    return isConnected;
  }

  void dispose() {
    _sub?.cancel();
    _controller.close();
  }
}
