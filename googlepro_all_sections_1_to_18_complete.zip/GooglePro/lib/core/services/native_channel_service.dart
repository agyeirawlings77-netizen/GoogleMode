// lib/core/services/native_channel_service.dart
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';

class NativeChannelService {
  static const _methodChannel = MethodChannel('com.rawlings.googlepro/methods');
  static const _fcmEventChannel    = EventChannel('com.rawlings.googlepro/fcm_events');
  static const _autoConnectChannel = EventChannel('com.rawlings.googlepro/auto_connect');

  // ─── Foreground Service ─────────────────────────────────────
  Future<bool> startForegroundService({
    String title = 'GooglePro',
    String text  = 'Running in background',
  }) async {
    try {
      final result = await _methodChannel.invokeMethod<bool>(
        'startForegroundService', {'title': title, 'text': text},
      );
      return result ?? false;
    } on PlatformException catch (e) {
      debugPrint('startForegroundService error: $e');
      return false;
    }
  }

  Future<bool> stopForegroundService() async {
    try {
      final result = await _methodChannel.invokeMethod<bool>('stopForegroundService');
      return result ?? false;
    } on PlatformException catch (e) {
      debugPrint('stopForegroundService error: $e');
      return false;
    }
  }

  // ─── Permissions ────────────────────────────────────────────
  Future<bool> checkPermission(String permission) async {
    try {
      final result = await _methodChannel.invokeMethod<bool>(
        'checkPermission', {'permission': permission},
      );
      return result ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> requestPermission(String permission) async {
    try {
      await _methodChannel.invokeMethod('requestPermission', {'permission': permission});
    } on PlatformException catch (e) {
      debugPrint('requestPermission error: $e');
    }
  }

  Future<bool> isBatteryOptimizationIgnored() async {
    try {
      return await _methodChannel.invokeMethod<bool>('isBatteryOptimizationIgnored') ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> openBatteryOptimizationSettings() async {
    try {
      await _methodChannel.invokeMethod('openBatteryOptimizationSettings');
    } on PlatformException catch (e) {
      debugPrint('openBatterySettings error: $e');
    }
  }

  Future<bool> needsAutoStartPermission() async {
    try {
      return await _methodChannel.invokeMethod<bool>('needsAutoStartPermission') ?? false;
    } on PlatformException {
      return false;
    }
  }

  Future<void> openAutoStartSettings() async {
    try {
      await _methodChannel.invokeMethod('openAutoStartSettings');
    } on PlatformException catch (e) {
      debugPrint('openAutoStartSettings error: $e');
    }
  }

  // ─── Auto Connect ────────────────────────────────────────────
  Future<bool> scheduleAutoConnect({required String userId, required String deviceId}) async {
    try {
      return await _methodChannel.invokeMethod<bool>(
        'scheduleAutoConnect', {'userId': userId, 'deviceId': deviceId},
      ) ?? false;
    } on PlatformException catch (e) {
      debugPrint('scheduleAutoConnect error: $e');
      return false;
    }
  }

  Future<bool> cancelAutoConnect() async {
    try {
      return await _methodChannel.invokeMethod<bool>('cancelAutoConnect') ?? false;
    } on PlatformException {
      return false;
    }
  }

  // ─── Session ─────────────────────────────────────────────────
  Future<void> saveUserSession({required String userId, required String deviceId}) async {
    try {
      await _methodChannel.invokeMethod(
        'saveUserSession', {'userId': userId, 'deviceId': deviceId},
      );
    } on PlatformException catch (e) {
      debugPrint('saveUserSession error: $e');
    }
  }

  Future<void> clearUserSession() async {
    try {
      await _methodChannel.invokeMethod('clearUserSession');
    } on PlatformException catch (e) {
      debugPrint('clearUserSession error: $e');
    }
  }

  // ─── FCM ─────────────────────────────────────────────────────
  Future<String?> getFcmToken() async {
    try {
      return await _methodChannel.invokeMethod<String>('getFcmToken');
    } on PlatformException {
      return null;
    }
  }

  // ─── Device Info ─────────────────────────────────────────────
  Future<String> getManufacturer() async {
    try {
      return await _methodChannel.invokeMethod<String>('getManufacturer') ?? 'Unknown';
    } on PlatformException {
      return 'Unknown';
    }
  }

  Future<String> getModel() async {
    try {
      return await _methodChannel.invokeMethod<String>('getModel') ?? 'Unknown';
    } on PlatformException {
      return 'Unknown';
    }
  }

  Future<String> getAndroidVersion() async {
    try {
      return await _methodChannel.invokeMethod<String>('getAndroidVersion') ?? 'Unknown';
    } on PlatformException {
      return 'Unknown';
    }
  }

  // ─── Event Streams ───────────────────────────────────────────
  Stream<Map<String, dynamic>> get fcmEventStream =>
      _fcmEventChannel.receiveBroadcastStream().map(
        (event) => Map<String, dynamic>.from(event as Map),
      );

  Stream<String> get autoConnectStream =>
      _autoConnectChannel.receiveBroadcastStream().map((e) => e.toString());
}
