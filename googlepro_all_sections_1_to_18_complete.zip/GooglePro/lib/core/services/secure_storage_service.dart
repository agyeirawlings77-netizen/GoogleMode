// lib/core/services/secure_storage_service.dart
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageService {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const _keyUserId = 'user_id';
  static const _keyDeviceId = 'device_id';
  static const _keyAuthToken = 'auth_token';
  static const _keyPinHash = 'pin_hash';
  static const _keyBiometricEnabled = 'biometric_enabled';

  Future<void> saveUserId(String userId) =>
      _storage.write(key: _keyUserId, value: userId);
  Future<String?> getUserId() => _storage.read(key: _keyUserId);

  Future<void> saveDeviceId(String deviceId) =>
      _storage.write(key: _keyDeviceId, value: deviceId);
  Future<String?> getDeviceId() => _storage.read(key: _keyDeviceId);

  Future<void> saveAuthToken(String token) =>
      _storage.write(key: _keyAuthToken, value: token);
  Future<String?> getAuthToken() => _storage.read(key: _keyAuthToken);

  Future<void> savePinHash(String hash) =>
      _storage.write(key: _keyPinHash, value: hash);
  Future<String?> getPinHash() => _storage.read(key: _keyPinHash);
  Future<void> deletePinHash() => _storage.delete(key: _keyPinHash);

  Future<void> setBiometricEnabled(bool enabled) =>
      _storage.write(key: _keyBiometricEnabled, value: enabled.toString());
  Future<bool> isBiometricEnabled() async {
    final val = await _storage.read(key: _keyBiometricEnabled);
    return val == 'true';
  }

  Future<void> write(String key, String value) =>
      _storage.write(key: key, value: value);
  Future<String?> read(String key) => _storage.read(key: key);
  Future<void> delete(String key) => _storage.delete(key: key);

  Future<void> clearAll() => _storage.deleteAll();
}
