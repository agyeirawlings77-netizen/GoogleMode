// lib/core/middleware/auth_guard.dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter/material.dart';

class AuthGuard {
  static String? redirect(BuildContext context, GoRouterState state) {
    final user = FirebaseAuth.instance.currentUser;
    final isAuth = user != null;
    final isAuthRoute = state.matchedLocation.startsWith('/auth') || state.matchedLocation == '/splash' || state.matchedLocation == '/onboarding';
    if (!isAuth && !isAuthRoute) return '/auth/welcome';
    if (isAuth && state.matchedLocation == '/auth/welcome') return '/dashboard';
    return null;
  }
}
