// lib/core/firebase/firebase_options.dart
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => android;

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBVDzvX3KhOmY8ujlbNC-jGoQX43aERmd8',
    appId: '1:458149596472:android:771af17fbc2a4434ac45cd',
    messagingSenderId: '458149596472',
    projectId: 'pro-c76ee',
    storageBucket: 'pro-c76ee.firebasestorage.app',
    databaseURL: 'https://pro-c76ee-default-rtdb.firebaseio.com',
  );
}
