// lib/core/firebase/realtime_db_service.dart
import 'package:firebase_database/firebase_database.dart';

class RealtimeDbService {
  final FirebaseDatabase _db = FirebaseDatabase.instance;

  Future<void> set(String path, dynamic value) =>
      _db.ref(path).set(value);

  Future<void> update(String path, Map<String, dynamic> data) =>
      _db.ref(path).update(data);

  Future<void> delete(String path) => _db.ref(path).remove();

  Future<DataSnapshot> get(String path) => _db.ref(path).get();

  Future<DatabaseReference> push(String path, dynamic value) async {
    final ref = _db.ref(path).push();
    await ref.set(value);
    return ref;
  }

  Stream<DatabaseEvent> watch(String path) => _db.ref(path).onValue;

  Stream<DatabaseEvent> watchChild(String path) => _db.ref(path).onChildAdded;

  Future<void> setPresence(String deviceId, bool isOnline) async {
    await _db.ref('presence/$deviceId').set({
      'online': isOnline,
      'lastSeen': ServerValue.timestamp,
    });
  }

  Stream<bool> watchPresence(String deviceId) {
    return _db.ref('presence/$deviceId/online').onValue.map(
      (event) => event.snapshot.value as bool? ?? false,
    );
  }

  Future<void> setSignalingOffer(String deviceId, Map<String, dynamic> offer) =>
      _db.ref('signaling/$deviceId/offer').set(offer);

  Future<void> setSignalingAnswer(String deviceId, Map<String, dynamic> answer) =>
      _db.ref('signaling/$deviceId/answer').set(answer);

  Future<DatabaseReference> addIceCandidate(String deviceId, Map<String, dynamic> candidate) async {
    final ref = _db.ref('signaling/$deviceId/candidates').push();
    await ref.set(candidate);
    return ref;
  }

  Future<void> clearSignaling(String deviceId) =>
      _db.ref('signaling/$deviceId').remove();
}
