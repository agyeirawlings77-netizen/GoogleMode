// lib/core/firebase/firestore_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Generic get document
  Future<DocumentSnapshot> getDoc(String collection, String docId) =>
      _db.collection(collection).doc(docId).get();

  // Generic set document
  Future<void> setDoc(String collection, String docId, Map<String, dynamic> data, {bool merge = true}) =>
      _db.collection(collection).doc(docId).set(data, SetOptions(merge: merge));

  // Generic update document
  Future<void> updateDoc(String collection, String docId, Map<String, dynamic> data) =>
      _db.collection(collection).doc(docId).update(data);

  // Generic delete document
  Future<void> deleteDoc(String collection, String docId) =>
      _db.collection(collection).doc(docId).delete();

  // Generic add document (auto ID)
  Future<DocumentReference> addDoc(String collection, Map<String, dynamic> data) =>
      _db.collection(collection).add(data);

  // Generic watch document
  Stream<DocumentSnapshot> watchDoc(String collection, String docId) =>
      _db.collection(collection).doc(docId).snapshots();

  // Generic query collection
  Future<QuerySnapshot> queryCollection(
    String collection, {
    String? whereField,
    dynamic whereValue,
    String? orderBy,
    bool descending = false,
    int? limit,
  }) {
    Query query = _db.collection(collection);
    if (whereField != null && whereValue != null) {
      query = query.where(whereField, isEqualTo: whereValue);
    }
    if (orderBy != null) {
      query = query.orderBy(orderBy, descending: descending);
    }
    if (limit != null) {
      query = query.limit(limit);
    }
    return query.get();
  }

  // Generic watch collection
  Stream<QuerySnapshot> watchCollection(
    String collection, {
    String? whereField,
    dynamic whereValue,
    String? orderBy,
    bool descending = false,
  }) {
    Query query = _db.collection(collection);
    if (whereField != null && whereValue != null) {
      query = query.where(whereField, isEqualTo: whereValue);
    }
    if (orderBy != null) {
      query = query.orderBy(orderBy, descending: descending);
    }
    return query.snapshots();
  }

  // Batch write
  WriteBatch batch() => _db.batch();

  // Server timestamp
  FieldValue get serverTimestamp => FieldValue.serverTimestamp();

  // Increment
  FieldValue increment(num value) => FieldValue.increment(value);

  // Array union
  FieldValue arrayUnion(List items) => FieldValue.arrayUnion(items);

  // Array remove
  FieldValue arrayRemove(List items) => FieldValue.arrayRemove(items);
}
