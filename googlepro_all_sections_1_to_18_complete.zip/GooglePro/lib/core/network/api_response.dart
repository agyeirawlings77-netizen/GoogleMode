// lib/core/network/api_response.dart

class ApiResponse<T> {
  final bool success;
  final T? data;
  final String? message;
  final String? error;
  final int? statusCode;

  const ApiResponse({
    required this.success,
    this.data,
    this.message,
    this.error,
    this.statusCode,
  });

  factory ApiResponse.success(T data, {String? message, int statusCode = 200}) =>
      ApiResponse(success: true, data: data, message: message, statusCode: statusCode);

  factory ApiResponse.failure(String error, {int? statusCode}) =>
      ApiResponse(success: false, error: error, statusCode: statusCode);

  factory ApiResponse.fromJson(
    Map<String, dynamic> json,
    T Function(dynamic) fromJson,
  ) {
    final success = json['success'] as bool? ?? false;
    return ApiResponse(
      success: success,
      data: success && json['data'] != null ? fromJson(json['data']) : null,
      message: json['message']?.toString(),
      error: json['error']?.toString(),
      statusCode: json['statusCode'] as int?,
    );
  }

  bool get hasData => success && data != null;
  bool get hasError => !success || error != null;

  @override
  String toString() => success
      ? 'ApiResponse.success(data: $data, message: $message)'
      : 'ApiResponse.failure(error: $error, statusCode: $statusCode)';
}
