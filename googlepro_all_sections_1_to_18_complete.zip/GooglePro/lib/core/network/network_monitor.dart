// lib/core/network/network_monitor.dart
import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';

enum NetworkStatus { online, offline, wifi, mobile, ethernet }

class NetworkMonitor {
  NetworkMonitor._();

  static final _instance = NetworkMonitor._();
  factory NetworkMonitor() => _instance;

  final _connectivity = Connectivity();
  NetworkStatus _status = NetworkStatus.online;
  StreamController<NetworkStatus>? _controller;

  NetworkStatus get currentStatus => _status;
  bool get isOnline => _status != NetworkStatus.offline;

  Stream<NetworkStatus> get statusStream {
    _controller ??= StreamController<NetworkStatus>.broadcast();
    return _controller!.stream;
  }

  Future<void> init() async {
    final result = await _connectivity.checkConnectivity();
    _status = _mapResult(result);

    _connectivity.onConnectivityChanged.listen((result) {
      final newStatus = _mapResult(result);
      if (newStatus != _status) {
        _status = newStatus;
        _controller?.add(_status);
        debugPrint('NetworkMonitor: $newStatus');
      }
    });
  }

  NetworkStatus _mapResult(ConnectivityResult result) {
    switch (result) {
      case ConnectivityResult.wifi:
        return NetworkStatus.wifi;
      case ConnectivityResult.mobile:
        return NetworkStatus.mobile;
      case ConnectivityResult.ethernet:
        return NetworkStatus.ethernet;
      case ConnectivityResult.none:
        return NetworkStatus.offline;
      default:
        return NetworkStatus.online;
    }
  }

  Future<bool> checkConnection() async {
    final result = await _connectivity.checkConnectivity();
    _status = _mapResult(result);
    return _status != NetworkStatus.offline;
  }

  void dispose() {
    _controller?.close();
    _controller = null;
  }
}
