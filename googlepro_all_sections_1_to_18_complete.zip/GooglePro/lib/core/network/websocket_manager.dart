// lib/core/network/websocket/websocket_manager.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/io.dart';

enum WebSocketStatus { disconnected, connecting, connected, reconnecting, error }

class WebSocketManager {
  static const _wsUrl = 'wss://googlepro-signaling.onrender.com/ws';
  static const _maxRetries = 5;
  static const _retryDelayMs = 2000;

  WebSocketChannel?  _channel;
  WebSocketStatus    _status = WebSocketStatus.disconnected;
  String?            _authToken;
  String?            _deviceId;
  int                _retryCount = 0;
  Timer?             _heartbeatTimer;
  Timer?             _reconnectTimer;

  final _messageController = StreamController<Map<String, dynamic>>.broadcast();
  final _statusController  = StreamController<WebSocketStatus>.broadcast();

  Stream<Map<String, dynamic>> get messageStream => _messageController.stream;
  Stream<WebSocketStatus>      get statusStream  => _statusController.stream;
  WebSocketStatus get status => _status;
  bool get isConnected => _status == WebSocketStatus.connected;

  Future<void> connect({required String token, required String deviceId}) async {
    _authToken = token;
    _deviceId  = deviceId;
    _retryCount = 0;
    await _connect();
  }

  Future<void> _connect() async {
    _updateStatus(WebSocketStatus.connecting);
    try {
      final uri = Uri.parse('$_wsUrl?token=$_authToken&deviceId=$_deviceId');
      _channel = IOWebSocketChannel.connect(uri, pingInterval: const Duration(seconds: 25));

      _channel!.stream.listen(
        _onMessage,
        onError: _onError,
        onDone:  _onDone,
        cancelOnError: false,
      );

      _updateStatus(WebSocketStatus.connected);
      _retryCount = 0;
      _startHeartbeat();
      debugPrint('WebSocket connected to $_wsUrl');
    } catch (e) {
      debugPrint('WebSocket connect error: $e');
      _updateStatus(WebSocketStatus.error);
      _scheduleReconnect();
    }
  }

  void _onMessage(dynamic data) {
    try {
      final message = jsonDecode(data as String) as Map<String, dynamic>;
      _messageController.add(message);
    } catch (e) {
      debugPrint('WebSocket message parse error: $e');
    }
  }

  void _onError(dynamic error) {
    debugPrint('WebSocket error: $error');
    _updateStatus(WebSocketStatus.error);
    _scheduleReconnect();
  }

  void _onDone() {
    debugPrint('WebSocket disconnected');
    _stopHeartbeat();
    if (_status != WebSocketStatus.disconnected) {
      _updateStatus(WebSocketStatus.disconnected);
      _scheduleReconnect();
    }
  }

  void send(Map<String, dynamic> data) {
    if (!isConnected) {
      debugPrint('WebSocket not connected, cannot send');
      return;
    }
    try {
      _channel?.sink.add(jsonEncode(data));
    } catch (e) {
      debugPrint('WebSocket send error: $e');
    }
  }

  void sendEvent(String event, Map<String, dynamic> payload) {
    send({'event': event, 'data': payload, 'timestamp': DateTime.now().toIso8601String()});
  }

  void _startHeartbeat() {
    _heartbeatTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      send({'event': 'ping', 'data': {}});
    });
  }

  void _stopHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;
  }

  void _scheduleReconnect() {
    if (_retryCount >= _maxRetries) {
      debugPrint('WebSocket max retries reached');
      _updateStatus(WebSocketStatus.error);
      return;
    }
    _retryCount++;
    final delay = _retryDelayMs * _retryCount;
    _updateStatus(WebSocketStatus.reconnecting);
    debugPrint('WebSocket reconnecting in ${delay}ms (attempt $_retryCount)');
    _reconnectTimer = Timer(Duration(milliseconds: delay), _connect);
  }

  void _updateStatus(WebSocketStatus status) {
    _status = status;
    _statusController.add(status);
  }

  Future<void> disconnect() async {
    _updateStatus(WebSocketStatus.disconnected);
    _stopHeartbeat();
    _reconnectTimer?.cancel();
    await _channel?.sink.close();
    _channel = null;
  }

  void dispose() {
    disconnect();
    _messageController.close();
    _statusController.close();
  }
}
