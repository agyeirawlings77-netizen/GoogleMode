// lib/core/validators/app_validators.dart

class AppValidators {
  static String? email(String? value) {
    if (value == null || value.isEmpty) return 'Email is required';
    final regex = RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
    if (!regex.hasMatch(value.trim())) return 'Enter a valid email address';
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.isEmpty) return 'Password is required';
    if (value.length < 8) return 'Password must be at least 8 characters';
    if (!value.contains(RegExp(r'[A-Z]'))) return 'Include at least one uppercase letter';
    if (!value.contains(RegExp(r'[0-9]'))) return 'Include at least one number';
    return null;
  }

  static String? confirmPassword(String? value, String original) {
    if (value == null || value.isEmpty) return 'Please confirm your password';
    if (value != original) return 'Passwords do not match';
    return null;
  }

  static String? name(String? value) {
    if (value == null || value.trim().isEmpty) return 'Name is required';
    if (value.trim().length < 2) return 'Name must be at least 2 characters';
    if (value.trim().length > 50) return 'Name must be less than 50 characters';
    return null;
  }

  static String? phone(String? value) {
    if (value == null || value.isEmpty) return null; // Optional
    final cleaned = value.replaceAll(RegExp(r'[\s\-\(\)]'), '');
    if (!RegExp(r'^\+?[0-9]{10,15}$').hasMatch(cleaned)) return 'Enter a valid phone number';
    return null;
  }

  static String? deviceName(String? value) {
    if (value == null || value.trim().isEmpty) return 'Device name is required';
    if (value.trim().length < 2) return 'Name must be at least 2 characters';
    if (value.trim().length > 30) return 'Name must be less than 30 characters';
    return null;
  }

  static String? required(String? value, {String field = 'This field'}) {
    if (value == null || value.trim().isEmpty) return '$field is required';
    return null;
  }

  static String? pin(String? value) {
    if (value == null || value.isEmpty) return 'PIN is required';
    if (value.length != 4) return 'PIN must be exactly 4 digits';
    if (!RegExp(r'^[0-9]{4}$').hasMatch(value)) return 'PIN must contain only digits';
    return null;
  }

  static String? pairingCode(String? value) {
    if (value == null || value.isEmpty) return 'Code is required';
    if (value.length != 6) return 'Code must be exactly 6 digits';
    if (!RegExp(r'^[0-9]{6}$').hasMatch(value)) return 'Code must contain only digits';
    return null;
  }

  static String? url(String? value) {
    if (value == null || value.isEmpty) return null;
    try {
      final uri = Uri.parse(value);
      if (!uri.hasScheme || (!uri.scheme.startsWith('http') && !uri.scheme.startsWith('ws'))) {
        return 'Enter a valid URL';
      }
    } catch (_) {
      return 'Enter a valid URL';
    }
    return null;
  }

  static String? minLength(String? value, int min, {String field = 'Field'}) {
    if (value == null || value.length < min) return '$field must be at least $min characters';
    return null;
  }

  static String? maxLength(String? value, int max, {String field = 'Field'}) {
    if (value != null && value.length > max) return '$field must be less than $max characters';
    return null;
  }
}
