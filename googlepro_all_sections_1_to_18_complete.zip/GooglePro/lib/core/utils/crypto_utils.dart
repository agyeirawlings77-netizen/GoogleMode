// lib/core/utils/crypto_utils.dart
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';

class CryptoUtils {
  static String generateRandomString(int length) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final rand = Random.secure();
    return List.generate(length, (_) => chars[rand.nextInt(chars.length)]).join();
  }

  static String generateSessionId() {
    return '${DateTime.now().millisecondsSinceEpoch}_${generateRandomString(8)}';
  }

  static String sha256Hash(String input) {
    final bytes = utf8.encode(input);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  static String md5Hash(String input) {
    final bytes = utf8.encode(input);
    final digest = md5.convert(bytes);
    return digest.toString();
  }

  static String base64Encode(String input) {
    return base64.encode(utf8.encode(input));
  }

  static String base64Decode(String encoded) {
    return utf8.decode(base64.decode(encoded));
  }

  static String generateDeviceFingerprint({
    required String deviceId,
    required String manufacturer,
    required String model,
  }) {
    final raw = '$deviceId-$manufacturer-$model';
    return sha256Hash(raw).substring(0, 16).toUpperCase();
  }

  static bool isValidUuid(String uuid) {
    final regex = RegExp(
      r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
      caseSensitive: false,
    );
    return regex.hasMatch(uuid);
  }
}
