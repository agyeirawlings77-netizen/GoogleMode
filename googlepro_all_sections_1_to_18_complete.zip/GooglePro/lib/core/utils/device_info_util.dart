// lib/core/utils/device_info_util.dart
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/services.dart';
import 'app_logger.dart';

class DeviceInfoUtil {
  DeviceInfoUtil._();

  static final _plugin = DeviceInfoPlugin();
  static AndroidDeviceInfo? _androidInfo;
  static IosDeviceInfo? _iosInfo;

  static Future<void> init() async {
    try {
      if (Platform.isAndroid) {
        _androidInfo = await _plugin.androidInfo;
      } else if (Platform.isIOS) {
        _iosInfo = await _plugin.iosInfo;
      }
    } catch (e) {
      AppLogger.e('DeviceInfoUtil init error: $e');
    }
  }

  static String get deviceId {
    if (Platform.isAndroid) {
      return _androidInfo?.id ?? 'unknown_android';
    } else if (Platform.isIOS) {
      return _iosInfo?.identifierForVendor ?? 'unknown_ios';
    }
    return 'unknown';
  }

  static String get deviceName {
    if (Platform.isAndroid) {
      return '${_androidInfo?.manufacturer ?? ''} ${_androidInfo?.model ?? ''}'.trim();
    } else if (Platform.isIOS) {
      return _iosInfo?.name ?? 'iPhone';
    }
    return 'Unknown Device';
  }

  static String get deviceType {
    if (Platform.isAndroid) return 'android';
    if (Platform.isIOS) return 'ios';
    return 'unknown';
  }

  static String get manufacturer {
    return _androidInfo?.manufacturer ?? 'Apple';
  }

  static String get model {
    if (Platform.isAndroid) return _androidInfo?.model ?? '';
    if (Platform.isIOS) return _iosInfo?.model ?? '';
    return '';
  }

  static String get osVersion {
    if (Platform.isAndroid) {
      return 'Android ${_androidInfo?.version.release ?? ''}';
    } else if (Platform.isIOS) {
      return 'iOS ${_iosInfo?.systemVersion ?? ''}';
    }
    return '';
  }

  static int get sdkInt {
    return _androidInfo?.version.sdkInt ?? 0;
  }

  static bool get isPhysicalDevice {
    if (Platform.isAndroid) return _androidInfo?.isPhysicalDevice ?? true;
    if (Platform.isIOS) return _iosInfo?.isPhysicalDevice ?? true;
    return true;
  }

  static Map<String, dynamic> toMap() => {
        'deviceId': deviceId,
        'deviceName': deviceName,
        'deviceType': deviceType,
        'manufacturer': manufacturer,
        'model': model,
        'osVersion': osVersion,
        'isPhysicalDevice': isPhysicalDevice,
      };

  static Future<String> getAndroidId() async {
    try {
      const channel = MethodChannel('com.rawlings.googlepro/device_info');
      final id = await channel.invokeMethod<String>('getAndroidId');
      return id ?? deviceId;
    } catch (_) {
      return deviceId;
    }
  }
}
