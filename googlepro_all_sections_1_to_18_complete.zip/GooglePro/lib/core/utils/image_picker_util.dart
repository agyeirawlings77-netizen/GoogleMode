// lib/core/utils/image_picker_util.dart
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/foundation.dart';

class ImagePickerUtil {
  static final _picker = ImagePicker();

  static Future<File?> pickFromGallery({
    double? maxWidth,
    double? maxHeight,
    int? imageQuality,
  }) async {
    try {
      final xFile = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        imageQuality: imageQuality ?? 85,
      );
      if (xFile == null) return null;
      return File(xFile.path);
    } catch (e) {
      debugPrint('Image gallery picker error: $e');
      return null;
    }
  }

  static Future<File?> pickFromCamera({
    double? maxWidth,
    double? maxHeight,
    int? imageQuality,
  }) async {
    try {
      final xFile = await _picker.pickImage(
        source: ImageSource.camera,
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        imageQuality: imageQuality ?? 85,
      );
      if (xFile == null) return null;
      return File(xFile.path);
    } catch (e) {
      debugPrint('Image camera picker error: $e');
      return null;
    }
  }

  static Future<File?> pickAvatar() async {
    return pickFromGallery(maxWidth: 512, maxHeight: 512, imageQuality: 80);
  }

  static Future<List<File>> pickMultipleImages({int? limit}) async {
    try {
      final xFiles = await _picker.pickMultiImage(imageQuality: 80);
      final files = xFiles.map((x) => File(x.path)).toList();
      if (limit != null && files.length > limit) return files.sublist(0, limit);
      return files;
    } catch (e) {
      debugPrint('Image multi picker error: $e');
      return [];
    }
  }

  static Future<File?> pickVideo({ImageSource source = ImageSource.gallery}) async {
    try {
      final xFile = await _picker.pickVideo(source: source);
      if (xFile == null) return null;
      return File(xFile.path);
    } catch (e) {
      debugPrint('Video picker error: $e');
      return null;
    }
  }
}
