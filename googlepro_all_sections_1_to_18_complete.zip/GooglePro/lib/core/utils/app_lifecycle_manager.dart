// lib/core/utils/app_lifecycle_manager.dart
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class AppLifecycleManager extends WidgetsBindingObserver {
  final VoidCallback? onResume;
  final VoidCallback? onPause;
  final VoidCallback? onDetach;

  AppLifecycleManager({this.onResume, this.onPause, this.onDetach}) {
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed: onResume?.call(); break;
      case AppLifecycleState.paused: onPause?.call(); break;
      case AppLifecycleState.detached: onDetach?.call(); break;
      default: break;
    }
  }

  void dispose() { WidgetsBinding.instance.removeObserver(this); }
}
