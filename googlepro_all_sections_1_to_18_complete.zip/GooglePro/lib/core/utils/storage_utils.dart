// lib/core/utils/storage_utils.dart
import 'package:shared_preferences/shared_preferences.dart';

class StorageUtils {
  static Future<void> setString(String key, String value) async =>
      (await SharedPreferences.getInstance()).setString(key, value);
  static Future<String?> getString(String key) async =>
      (await SharedPreferences.getInstance()).getString(key);
  static Future<void> setBool(String key, bool value) async =>
      (await SharedPreferences.getInstance()).setBool(key, value);
  static Future<bool?> getBool(String key) async =>
      (await SharedPreferences.getInstance()).getBool(key);
  static Future<void> setInt(String key, int value) async =>
      (await SharedPreferences.getInstance()).setInt(key, value);
  static Future<int?> getInt(String key) async =>
      (await SharedPreferences.getInstance()).getInt(key);
  static Future<void> remove(String key) async =>
      (await SharedPreferences.getInstance()).remove(key);
  static Future<bool> hasKey(String key) async =>
      (await SharedPreferences.getInstance()).containsKey(key);
}
