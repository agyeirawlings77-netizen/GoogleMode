// lib/core/utils/app_logger.dart
import 'package:flutter/foundation.dart';
import 'package:logger/logger.dart';

class AppLogger {
  AppLogger._();

  static final _logger = Logger(
    printer: PrettyPrinter(
      methodCount: 2,
      errorMethodCount: 8,
      lineLength: 120,
      colors: true,
      printEmojis: true,
      printTime: true,
    ),
    filter: kDebugMode ? DevelopmentFilter() : ProductionFilter(),
    level: kDebugMode ? Level.verbose : Level.warning,
  );

  static void v(dynamic message, [dynamic error, StackTrace? stackTrace]) {
    _logger.v(message, error: error, stackTrace: stackTrace);
  }

  static void d(dynamic message, [dynamic error, StackTrace? stackTrace]) {
    _logger.d(message, error: error, stackTrace: stackTrace);
  }

  static void i(dynamic message, [dynamic error, StackTrace? stackTrace]) {
    _logger.i(message, error: error, stackTrace: stackTrace);
  }

  static void w(dynamic message, [dynamic error, StackTrace? stackTrace]) {
    _logger.w(message, error: error, stackTrace: stackTrace);
  }

  static void e(dynamic message, [dynamic error, StackTrace? stackTrace]) {
    _logger.e(message, error: error, stackTrace: stackTrace);
  }

  static void wtf(dynamic message, [dynamic error, StackTrace? stackTrace]) {
    _logger.f(message, error: error, stackTrace: stackTrace);
  }

  // Feature-specific loggers
  static void webrtc(String message) => d('🎥 [WebRTC] $message');
  static void signaling(String message) => d('📡 [Signaling] $message');
  static void connection(String message) => d('🔌 [Connection] $message');
  static void auth(String message) => d('🔐 [Auth] $message');
  static void firebase(String message) => d('🔥 [Firebase] $message');
  static void network(String message) => d('🌐 [Network] $message');
  static void socket(String message) => d('🔗 [Socket] $message');
  static void liveScreen(String message) => d('📺 [LiveScreen] $message');
  static void remoteControl(String message) => d('🎮 [RemoteCtrl] $message');
  static void autoConnect(String message) => d('⚡ [AutoConnect] $message');
  static void notification(String message) => d('🔔 [Notification] $message');
  static void location(String message) => d('📍 [Location] $message');
  static void fileTransfer(String message) => d('📁 [FileTransfer] $message');
  static void chat(String message) => d('💬 [Chat] $message');
  static void analytics(String message) => d('📊 [Analytics] $message');
  static void backup(String message) => d('☁️ [Backup] $message');
  static void wearable(String message) => d('⌚ [Wearable] $message');
}
