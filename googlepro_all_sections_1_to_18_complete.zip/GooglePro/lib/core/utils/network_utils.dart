// lib/core/utils/network_utils.dart
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';

class NetworkUtils {
  static Future<bool> isConnected() async {
    try {
      final result = await Connectivity().checkConnectivity();
      return result != ConnectivityResult.none;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> isWifi() async {
    try {
      final result = await Connectivity().checkConnectivity();
      return result == ConnectivityResult.wifi;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> isMobile() async {
    try {
      final result = await Connectivity().checkConnectivity();
      return result == ConnectivityResult.mobile;
    } catch (_) {
      return false;
    }
  }

  static Stream<ConnectivityResult> get connectivityStream =>
      Connectivity().onConnectivityChanged;

  static String formatBytes(int bytes) {
    if (bytes >= 1073741824) return '${(bytes / 1073741824).toStringAsFixed(1)} GB';
    if (bytes >= 1048576) return '${(bytes / 1048576).toStringAsFixed(1)} MB';
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    return '$bytes B';
  }

  static String formatSpeed(int bytesPerSecond) {
    if (bytesPerSecond >= 1048576) {
      return '${(bytesPerSecond / 1048576).toStringAsFixed(1)} MB/s';
    }
    if (bytesPerSecond >= 1024) {
      return '${(bytesPerSecond / 1024).toStringAsFixed(0)} KB/s';
    }
    return '$bytesPerSecond B/s';
  }

  static bool isValidIpAddress(String ip) {
    final parts = ip.split('.');
    if (parts.length != 4) return false;
    return parts.every((p) {
      final n = int.tryParse(p);
      return n != null && n >= 0 && n <= 255;
    });
  }

  static bool isValidUrl(String url) {
    try {
      final uri = Uri.parse(url);
      return uri.hasScheme && (uri.scheme == 'http' || uri.scheme == 'https' ||
             uri.scheme == 'ws' || uri.scheme == 'wss');
    } catch (_) {
      return false;
    }
  }
}
