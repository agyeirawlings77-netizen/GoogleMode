// lib/core/utils/network_monitor.dart
import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';

class NetworkMonitor {
  static final _connectivity = Connectivity();
  static ConnectivityResult _current = ConnectivityResult.none;
  static bool get isConnected => _current != ConnectivityResult.none;
  static bool get isWifi => _current == ConnectivityResult.wifi;

  static Future<void> initialize() async {
    _current = await _connectivity.checkConnectivity();
    _connectivity.onConnectivityChanged.listen((result) { _current = result; });
  }

  static Future<bool> checkNow() async {
    _current = await _connectivity.checkConnectivity();
    return isConnected;
  }
}
