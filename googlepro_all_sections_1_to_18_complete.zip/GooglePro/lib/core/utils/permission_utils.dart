// lib/core/utils/permission_utils.dart
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionUtils {
  PermissionUtils._();

  static Future<bool> requestCamera() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  static Future<bool> requestMicrophone() async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  static Future<bool> requestLocation() async {
    final status = await Permission.locationWhenInUse.request();
    return status.isGranted;
  }

  static Future<bool> requestLocationAlways() async {
    final when = await Permission.locationWhenInUse.request();
    if (!when.isGranted) return false;
    final always = await Permission.locationAlways.request();
    return always.isGranted;
  }

  static Future<bool> requestStorage() async {
    final status = await Permission.storage.request();
    return status.isGranted;
  }

  static Future<bool> requestNotification() async {
    final status = await Permission.notification.request();
    return status.isGranted;
  }

  static Future<bool> requestBluetooth() async {
    final status = await Permission.bluetooth.request();
    return status.isGranted;
  }

  static Future<bool> requestPhone() async {
    final status = await Permission.phone.request();
    return status.isGranted;
  }

  static Future<bool> isGranted(Permission permission) async {
    return await permission.isGranted;
  }

  static Future<bool> isDenied(Permission permission) async {
    return await permission.isDenied;
  }

  static Future<bool> isPermanentlyDenied(Permission permission) async {
    return await permission.isPermanentlyDenied;
  }

  static Future<Map<Permission, PermissionStatus>> requestMultiple(
      List<Permission> permissions) async {
    return await permissions.request();
  }

  static Future<bool> requestAllRequired() async {
    final statuses = await [
      Permission.camera,
      Permission.microphone,
      Permission.notification,
      Permission.storage,
    ].request();

    return statuses.values.every((s) => s.isGranted);
  }

  static void openSettings() {
    openAppSettings();
  }

  static Future<void> showPermissionDialog(
    BuildContext context, {
    required String title,
    required String message,
    required VoidCallback onGranted,
    VoidCallback? onDenied,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Deny'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Grant'),
          ),
        ],
      ),
    );
    if (result == true) {
      onGranted();
    } else {
      onDenied?.call();
    }
  }
}
