// lib/core/utils/file_utils.dart
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:mime/mime.dart';

class FileUtils {
  static Future<Directory> getAppDirectory() async {
    final dir = await getApplicationDocumentsDirectory();
    return dir;
  }

  static Future<Directory> getScreenshotsDir() async {
    final base = await getAppDirectory();
    final dir = Directory('${base.path}/GooglePro/screenshots');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static Future<Directory> getRecordingsDir() async {
    final base = await getAppDirectory();
    final dir = Directory('${base.path}/GooglePro/recordings');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static Future<Directory> getDownloadsDir() async {
    final base = await getAppDirectory();
    final dir = Directory('${base.path}/GooglePro/downloads');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static String getExtension(String filePath) {
    return path.extension(filePath).toLowerCase();
  }

  static String getFileName(String filePath) {
    return path.basename(filePath);
  }

  static String? getMimeType(String filePath) {
    return lookupMimeType(filePath);
  }

  static bool isImage(String filePath) {
    final mime = getMimeType(filePath);
    return mime?.startsWith('image/') ?? false;
  }

  static bool isVideo(String filePath) {
    final mime = getMimeType(filePath);
    return mime?.startsWith('video/') ?? false;
  }

  static bool isAudio(String filePath) {
    final mime = getMimeType(filePath);
    return mime?.startsWith('audio/') ?? false;
  }

  static String formatSize(int bytes) {
    if (bytes >= 1073741824) return '${(bytes / 1073741824).toStringAsFixed(1)} GB';
    if (bytes >= 1048576) return '${(bytes / 1048576).toStringAsFixed(1)} MB';
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    return '$bytes B';
  }

  static Future<int> getFileSize(String filePath) async {
    final file = File(filePath);
    if (!await file.exists()) return 0;
    return await file.length();
  }

  static Future<bool> deleteFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  static String generateFileName(String prefix, String extension) {
    final ts = DateTime.now().millisecondsSinceEpoch;
    return '${prefix}_$ts$extension';
  }

  static Future<int> getDirectorySize(String dirPath) async {
    final dir = Directory(dirPath);
    if (!await dir.exists()) return 0;
    int total = 0;
    await for (final entity in dir.list(recursive: true)) {
      if (entity is File) {
        total += await entity.length();
      }
    }
    return total;
  }
}
