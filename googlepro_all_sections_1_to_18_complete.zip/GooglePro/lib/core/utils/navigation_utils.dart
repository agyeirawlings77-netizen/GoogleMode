// lib/core/utils/navigation_utils.dart
import 'package:flutter/material.dart';

class NavigationUtils {
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static BuildContext? get context => navigatorKey.currentContext;

  static void goBack() => navigatorKey.currentState?.pop();

  static void goBackWithResult(dynamic result) =>
      navigatorKey.currentState?.pop(result);

  static bool canPop() => navigatorKey.currentState?.canPop() ?? false;

  static Future<void> showLoadingDialog({String? message}) async {
    final ctx = context;
    if (ctx == null) return;
    return showDialog(
      context: ctx,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        content: Row(
          children: [
            const CircularProgressIndicator(),
            const SizedBox(width: 16),
            Expanded(child: Text(message ?? 'Please wait...')),
          ],
        ),
      ),
    );
  }

  static void hideLoadingDialog() {
    if (canPop()) goBack();
  }

  static Future<bool?> showConfirmDialog({
    required String title,
    required String message,
    String confirm = 'Confirm',
    String cancel = 'Cancel',
    bool isDanger = false,
  }) async {
    final ctx = context;
    if (ctx == null) return null;
    return showDialog<bool>(
      context: ctx,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => goBackWithResult(false), child: Text(cancel)),
          TextButton(
            onPressed: () => goBackWithResult(true),
            child: Text(confirm, style: TextStyle(color: isDanger ? Colors.red : null)),
          ),
        ],
      ),
    );
  }
}
