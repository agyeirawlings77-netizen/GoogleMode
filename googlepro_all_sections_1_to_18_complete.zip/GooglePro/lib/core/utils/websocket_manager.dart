// lib/core/utils/websocket_manager.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class WebSocketManager {
  static const _wsUrl = 'wss://googlepro-signaling.onrender.com/ws';
  WebSocketChannel? _channel;
  bool _connected = false;
  Timer? _pingTimer;
  final _msgCtrl = StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get messages => _msgCtrl.stream;
  bool get isConnected => _connected;

  Future<void> connect(String deviceId, String token) async {
    try {
      _channel = WebSocketChannel.connect(Uri.parse('$_wsUrl?deviceId=$deviceId&token=$token'));
      _connected = true;
      _channel!.stream.listen(
        (data) { try { _msgCtrl.add(jsonDecode(data.toString()) as Map<String, dynamic>); } catch (_) {} },
        onDone: () { _connected = false; },
        onError: (_) { _connected = false; },
      );
      _pingTimer = Timer.periodic(const Duration(seconds: 25), (_) => send({'type': 'ping'}));
    } catch (e) { _connected = false; debugPrint('WS connect error: $e'); }
  }

  void send(Map<String, dynamic> message) {
    if (_connected && _channel != null) {
      try { _channel!.sink.add(jsonEncode(message)); } catch (_) {}
    }
  }

  Future<void> disconnect() async {
    _pingTimer?.cancel();
    await _channel?.sink.close();
    _channel = null; _connected = false;
  }

  void dispose() { disconnect(); _msgCtrl.close(); }
}
