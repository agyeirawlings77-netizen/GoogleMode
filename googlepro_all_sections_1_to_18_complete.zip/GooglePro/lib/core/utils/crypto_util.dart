// lib/core/utils/crypto_util.dart
import 'dart:convert';
import 'package:crypto/crypto.dart';

class CryptoUtil {
  static String sha256Hash(String input) {
    final bytes = utf8.encode(input);
    return sha256.convert(bytes).toString();
  }

  static String md5Hash(String input) {
    final bytes = utf8.encode(input);
    return md5.convert(bytes).toString();
  }

  static String generateSessionId() {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final random = timestamp ^ (timestamp >> 16);
    return sha256Hash('session_$random').substring(0, 32);
  }

  static String generatePairingCode() {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return (100000 + (timestamp % 900000)).toString();
  }

  static bool verifyPin(String pin, String storedHash) {
    return sha256Hash(pin) == storedHash;
  }

  static String hashPin(String pin) => sha256Hash(pin);

  static String generateDeviceToken(String deviceId, String userId) {
    final payload = '$deviceId:$userId:${DateTime.now().millisecondsSinceEpoch}';
    return base64.encode(utf8.encode(sha256Hash(payload)));
  }
}
