// lib/core/utils/throttler.dart
import 'dart:async';

class Throttler {
  final Duration duration;
  DateTime? _lastRun;

  Throttler({this.duration = const Duration(milliseconds: 300)});

  bool throttle(void Function() action) {
    final now = DateTime.now();
    if (_lastRun == null || now.difference(_lastRun!) >= duration) {
      _lastRun = now;
      action();
      return true;
    }
    return false;
  }
}
