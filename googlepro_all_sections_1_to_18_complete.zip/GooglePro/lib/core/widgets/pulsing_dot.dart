// lib/core/widgets/pulsing_dot.dart
import 'package:flutter/material.dart';
class PulsingDot extends StatefulWidget {
  final Color color; final double size;
  const PulsingDot({super.key, this.color = Colors.green, this.size = 10});
  @override State<PulsingDot> createState() => _State();
}
class _State extends State<PulsingDot> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;
  @override void initState() { super.initState(); _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat(reverse: true); _anim = Tween<double>(begin: 0.6, end: 1.0).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut)); }
  @override void dispose() { _ctrl.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => FadeTransition(opacity: _anim, child: CircleAvatar(radius: widget.size / 2, backgroundColor: widget.color));
}
