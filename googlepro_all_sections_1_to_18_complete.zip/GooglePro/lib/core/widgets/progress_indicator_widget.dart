// lib/core/widgets/progress_indicator_widget.dart
import 'package:flutter/material.dart';

class LabeledProgressBar extends StatelessWidget {
  final String label;
  final double value;
  final String? valueLabel;
  final Color? color;
  final double height;
  const LabeledProgressBar({super.key, required this.label, required this.value, this.valueLabel, this.color, this.height = 8});

  @override
  Widget build(BuildContext context) {
    final barColor = color ?? Theme.of(context).colorScheme.primary;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 13)),
        Text(valueLabel ?? '${(value * 100).round()}%', style: TextStyle(color: barColor, fontWeight: FontWeight.bold, fontSize: 13)),
      ]),
      const SizedBox(height: 6),
      ClipRRect(
        borderRadius: BorderRadius.circular(height / 2),
        child: LinearProgressIndicator(
          value: value.clamp(0.0, 1.0), minHeight: height,
          backgroundColor: Colors.grey.withOpacity(0.2),
          valueColor: AlwaysStoppedAnimation<Color>(barColor),
        ),
      ),
    ]);
  }
}
