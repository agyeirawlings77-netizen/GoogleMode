// lib/core/widgets/app_bar_widget.dart
import 'package:flutter/material.dart';

class AppBarWidget extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget>? actions;
  final Widget? leading;
  final bool showBack;
  const AppBarWidget({super.key, required this.title, this.actions, this.leading, this.showBack = true});

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) => AppBar(
    title: Text(title),
    actions: actions,
    leading: leading,
    automaticallyImplyLeading: showBack,
  );
}
