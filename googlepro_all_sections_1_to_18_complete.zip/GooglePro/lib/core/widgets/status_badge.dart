// lib/core/widgets/status_badge.dart
import 'package:flutter/material.dart';

enum StatusType { online, offline, connecting, warning, error, success }

class StatusBadge extends StatelessWidget {
  final StatusType status;
  final String? label;
  final double size;
  final bool showLabel;

  const StatusBadge({
    super.key,
    required this.status,
    this.label,
    this.size = 10,
    this.showLabel = false,
  });

  Color get _color {
    switch (status) {
      case StatusType.online: return Colors.green;
      case StatusType.offline: return Colors.grey;
      case StatusType.connecting: return Colors.orange;
      case StatusType.warning: return Colors.orange;
      case StatusType.error: return Colors.red;
      case StatusType.success: return Colors.green;
    }
  }

  String get _defaultLabel {
    switch (status) {
      case StatusType.online: return 'Online';
      case StatusType.offline: return 'Offline';
      case StatusType.connecting: return 'Connecting';
      case StatusType.warning: return 'Warning';
      case StatusType.error: return 'Error';
      case StatusType.success: return 'Success';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!showLabel) {
      return Container(
        width: size, height: size,
        decoration: BoxDecoration(color: _color, shape: BoxShape.circle),
      );
    }
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: size, height: size, decoration: BoxDecoration(color: _color, shape: BoxShape.circle)),
        const SizedBox(width: 4),
        Text(label ?? _defaultLabel,
            style: TextStyle(color: _color, fontSize: 12, fontWeight: FontWeight.w500)),
      ],
    );
  }
}

class OnlineBadge extends StatelessWidget {
  final bool isOnline;
  final bool showLabel;
  const OnlineBadge({super.key, required this.isOnline, this.showLabel = true});

  @override
  Widget build(BuildContext context) => StatusBadge(
    status: isOnline ? StatusType.online : StatusType.offline,
    showLabel: showLabel,
  );
}
