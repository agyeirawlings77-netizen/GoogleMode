// lib/core/widgets/online_badge.dart
import 'package:flutter/material.dart';
class OnlineBadge extends StatelessWidget {
  final bool isOnline; final double size;
  const OnlineBadge({super.key, required this.isOnline, this.size = 10});
  @override Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    CircleAvatar(radius: size / 2, backgroundColor: isOnline ? Colors.green : Colors.grey),
    const SizedBox(width: 4),
    Text(isOnline ? 'Online' : 'Offline', style: TextStyle(color: isOnline ? Colors.green : Colors.grey, fontSize: size * 1.2)),
  ]);
}
