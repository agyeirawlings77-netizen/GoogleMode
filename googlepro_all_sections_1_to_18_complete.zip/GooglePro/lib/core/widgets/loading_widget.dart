// lib/core/widgets/loading_widget.dart
import 'package:flutter/material.dart';
class LoadingWidget extends StatelessWidget {
  final String? message;
  const LoadingWidget({super.key, this.message});
  @override Widget build(BuildContext context) => Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const CircularProgressIndicator(),
    if (message != null) ...[const SizedBox(height: 16), Text(message!, style: const TextStyle(color: Colors.grey))],
  ]));
}
