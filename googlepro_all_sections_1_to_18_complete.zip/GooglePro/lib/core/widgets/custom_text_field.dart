// lib/core/widgets/custom_text_field.dart
import 'package:flutter/material.dart';
class CustomTextField extends StatelessWidget {
  final TextEditingController controller; final String label; final IconData? icon; final bool obscure; final TextInputType? type; final String? Function(String?)? validator; final VoidCallback? onToggleObscure;
  const CustomTextField({super.key, required this.controller, required this.label, this.icon, this.obscure = false, this.type, this.validator, this.onToggleObscure});
  @override Widget build(BuildContext context) => TextFormField(controller: controller, obscureText: obscure, keyboardType: type, validator: validator,
    decoration: InputDecoration(labelText: label, prefixIcon: icon != null ? Icon(icon) : null, suffixIcon: onToggleObscure != null ? IconButton(icon: Icon(obscure ? Icons.visibility : Icons.visibility_off), onPressed: onToggleObscure) : null));
}
