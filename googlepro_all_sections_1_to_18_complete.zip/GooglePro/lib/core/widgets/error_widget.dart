// lib/core/widgets/error_widget.dart
import 'package:flutter/material.dart';
class AppErrorWidget extends StatelessWidget {
  final String message; final VoidCallback? onRetry;
  const AppErrorWidget({super.key, required this.message, this.onRetry});
  @override Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const Icon(Icons.error_outline, size: 64, color: Colors.red),
    const SizedBox(height: 16),
    const Text('Something went wrong', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    Text(message, style: const TextStyle(color: Colors.grey), textAlign: TextAlign.center),
    if (onRetry != null) ...[const SizedBox(height: 24), ElevatedButton.icon(icon: const Icon(Icons.refresh), label: const Text('Retry'), onPressed: onRetry)],
  ])));
}
