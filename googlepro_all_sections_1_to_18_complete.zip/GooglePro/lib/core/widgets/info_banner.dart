// lib/core/widgets/info_banner.dart
import 'package:flutter/material.dart';
enum BannerType { info, success, warning, error }
class InfoBanner extends StatelessWidget {
  final String message; final BannerType type; final VoidCallback? onDismiss;
  const InfoBanner({super.key, required this.message, this.type = BannerType.info, this.onDismiss});
  @override Widget build(BuildContext context) {
    final colors = {BannerType.info: Colors.blue, BannerType.success: Colors.green, BannerType.warning: Colors.orange, BannerType.error: Colors.red};
    final icons = {BannerType.info: Icons.info_outline, BannerType.success: Icons.check_circle_outline, BannerType.warning: Icons.warning_amber_outlined, BannerType.error: Icons.error_outline};
    final color = colors[type]!;
    return Container(margin: const EdgeInsets.all(12), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: color.withOpacity(0.3))), child: Row(children: [
      Icon(icons[type], color: color, size: 20),
      const SizedBox(width: 8),
      Expanded(child: Text(message, style: TextStyle(color: color))),
      if (onDismiss != null) GestureDetector(onTap: onDismiss, child: Icon(Icons.close, color: color, size: 18)),
    ]));
  }
}
