// lib/core/widgets/device_avatar.dart
import 'package:flutter/material.dart';

class DeviceAvatar extends StatelessWidget {
  final String deviceType;
  final bool isOnline;
  final double radius;
  final Color? backgroundColor;

  const DeviceAvatar({
    super.key,
    required this.deviceType,
    this.isOnline = false,
    this.radius = 24,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        CircleAvatar(
          radius: radius,
          backgroundColor: backgroundColor ??
              Theme.of(context).colorScheme.primary.withOpacity(0.12),
          child: Icon(
            deviceType == 'ios' ? Icons.phone_iphone : Icons.phone_android,
            color: Theme.of(context).colorScheme.primary,
            size: radius * 1.1,
          ),
        ),
        Positioned(
          bottom: 0, right: 0,
          child: CircleAvatar(
            radius: radius * 0.28,
            backgroundColor: isOnline ? Colors.green : Colors.grey,
          ),
        ),
      ],
    );
  }
}
