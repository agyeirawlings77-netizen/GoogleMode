// lib/core/widgets/network_aware_widget.dart
import 'package:flutter/material.dart';

class NetworkAwareWidget extends StatelessWidget {
  final Widget child;
  final Widget? offlineWidget;
  final bool isConnected;
  const NetworkAwareWidget({super.key, required this.child, this.offlineWidget, required this.isConnected});

  @override
  Widget build(BuildContext context) {
    if (isConnected) return child;
    return offlineWidget ?? Column(children: [
      Container(width: double.infinity, color: Colors.red, padding: const EdgeInsets.symmetric(vertical: 6),
          child: const Text('No internet connection', style: TextStyle(color: Colors.white), textAlign: TextAlign.center)),
      Expanded(child: child),
    ]);
  }
}
