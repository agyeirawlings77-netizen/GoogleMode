// lib/core/widgets/device_card.dart
import 'package:flutter/material.dart';
class DeviceCard extends StatelessWidget {
  final String deviceName; final bool isOnline; final String? model; final String? status; final VoidCallback? onTap; final List<Widget> actions;
  const DeviceCard({super.key, required this.deviceName, required this.isOnline, this.model, this.status, this.onTap, this.actions = const []});
  @override Widget build(BuildContext context) => Card(child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(12), child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
    Stack(children: [
      CircleAvatar(radius: 24, backgroundColor: isOnline ? Colors.blue.withOpacity(0.1) : Colors.grey.withOpacity(0.1), child: Icon(Icons.phone_android, color: isOnline ? Colors.blue : Colors.grey)),
      if (isOnline) const Positioned(bottom: 0, right: 0, child: CircleAvatar(radius: 7, backgroundColor: Colors.green)),
    ]),
    const SizedBox(width: 12),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(deviceName, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
      if (model != null) Text(model!, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      Text(status ?? (isOnline ? '● Online' : '○ Offline'), style: TextStyle(color: isOnline ? Colors.green : Colors.grey, fontSize: 12)),
    ])),
    ...actions,
    if (actions.isEmpty) const Icon(Icons.chevron_right, color: Colors.grey),
  ]))));
}
