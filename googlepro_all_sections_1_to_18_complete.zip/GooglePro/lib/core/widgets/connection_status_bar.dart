// lib/core/widgets/connection_status_bar.dart
import 'package:flutter/material.dart';

class ConnectionStatusBar extends StatelessWidget {
  final bool isConnected;
  const ConnectionStatusBar({super.key, required this.isConnected});

  @override
  Widget build(BuildContext context) {
    if (isConnected) return const SizedBox.shrink();
    return MaterialBanner(
      backgroundColor: Colors.red.shade700,
      content: const Text('No internet connection', style: TextStyle(color: Colors.white)),
      leading: const Icon(Icons.wifi_off, color: Colors.white),
      actions: [TextButton(onPressed: () {}, child: const Text('Retry', style: TextStyle(color: Colors.white)))],
    );
  }
}
