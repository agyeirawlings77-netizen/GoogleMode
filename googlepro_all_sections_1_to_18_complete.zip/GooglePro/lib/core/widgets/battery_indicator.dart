// lib/core/widgets/battery_indicator.dart
import 'package:flutter/material.dart';

class BatteryIndicator extends StatelessWidget {
  final int level;
  final bool isCharging;
  final double height;
  final double width;
  final bool showPercentage;
  final bool showLabel;

  const BatteryIndicator({
    super.key,
    required this.level,
    this.isCharging = false,
    this.height = 14,
    this.width = 28,
    this.showPercentage = false,
    this.showLabel = false,
  });

  Color get _color {
    if (isCharging) return Colors.green;
    if (level <= 10) return Colors.red;
    if (level <= 20) return Colors.orange;
    return Colors.green;
  }

  IconData get _icon {
    if (isCharging) return Icons.battery_charging_full;
    if (level > 90) return Icons.battery_full;
    if (level > 60) return Icons.battery_6_bar;
    if (level > 40) return Icons.battery_4_bar;
    if (level > 20) return Icons.battery_2_bar;
    if (level > 10) return Icons.battery_1_bar;
    return Icons.battery_alert;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(_icon, color: _color, size: height + 4),
        if (showPercentage || showLabel) ...[
          const SizedBox(width: 2),
          Text(
            '$level%',
            style: TextStyle(color: _color, fontSize: 12, fontWeight: FontWeight.w500),
          ),
        ],
      ],
    );
  }
}
