// lib/core/widgets/custom_snackbar.dart
import 'package:flutter/material.dart';

enum SnackbarType { success, error, warning, info }

class CustomSnackbar {
  static void show(
    BuildContext context, {
    required String message,
    SnackbarType type = SnackbarType.info,
    Duration duration = const Duration(seconds: 3),
    VoidCallback? onAction,
    String? actionLabel,
  }) {
    Color backgroundColor;
    IconData icon;
    switch (type) {
      case SnackbarType.success: backgroundColor = Colors.green; icon = Icons.check_circle; break;
      case SnackbarType.error: backgroundColor = Colors.red; icon = Icons.error_outline; break;
      case SnackbarType.warning: backgroundColor = Colors.orange; icon = Icons.warning_amber; break;
      case SnackbarType.info: backgroundColor = Colors.blue; icon = Icons.info_outline; break;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: backgroundColor,
        duration: duration,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        content: Row(
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 8),
            Expanded(child: Text(message, style: const TextStyle(color: Colors.white))),
          ],
        ),
        action: onAction != null && actionLabel != null
            ? SnackBarAction(label: actionLabel, textColor: Colors.white, onPressed: onAction)
            : null,
      ),
    );
  }

  static void success(BuildContext context, String message) =>
      show(context, message: message, type: SnackbarType.success);

  static void error(BuildContext context, String message) =>
      show(context, message: message, type: SnackbarType.error);

  static void warning(BuildContext context, String message) =>
      show(context, message: message, type: SnackbarType.warning);

  static void info(BuildContext context, String message) =>
      show(context, message: message, type: SnackbarType.info);
}
