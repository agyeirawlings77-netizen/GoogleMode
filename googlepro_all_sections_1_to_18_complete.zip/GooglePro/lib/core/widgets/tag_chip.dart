// lib/core/widgets/tag_chip.dart
import 'package:flutter/material.dart';

class TagChip extends StatelessWidget {
  final String label;
  final Color? color;
  final IconData? icon;
  final VoidCallback? onRemove;
  const TagChip({super.key, required this.label, this.color, this.icon, this.onRemove});

  @override
  Widget build(BuildContext context) {
    final chipColor = color ?? Theme.of(context).colorScheme.primary;
    return Chip(
      label: Text(label, style: TextStyle(color: chipColor, fontSize: 12)),
      avatar: icon != null ? Icon(icon, size: 14, color: chipColor) : null,
      backgroundColor: chipColor.withOpacity(0.1),
      deleteIcon: onRemove != null ? Icon(Icons.close, size: 14, color: chipColor) : null,
      onDeleted: onRemove,
      side: BorderSide(color: chipColor.withOpacity(0.3)),
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      padding: const EdgeInsets.symmetric(horizontal: 4),
    );
  }
}
