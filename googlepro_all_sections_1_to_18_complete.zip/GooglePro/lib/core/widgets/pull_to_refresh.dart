// lib/core/widgets/pull_to_refresh.dart
import 'package:flutter/material.dart';

class PullToRefresh extends StatelessWidget {
  final Widget child;
  final Future<void> Function() onRefresh;
  const PullToRefresh({super.key, required this.child, required this.onRefresh});

  @override
  Widget build(BuildContext context) => RefreshIndicator(onRefresh: onRefresh, child: child);
}
