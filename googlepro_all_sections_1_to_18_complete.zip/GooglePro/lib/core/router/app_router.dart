// lib/core/router/app_router.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Auth
import '../../features/auth/ui/splash_screen.dart';
import '../../features/auth/ui/welcome_screen.dart';
import '../../features/auth/ui/login_screen.dart';
import '../../features/auth/ui/register_screen.dart';
import '../../features/auth/ui/forgot_password_screen.dart';
import '../../features/auth/ui/otp_screen.dart';
import '../../features/auth/ui/biometric_login_screen.dart';
import '../../features/onboarding/ui/onboarding_screen.dart';

// Dashboard
import '../../features/dashboard/ui/dashboard_screen.dart';
import '../../features/dashboard/ui/main_nav_shell.dart';
import '../../features/dashboard/ui/notification_screen.dart';

// Devices
import '../../features/device_management/ui/devices_screen.dart';
import '../../features/device_management/ui/device_detail_screen.dart';
import '../../features/device_management/ui/add_device_screen.dart';
import '../../features/device_management/ui/qr_pairing_screen.dart';
import '../../features/device_management/ui/scan_qr_screen.dart';
import '../../features/device_management/ui/show_qr_screen.dart';

// Live Screen
import '../../features/live_screen/ui/live_screen_viewer_screen.dart';
import '../../features/live_screen/ui/live_screen_history_screen.dart';

// Remote Control
import '../../features/remote_control/ui/remote_control_screen.dart';

// Session
import '../../features/session/ui/session_history_screen.dart';
import '../../features/session/ui/screen_viewer_screen.dart';
import '../../features/session/ui/incoming_call_screen.dart';
import '../../features/session/ui/session_ended_screen.dart';

// Profile
import '../../features/profile/ui/profile_screen.dart';
import '../../features/profile/ui/edit_profile_screen.dart';

// Settings
import '../../features/settings/ui/settings_screen.dart';
import '../../features/settings/ui/about_screen.dart';
import '../../features/settings/ui/language_settings_screen.dart';
import '../../features/settings/ui/notification_settings_screen.dart';
import '../../features/settings/ui/security_screen.dart';
import '../../features/settings/ui/advanced_settings_screen.dart';
import '../../features/settings/ui/storage_settings_screen.dart';
import '../../features/settings/ui/connection_settings_screen.dart';

// Features
import '../../features/chat/ui/chat_screen.dart';
import '../../features/chat/ui/chat_list_screen.dart';
import '../../features/file_transfer/ui/file_transfer_screen.dart';
import '../../features/location/ui/location_screen.dart';
import '../../features/location/ui/location_history_screen.dart';
import '../../features/voice_call/ui/voice_call_screen.dart';
import '../../features/parental_controls/ui/parental_controls_screen.dart';
import '../../features/parental_controls/ui/app_blocking_screen.dart';
import '../../features/parental_controls/ui/screen_time_detail_screen.dart';
import '../../features/parental_controls/ui/content_filter_screen.dart';
import '../../features/ai_assistant/ui/ai_assistant_screen.dart';
import '../../features/security/ui/security_screen.dart';
import '../../features/security/ui/security_alerts_screen.dart';
import '../../features/analytics/ui/analytics_screen.dart';
import '../../features/cloud_backup/ui/cloud_backup_screen.dart';
import '../../features/wearable/ui/wearable_screen.dart';
import '../../features/focus_mode/ui/focus_mode_screen.dart';
import '../../features/remote_status/ui/remote_status_screen.dart';
import '../../features/theme/ui/theme_settings_screen.dart';
import '../../features/trusted_device/ui/trusted_devices_screen.dart';
import '../../features/notifications/ui/notifications_screen.dart';
import '../../features/app_lock/ui/app_lock_screen.dart';
import '../../features/app_lock/ui/setup_pin_screen.dart';

class AppRouter {
  static final _rootNavigatorKey = GlobalKey<NavigatorState>();
  static final _shellNavigatorKey = GlobalKey<NavigatorState>();

  static GoRouter get router => _router;

  static final _router = GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/splash',
    redirect: (context, state) {
      final loggedIn = FirebaseAuth.instance.currentUser != null;
      final onAuthPath = state.matchedLocation.startsWith('/auth') ||
          state.matchedLocation == '/splash' ||
          state.matchedLocation == '/onboarding';

      if (!loggedIn && !onAuthPath) return '/auth/welcome';
      return null;
    },
    routes: [
      // Splash
      GoRoute(
        path: '/splash',
        builder: (context, state) => const SplashScreen(),
      ),

      // Onboarding
      GoRoute(
        path: '/onboarding',
        builder: (context, state) => const OnboardingScreen(),
      ),

      // Auth routes
      GoRoute(
        path: '/auth/welcome',
        builder: (context, state) => const WelcomeScreen(),
      ),
      GoRoute(
        path: '/auth/login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/auth/register',
        builder: (context, state) => const RegisterScreen(),
      ),
      GoRoute(
        path: '/auth/forgot-password',
        builder: (context, state) => const ForgotPasswordScreen(),
      ),
      GoRoute(
        path: '/auth/otp',
        builder: (context, state) => const OtpScreen(),
      ),
      GoRoute(
        path: '/auth/biometric',
        builder: (context, state) => const BiometricLoginScreen(),
      ),

      // Main shell with bottom nav
      ShellRoute(
        navigatorKey: _shellNavigatorKey,
        builder: (context, state, child) => MainNavShell(child: child),
        routes: [
          GoRoute(
            path: '/dashboard',
            builder: (context, state) => const DashboardScreen(),
          ),
          GoRoute(
            path: '/devices',
            builder: (context, state) => const DevicesScreen(),
          ),
          GoRoute(
            path: '/notifications',
            builder: (context, state) => const NotificationsScreen(),
          ),
          GoRoute(
            path: '/profile',
            builder: (context, state) => const ProfileScreen(),
          ),
        ],
      ),

      // Device routes (full screen)
      GoRoute(
        path: '/devices/:deviceId',
        builder: (context, state) => DeviceDetailScreen(
          deviceId: state.pathParameters['deviceId']!,
        ),
      ),
      GoRoute(
        path: '/devices/add',
        builder: (context, state) => const AddDeviceScreen(),
      ),
      GoRoute(
        path: '/devices/qr-pair',
        builder: (context, state) => const QrPairingScreen(),
      ),
      GoRoute(
        path: '/devices/scan-qr',
        builder: (context, state) => const ScanQrScreen(),
      ),
      GoRoute(
        path: '/devices/show-qr',
        builder: (context, state) => const ShowQrScreen(),
      ),

      // Live Screen
      GoRoute(
        path: '/live-screen',
        builder: (context, state) {
          final extra = state.extra as Map<String, String>?;
          return LiveScreenViewerScreen(
            targetDeviceId: extra?['deviceId'] ?? '',
            targetUserId: extra?['userId'] ?? '',
            deviceName: extra?['deviceName'] ?? 'Device',
          );
        },
      ),
      GoRoute(
        path: '/live-screen/history',
        builder: (context, state) => const Placeholder(),
      ),

      // Remote Control
      GoRoute(
        path: '/remote-control',
        builder: (context, state) => const RemoteControlScreen(),
      ),

      // Session
      GoRoute(
        path: '/session/history',
        builder: (context, state) => const SessionHistoryScreen(),
      ),
      GoRoute(
        path: '/session/viewer',
        builder: (context, state) => const ScreenViewerScreen(),
      ),
      GoRoute(
        path: '/session/incoming',
        builder: (context, state) => const IncomingCallScreen(),
      ),
      GoRoute(
        path: '/session/ended',
        builder: (context, state) => const SessionEndedScreen(),
      ),

      // Chat
      GoRoute(
        path: '/chat',
        builder: (context, state) => const ChatListScreen(),
      ),
      GoRoute(
        path: '/chat/:sessionId',
        builder: (context, state) => ChatScreen(
          sessionId: state.pathParameters['sessionId'] ?? '',
        ),
      ),

      // File Transfer
      GoRoute(
        path: '/file-transfer',
        builder: (context, state) => const FileTransferScreen(),
      ),

      // Location
      GoRoute(
        path: '/location',
        builder: (context, state) => const LocationScreen(),
      ),
      GoRoute(
        path: '/location/history',
        builder: (context, state) => const LocationHistoryScreen(),
      ),

      // Voice Call
      GoRoute(
        path: '/voice-call',
        builder: (context, state) => const VoiceCallScreen(),
      ),

      // Parental Controls
      GoRoute(
        path: '/parental-controls',
        builder: (context, state) => const ParentalControlsScreen(),
      ),
      GoRoute(
        path: '/parental-controls/app-blocking',
        builder: (context, state) => const AppBlockingScreen(),
      ),
      GoRoute(
        path: '/parental-controls/screen-time',
        builder: (context, state) => const ScreenTimeDetailScreen(),
      ),
      GoRoute(
        path: '/parental-controls/content-filter',
        builder: (context, state) => const ContentFilterScreen(),
      ),

      // Remote Status
      GoRoute(
        path: '/remote-status/:deviceId',
        builder: (context, state) {
          final extra = state.extra as Map<String, String>?;
          return RemoteStatusScreen(
            deviceId: state.pathParameters['deviceId']!,
            deviceName: extra?['deviceName'] ?? 'Device',
          );
        },
      ),

      // AI Assistant
      GoRoute(
        path: '/ai-assistant',
        builder: (context, state) => const AiAssistantScreen(),
      ),

      // Security
      GoRoute(
        path: '/security',
        builder: (context, state) => const SecurityScreen(),
      ),
      GoRoute(
        path: '/security/alerts',
        builder: (context, state) => const SecurityAlertsScreen(),
      ),

      // Analytics
      GoRoute(
        path: '/analytics',
        builder: (context, state) => const AnalyticsScreen(),
      ),

      // Cloud Backup
      GoRoute(
        path: '/cloud-backup',
        builder: (context, state) => const CloudBackupScreen(),
      ),

      // Wearable
      GoRoute(
        path: '/wearable',
        builder: (context, state) => const WearableScreen(),
      ),

      // Focus Mode
      GoRoute(
        path: '/focus-mode',
        builder: (context, state) {
          final extra = state.extra as Map<String, String>?;
          return FocusModeScreen(
            targetDeviceId: extra?['deviceId'],
            targetDeviceName: extra?['deviceName'],
          );
        },
      ),

      // Trusted Devices
      GoRoute(
        path: '/trusted-devices',
        builder: (context, state) => const TrustedDevicesScreen(),
      ),

      // App Lock
      GoRoute(
        path: '/app-lock',
        builder: (context, state) => const AppLockScreen(),
      ),
      GoRoute(
        path: '/app-lock/setup',
        builder: (context, state) => const SetupPinScreen(),
      ),

      // Theme
      GoRoute(
        path: '/theme',
        builder: (context, state) => const ThemeSettingsScreen(),
      ),

      // Profile
      GoRoute(
        path: '/profile/edit',
        builder: (context, state) => const EditProfileScreen(),
      ),

      // Settings routes
      GoRoute(
        path: '/settings',
        builder: (context, state) => const SettingsScreen(),
      ),
      GoRoute(
        path: '/settings/about',
        builder: (context, state) => const AboutScreen(),
      ),
      GoRoute(
        path: '/settings/language',
        builder: (context, state) => const LanguageSettingsScreen(),
      ),
      GoRoute(
        path: '/settings/notifications',
        builder: (context, state) => const NotificationSettingsScreen(),
      ),
      GoRoute(
        path: '/settings/advanced',
        builder: (context, state) => const AdvancedSettingsScreen(),
      ),
      GoRoute(
        path: '/settings/storage',
        builder: (context, state) => const StorageSettingsScreen(),
      ),
      GoRoute(
        path: '/settings/connection',
        builder: (context, state) => const ConnectionSettingsScreen(),
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            Text('Page not found: ${state.error}'),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => context.go('/dashboard'),
              child: const Text('Go Home'),
            ),
          ],
        ),
      ),
    ),
  );
}
