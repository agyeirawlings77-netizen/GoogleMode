// lib/core/di/service_locator.dart
import 'package:get_it/get_it.dart';

// Firebase
import '../firebase/firebase_auth_service.dart';
import '../firebase/firestore_service.dart';
import '../firebase/realtime_db_service.dart';
import '../firebase/fcm_service.dart';

// Services
import '../services/secure_storage_service.dart';
import '../services/local_storage_service.dart';
import '../services/connectivity_service.dart';
import '../services/push_notification_service.dart';
import '../services/trusted_device_manager.dart';

// Features - Repositories
import '../../features/auth/repository/auth_repository.dart';
import '../../features/auth/repository/auth_repository_impl.dart';
import '../../features/device_management/repository/device_repository.dart';
import '../../features/device_management/repository/device_repository_impl.dart';
import '../../features/session/repository/session_repository.dart';
import '../../features/session/repository/session_repository_impl.dart';
import '../../features/chat/repository/chat_repository.dart';
import '../../features/chat/repository/chat_repository_impl.dart';
import '../../features/settings/repository/settings_repository.dart';
import '../../features/settings/repository/settings_repository_impl.dart';
import '../../features/trusted_device/repository/trusted_device_repository.dart';
import '../../features/trusted_device/repository/trusted_device_repository_impl.dart';
import '../../features/notifications/repository/notification_repository.dart';
import '../../features/notifications/repository/notification_repository_impl.dart';
import '../../features/profile/repository/profile_repository.dart';
import '../../features/profile/repository/profile_repository_impl.dart';
import '../../features/security/repository/security_repository.dart';
import '../../features/security/repository/security_repository_impl.dart';
import '../../features/live_screen/repository/live_screen_repository.dart';
import '../../features/live_screen/repository/live_screen_repository_impl.dart';
import '../../features/remote_status/repository/remote_status_repository.dart';
import '../../features/remote_alarm/repository/remote_alarm_repository.dart';
import '../../features/cloud_backup/repository/backup_repository.dart';
import '../../features/focus_mode/repository/focus_mode_repository.dart';
import '../../features/wearable/repository/wearable_repository.dart';
import '../../features/analytics/repository/analytics_repository.dart';

// Services (feature-level)
import '../../features/live_screen/service/live_screen_service.dart';
import '../../features/remote_status/service/remote_status_service.dart';
import '../../features/remote_alarm/service/remote_alarm_service.dart';
import '../../features/focus_mode/service/focus_mode_service.dart';
import '../../features/wearable/service/wearable_service.dart';
import '../../features/cloud_backup/service/backup_service.dart';
import '../../features/analytics/service/analytics_tracker_service.dart';
import '../../features/webrtc/service/webrtc_service.dart';
import '../../features/signaling/service/signaling_service.dart';

// BLoCs
import '../../features/auth/viewmodel/auth_bloc.dart';
import '../../features/dashboard/viewmodel/dashboard_bloc.dart';
import '../../features/device_management/viewmodel/device_bloc.dart';
import '../../features/session/viewmodel/session_bloc.dart';
import '../../features/webrtc/viewmodel/webrtc_bloc.dart';
import '../../features/signaling/viewmodel/signaling_bloc.dart';
import '../../features/chat/viewmodel/chat_bloc.dart';
import '../../features/notifications/viewmodel/notification_bloc.dart';
import '../../features/settings/viewmodel/settings_bloc.dart';
import '../../features/trusted_device/viewmodel/trusted_device_bloc.dart';
import '../../features/auto_connect/viewmodel/trusted_devices_bloc.dart';
import '../../features/theme/viewmodel/theme_bloc.dart';
import '../../features/security/viewmodel/security_bloc.dart';
import '../../features/analytics/viewmodel/analytics_bloc.dart';
import '../../features/live_screen/viewmodel/live_screen_bloc.dart';
import '../../features/remote_status/viewmodel/remote_status_bloc.dart';
import '../../features/remote_alarm/viewmodel/remote_alarm_bloc.dart';
import '../../features/focus_mode/viewmodel/focus_mode_bloc.dart';
import '../../features/cloud_backup/viewmodel/backup_bloc.dart';
import '../../features/wearable/viewmodel/wearable_bloc.dart';
import '../../features/profile/viewmodel/profile_bloc.dart';

final sl = GetIt.instance;

Future<void> setupServiceLocator() async {
  // ─── Core Services ──────────────────────────────────────────
  sl.registerLazySingleton(() => SecureStorageService());
  sl.registerLazySingleton(() => LocalStorageService());
  sl.registerLazySingleton(() => ConnectivityService());
  sl.registerLazySingleton(() => PushNotificationService());
  sl.registerLazySingleton(() => TrustedDeviceManager());

  // ─── Firebase ───────────────────────────────────────────────
  sl.registerLazySingleton(() => FirebaseAuthService());
  sl.registerLazySingleton(() => FirestoreService());
  sl.registerLazySingleton(() => RealtimeDbService());
  sl.registerLazySingleton(() => FcmService());

  // ─── Feature Services ────────────────────────────────────────
  sl.registerLazySingleton(() => LiveScreenService());
  sl.registerLazySingleton(() => RemoteStatusService());
  sl.registerLazySingleton(() => RemoteAlarmService());
  sl.registerLazySingleton(() => FocusModeService());
  sl.registerLazySingleton(() => WearableService());
  sl.registerLazySingleton(() => BackupService());
  sl.registerLazySingleton(() => AnalyticsTrackerService());
  sl.registerLazySingleton(() => WebRTCService());
  sl.registerLazySingleton(() => SignalingService());

  // ─── Repositories ────────────────────────────────────────────
  sl.registerLazySingleton<AuthRepository>(() => AuthRepositoryImpl());
  sl.registerLazySingleton<DeviceRepository>(() => DeviceRepositoryImpl());
  sl.registerLazySingleton<SessionRepository>(() => SessionRepositoryImpl());
  sl.registerLazySingleton<ChatRepository>(() => ChatRepositoryImpl());
  sl.registerLazySingleton<SettingsRepository>(() => SettingsRepositoryImpl());
  sl.registerLazySingleton<TrustedDeviceRepository>(() => TrustedDeviceRepositoryImpl());
  sl.registerLazySingleton<NotificationRepository>(() => NotificationRepositoryImpl());
  sl.registerLazySingleton<ProfileRepository>(() => ProfileRepositoryImpl());
  sl.registerLazySingleton<SecurityRepository>(() => SecurityRepositoryImpl());
  sl.registerLazySingleton<LiveScreenRepository>(() => LiveScreenRepositoryImpl());
  sl.registerLazySingleton(() => RemoteStatusRepository());
  sl.registerLazySingleton(() => RemoteAlarmRepository());
  sl.registerLazySingleton(() => BackupRepository());
  sl.registerLazySingleton(() => FocusModeRepository());
  sl.registerLazySingleton(() => WearableRepository());
  sl.registerLazySingleton(() => AnalyticsRepository());

  // ─── BLoCs ───────────────────────────────────────────────────
  sl.registerFactory(() => AuthBloc(repository: sl()));
  sl.registerFactory(() => DashboardBloc());
  sl.registerFactory(() => DeviceBloc(repository: sl()));
  sl.registerFactory(() => SessionBloc(repository: sl()));
  sl.registerFactory(() => WebRTCBloc(repository: sl(), service: sl()));
  sl.registerFactory(() => SignalingBloc(service: sl()));
  sl.registerFactory(() => ChatBloc(repository: sl()));
  sl.registerFactory(() => NotificationBloc(repository: sl()));
  sl.registerFactory(() => SettingsBloc(repository: sl()));
  sl.registerFactory(() => TrustedDeviceBloc(repository: sl()));
  sl.registerFactory(() => TrustedDevicesBloc());
  sl.registerFactory(() => ThemeBloc());
  sl.registerFactory(() => SecurityBloc(repository: sl()));
  sl.registerFactory(() => AnalyticsBloc(repository: sl(), service: sl()));
  sl.registerFactory(() => LiveScreenBloc(repository: sl(), service: sl()));
  sl.registerFactory(() => RemoteStatusBloc(repository: sl()));
  sl.registerFactory(() => RemoteAlarmBloc(repository: sl()));
  sl.registerFactory(() => FocusModeBloc(service: sl(), repository: sl()));
  sl.registerFactory(() => BackupBloc(repository: sl(), userId: ''));
  sl.registerFactory(() => WearableBloc(repository: sl()));
  sl.registerFactory(() => ProfileBloc(repository: sl()));
}
