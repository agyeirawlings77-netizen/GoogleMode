// lib/core/error/app_exceptions.dart
class AppException implements Exception {
  final String message; final String? code;
  const AppException(this.message, {this.code});
  @override String toString() => 'AppException: $message (code: $code)';
}
class NetworkException extends AppException { const NetworkException([String msg = 'Network error. Check your connection.']) : super(msg, code: 'NETWORK_ERROR'); }
class AuthException extends AppException { const AuthException([String msg = 'Authentication error.']) : super(msg, code: 'AUTH_ERROR'); }
class PermissionException extends AppException { const PermissionException([String msg = 'Permission denied.']) : super(msg, code: 'PERMISSION_DENIED'); }
class DeviceNotFoundException extends AppException { const DeviceNotFoundException([String msg = 'Device not found.']) : super(msg, code: 'DEVICE_NOT_FOUND'); }
class SessionException extends AppException { const SessionException([String msg = 'Session error.']) : super(msg, code: 'SESSION_ERROR'); }
class FileTransferException extends AppException { const FileTransferException([String msg = 'File transfer failed.']) : super(msg, code: 'TRANSFER_ERROR'); }
class BackupException extends AppException { const BackupException([String msg = 'Backup failed.']) : super(msg, code: 'BACKUP_ERROR'); }
class QrPairingException extends AppException { const QrPairingException([String msg = 'QR pairing failed.']) : super(msg, code: 'QR_ERROR'); }
