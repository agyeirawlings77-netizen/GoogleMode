// lib/core/error/error_handler.dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'app_exceptions.dart';

class ErrorHandler {
  static String handle(dynamic error) {
    debugPrint('Error: $error');
    if (error is AppException) return error.message;
    if (error is FirebaseAuthException) return _handleFirebaseAuth(error);
    final msg = error.toString();
    if (msg.contains('network')) return 'Network error. Check your connection.';
    if (msg.contains('permission')) return 'Permission denied.';
    if (msg.contains('not-found')) return 'Resource not found.';
    if (msg.contains('already-exists')) return 'Resource already exists.';
    if (msg.contains('timeout')) return 'Request timed out. Please try again.';
    return 'An unexpected error occurred.';
  }

  static String _handleFirebaseAuth(FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found': return 'No account found with this email.';
      case 'wrong-password': return 'Incorrect password.';
      case 'email-already-in-use': return 'Email already in use.';
      case 'weak-password': return 'Password is too weak.';
      case 'invalid-email': return 'Invalid email address.';
      case 'user-disabled': return 'This account has been disabled.';
      case 'too-many-requests': return 'Too many attempts. Try again later.';
      case 'network-request-failed': return 'Network error. Check your connection.';
      default: return e.message ?? 'Authentication error.';
    }
  }
}
