// lib/core/error/app_error.dart

abstract class AppError implements Exception {
  final String message;
  final String? code;
  const AppError(this.message, {this.code});
  @override String toString() => message;
}

class NetworkError extends AppError {
  const NetworkError(super.message, {super.code = 'network_error'});
}

class AuthError extends AppError {
  const AuthError(super.message, {super.code = 'auth_error'});
}

class NotFoundError extends AppError {
  const NotFoundError(super.message, {super.code = 'not_found'});
}

class PermissionError extends AppError {
  const PermissionError(super.message, {super.code = 'permission_denied'});
}

class StorageError extends AppError {
  const StorageError(super.message, {super.code = 'storage_error'});
}

class ConnectionError extends AppError {
  const ConnectionError(super.message, {super.code = 'connection_error'});
}

class ValidationError extends AppError {
  const ValidationError(super.message, {super.code = 'validation_error'});
}

class ServerError extends AppError {
  final int? statusCode;
  const ServerError(super.message, {super.code = 'server_error', this.statusCode});
}

class TimeoutError extends AppError {
  const TimeoutError([String message = 'Request timed out']) : super(message, code: 'timeout');
}

class UnknownError extends AppError {
  const UnknownError([String message = 'An unknown error occurred']) : super(message, code: 'unknown');
}

// Error handler helper
AppError handleError(dynamic error) {
  if (error is AppError) return error;
  final msg = error.toString();
  if (msg.contains('network') || msg.contains('SocketException')) return NetworkError(msg);
  if (msg.contains('permission') || msg.contains('denied')) return PermissionError(msg);
  if (msg.contains('not-found') || msg.contains('404')) return NotFoundError(msg);
  if (msg.contains('timeout')) return TimeoutError(msg);
  if (msg.contains('auth') || msg.contains('credential')) return AuthError(msg);
  return UnknownError(msg);
}
