// lib/core/extensions/list_extensions.dart

extension ListExtensions<T> on List<T> {
  T? get firstOrNull => isEmpty ? null : first;
  T? get lastOrNull => isEmpty ? null : last;

  List<T> unique([Object Function(T)? key]) {
    final seen = <Object>{};
    return where((item) => seen.add(key?.call(item) ?? item as Object)).toList();
  }

  List<List<T>> chunk(int size) {
    final chunks = <List<T>>[];
    for (var i = 0; i < length; i += size) {
      chunks.add(sublist(i, (i + size).clamp(0, length)));
    }
    return chunks;
  }

  T? tryGet(int index) => index >= 0 && index < length ? this[index] : null;

  List<T> sortedBy<C extends Comparable>(C Function(T) selector, {bool descending = false}) {
    final sorted = [...this]..sort((a, b) {
      final comparison = selector(a).compareTo(selector(b));
      return descending ? -comparison : comparison;
    });
    return sorted;
  }

  Map<K, List<T>> groupBy<K>(K Function(T) key) {
    final map = <K, List<T>>{};
    for (final item in this) {
      (map[key(item)] ??= []).add(item);
    }
    return map;
  }

  bool containsWhere(bool Function(T) test) => any(test);
}

extension NullableListExtensions<T> on List<T>? {
  bool get isNullOrEmpty => this == null || this!.isEmpty;
  List<T> get orEmpty => this ?? [];
  int get safeLength => this?.length ?? 0;
}
