// lib/core/extensions/map_extensions.dart
extension MapExtensions<K, V> on Map<K, V> {
  V? getOrNull(K key) => containsKey(key) ? this[key] : null;
  Map<K, V> where(bool Function(K, V) test) => Map.fromEntries(entries.where((e) => test(e.key, e.value)));
  Map<K2, V2> mapEntries<K2, V2>(MapEntry<K2, V2> Function(K, V) convert) => Map.fromEntries(entries.map((e) => convert(e.key, e.value)));
  bool containsAll(Iterable<K> keys) => keys.every(containsKey);
}
