// lib/core/extensions/widget_extensions.dart
import 'package:flutter/material.dart';
extension WidgetExtensions on Widget {
  Widget paddingAll(double v) => Padding(padding: EdgeInsets.all(v), child: this);
  Widget paddingSymmetric({double h = 0, double v = 0}) => Padding(padding: EdgeInsets.symmetric(horizontal: h, vertical: v), child: this);
  Widget paddingOnly({double l=0, double r=0, double t=0, double b=0}) => Padding(padding: EdgeInsets.fromLTRB(l, t, r, b), child: this);
  Widget card({double radius = 12}) => Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius)), child: this);
  Widget center() => Center(child: this);
  Widget expanded([int flex = 1]) => Expanded(flex: flex, child: this);
  Widget opacity(double v) => Opacity(opacity: v, child: this);
  SizedBox withHeight(double h) => SizedBox(height: h, child: this);
  SizedBox withWidth(double w) => SizedBox(width: w, child: this);
}
