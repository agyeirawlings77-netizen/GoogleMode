// lib/core/extensions/context_extensions.dart
import 'package:flutter/material.dart';

extension BuildContextExtensions on BuildContext {
  ThemeData get theme => Theme.of(this);
  ColorScheme get colors => Theme.of(this).colorScheme;
  TextTheme get textTheme => Theme.of(this).textTheme;
  MediaQueryData get mediaQuery => MediaQuery.of(this);
  double get screenWidth => MediaQuery.of(this).size.width;
  double get screenHeight => MediaQuery.of(this).size.height;
  double get statusBarHeight => MediaQuery.of(this).padding.top;
  double get bottomPadding => MediaQuery.of(this).padding.bottom;
  bool get isDark => Theme.of(this).brightness == Brightness.dark;

  void showSnackBar(String message, {Color? backgroundColor}) {
    ScaffoldMessenger.of(this).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: backgroundColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void showErrorSnackBar(String message) =>
      showSnackBar(message, backgroundColor: Colors.red);

  void showSuccessSnackBar(String message) =>
      showSnackBar(message, backgroundColor: Colors.green);

  Future<bool?> showConfirmDialog({
    required String title,
    required String message,
    String confirmLabel = 'Confirm',
    String cancelLabel = 'Cancel',
    bool isDanger = false,
  }) => showDialog<bool>(
    context: this,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(this, false), child: Text(cancelLabel)),
        TextButton(
          onPressed: () => Navigator.pop(this, true),
          child: Text(confirmLabel, style: TextStyle(color: isDanger ? Colors.red : null)),
        ),
      ],
    ),
  );

  void hideKeyboard() => FocusScope.of(this).unfocus();
}
