// lib/core/extensions/number_extensions.dart
import 'package:flutter/material.dart';

extension IntExtensions on int {
  String get bytesLabel {
    if (this >= 1073741824) return '${(this / 1073741824).toStringAsFixed(1)} GB';
    if (this >= 1048576) return '${(this / 1048576).toStringAsFixed(1)} MB';
    if (this >= 1024) return '${(this / 1024).toStringAsFixed(0)} KB';
    return '$this B';
  }

  String get speedLabel {
    if (this >= 1048576) return '${(this / 1048576).toStringAsFixed(1)} MB/s';
    if (this >= 1024) return '${(this / 1024).toStringAsFixed(0)} KB/s';
    return '$this B/s';
  }

  String get minutesLabel {
    final h = this ~/ 60;
    final m = this % 60;
    if (h > 0) return '${h}h ${m}m';
    return '${m}m';
  }

  Duration get seconds => Duration(seconds: this);
  Duration get minutes => Duration(minutes: this);
  Duration get hours => Duration(hours: this);
  Duration get milliseconds => Duration(milliseconds: this);

  SizedBox get heightBox => SizedBox(height: toDouble());
  SizedBox get widthBox => SizedBox(width: toDouble());

  EdgeInsets get allPadding => EdgeInsets.all(toDouble());
  EdgeInsets get horizontalPadding => EdgeInsets.symmetric(horizontal: toDouble());
  EdgeInsets get verticalPadding => EdgeInsets.symmetric(vertical: toDouble());

  bool get isEven => this % 2 == 0;
  bool get isOdd => this % 2 != 0;

  int clampMin(int min) => this < min ? min : this;
  int clampMax(int max) => this > max ? max : this;
}

extension DoubleExtensions on double {
  String get percentLabel => '${toStringAsFixed(0)}%';
  String toFixedString(int decimals) => toStringAsFixed(decimals);
  SizedBox get heightBox => SizedBox(height: this);
  SizedBox get widthBox => SizedBox(width: this);
}
