// lib/core/theme/border_radius.dart
import 'package:flutter/material.dart';
class AppBorderRadius {
  static const xs = BorderRadius.all(Radius.circular(4));
  static const sm = BorderRadius.all(Radius.circular(8));
  static const md = BorderRadius.all(Radius.circular(12));
  static const lg = BorderRadius.all(Radius.circular(16));
  static const xl = BorderRadius.all(Radius.circular(24));
  static const full = BorderRadius.all(Radius.circular(100));
  static const card = md;
  static const button = md;
  static const chip = sm;
  static const dialog = lg;
}
