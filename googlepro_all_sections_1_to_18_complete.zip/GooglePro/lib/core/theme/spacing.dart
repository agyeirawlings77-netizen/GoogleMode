// lib/core/theme/spacing.dart
import 'package:flutter/material.dart';

class AppSpacing {
  AppSpacing._();

  static const double xxs = 2.0;
  static const double xs = 4.0;
  static const double sm = 8.0;
  static const double md = 16.0;
  static const double lg = 24.0;
  static const double xl = 32.0;
  static const double xxl = 48.0;
  static const double xxxl = 64.0;

  // Screen padding
  static const EdgeInsets screenPadding =
      EdgeInsets.symmetric(horizontal: md, vertical: sm);
  static const EdgeInsets screenPaddingH = EdgeInsets.symmetric(horizontal: md);
  static const EdgeInsets screenPaddingAll = EdgeInsets.all(md);

  // Card padding
  static const EdgeInsets cardPadding = EdgeInsets.all(md);
  static const EdgeInsets cardPaddingSmall = EdgeInsets.all(sm);
  static const EdgeInsets cardPaddingLarge = EdgeInsets.all(lg);

  // List tile padding
  static const EdgeInsets listTilePadding =
      EdgeInsets.symmetric(horizontal: md, vertical: sm);

  // Button padding
  static const EdgeInsets buttonPadding =
      EdgeInsets.symmetric(horizontal: lg, vertical: 14);

  // Icon padding
  static const EdgeInsets iconPadding = EdgeInsets.all(sm);

  // Gaps (SizedBox heights)
  static const Widget gapXxs = SizedBox(height: xxs);
  static const Widget gapXs = SizedBox(height: xs);
  static const Widget gapSm = SizedBox(height: sm);
  static const Widget gapMd = SizedBox(height: md);
  static const Widget gapLg = SizedBox(height: lg);
  static const Widget gapXl = SizedBox(height: xl);
  static const Widget gapXxl = SizedBox(height: xxl);

  // Horizontal gaps
  static const Widget hGapXs = SizedBox(width: xs);
  static const Widget hGapSm = SizedBox(width: sm);
  static const Widget hGapMd = SizedBox(width: md);
  static const Widget hGapLg = SizedBox(width: lg);

  // Border radius
  static const double radiusSm = 4.0;
  static const double radiusMd = 8.0;
  static const double radiusLg = 12.0;
  static const double radiusXl = 16.0;
  static const double radiusXxl = 24.0;
  static const double radiusCircle = 100.0;

  static BorderRadius get roundedSm =>
      BorderRadius.circular(radiusSm);
  static BorderRadius get roundedMd =>
      BorderRadius.circular(radiusMd);
  static BorderRadius get roundedLg =>
      BorderRadius.circular(radiusLg);
  static BorderRadius get roundedXl =>
      BorderRadius.circular(radiusXl);
  static BorderRadius get roundedXxl =>
      BorderRadius.circular(radiusXxl);
  static BorderRadius get rounded =>
      BorderRadius.circular(radiusCircle);

  // Top rounded only
  static BorderRadius get topRoundedLg => const BorderRadius.vertical(
        top: Radius.circular(radiusLg),
      );
  static BorderRadius get topRoundedXl => const BorderRadius.vertical(
        top: Radius.circular(radiusXl),
      );
  static BorderRadius get topRoundedXxl => const BorderRadius.vertical(
        top: Radius.circular(radiusXxl),
      );
}
