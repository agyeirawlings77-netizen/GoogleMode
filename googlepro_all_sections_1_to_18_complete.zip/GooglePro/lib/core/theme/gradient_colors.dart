// lib/core/theme/gradient_colors.dart
import 'package:flutter/material.dart';

class GradientColors {
  GradientColors._();

  // Primary gradients
  static const primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF1565C0), Color(0xFF0D47A1)],
  );

  static const primaryLightGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF1976D2), Color(0xFF1565C0)],
  );

  static const splashGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF1565C0), Color(0xFF0D47A1), Color(0xFF0A3880)],
    stops: [0.0, 0.6, 1.0],
  );

  // Feature gradients
  static const screenShareGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF1565C0), Color(0xFF00ACC1)],
  );

  static const remoteControlGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF7B1FA2), Color(0xFF1565C0)],
  );

  static const locationGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF00897B), Color(0xFF1565C0)],
  );

  static const alarmGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFE53935), Color(0xFFFF6F00)],
  );

  static const focusGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF6A1B9A), Color(0xFF283593)],
  );

  static const backupGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF00838F), Color(0xFF1565C0)],
  );

  static const chatGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF00ACC1), Color(0xFF1565C0)],
  );

  static const fileTransferGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF558B2F), Color(0xFF1565C0)],
  );

  // Status gradients
  static const onlineGradient = LinearGradient(
    colors: [Color(0xFF43A047), Color(0xFF1B5E20)],
  );

  static const offlineGradient = LinearGradient(
    colors: [Color(0xFF757575), Color(0xFF424242)],
  );

  static const errorGradient = LinearGradient(
    colors: [Color(0xFFE53935), Color(0xFFB71C1C)],
  );

  // Card overlay gradient (for cards with image backgrounds)
  static const cardOverlayGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Colors.transparent, Color(0xCC000000)],
  );

  static const bottomFadeGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Colors.transparent, Colors.black87],
  );

  static const topFadeGradient = LinearGradient(
    begin: Alignment.bottomCenter,
    end: Alignment.topCenter,
    colors: [Colors.transparent, Colors.black87],
  );
}
