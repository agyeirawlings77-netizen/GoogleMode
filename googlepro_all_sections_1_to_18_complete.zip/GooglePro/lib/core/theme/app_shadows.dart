// lib/core/theme/app_shadows.dart
import 'package:flutter/material.dart';
class AppShadows {
  static const card = [BoxShadow(color: Color(0x1A000000), blurRadius: 8, offset: Offset(0, 2))];
  static const elevated = [BoxShadow(color: Color(0x26000000), blurRadius: 16, offset: Offset(0, 4))];
  static const button = [BoxShadow(color: Color(0x401565C0), blurRadius: 12, offset: Offset(0, 4))];
  static const modal = [BoxShadow(color: Color(0x33000000), blurRadius: 24, offset: Offset(0, 8))];
}
