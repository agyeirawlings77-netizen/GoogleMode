// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:provider/provider.dart';

import 'core/firebase/firebase_options.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'core/di/service_locator.dart';
import 'core/services/push_notification_service.dart';

// Feature BLoCs
import 'features/auth/viewmodel/auth_bloc.dart';
import 'features/dashboard/viewmodel/dashboard_bloc.dart';
import 'features/dashboard/state/bottom_nav_cubit.dart';
import 'features/device_management/viewmodel/device_bloc.dart';
import 'features/session/viewmodel/session_bloc.dart';
import 'features/webrtc/viewmodel/webrtc_bloc.dart';
import 'features/signaling/viewmodel/signaling_bloc.dart';
import 'features/chat/viewmodel/chat_bloc.dart';
import 'features/notifications/viewmodel/notification_bloc.dart';
import 'features/settings/viewmodel/settings_bloc.dart';
import 'features/trusted_device/viewmodel/trusted_device_bloc.dart';
import 'features/auto_connect/viewmodel/trusted_devices_bloc.dart';
import 'features/theme/viewmodel/theme_bloc.dart';
import 'features/security/viewmodel/security_bloc.dart';
import 'features/analytics/viewmodel/analytics_bloc.dart';
import 'features/live_screen/viewmodel/live_screen_bloc.dart';
import 'features/remote_status/viewmodel/remote_status_bloc.dart';
import 'features/remote_alarm/viewmodel/remote_alarm_bloc.dart';
import 'features/focus_mode/viewmodel/focus_mode_bloc.dart';
import 'features/cloud_backup/viewmodel/backup_bloc.dart';
import 'features/wearable/viewmodel/wearable_bloc.dart';
import 'features/profile/viewmodel/profile_bloc.dart';
import 'features/splash/viewmodel/splash_viewmodel.dart';

// Background message handler (must be top-level)
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  debugPrint('Background FCM message: ${message.messageId}');
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // System UI
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // FCM background handler
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  // Foreground task init
  FlutterForegroundTask.initCommunicationPort();

  // Dependency injection
  await setupServiceLocator();

  runApp(const GoogleProApp());
}

class GoogleProApp extends StatelessWidget {
  const GoogleProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SplashViewModel()),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider(create: (_) => sl<AuthBloc>()),
          BlocProvider(create: (_) => sl<DashboardBloc>()),
          BlocProvider(create: (_) => BottomNavCubit()),
          BlocProvider(create: (_) => sl<DeviceBloc>()),
          BlocProvider(create: (_) => sl<SessionBloc>()),
          BlocProvider(create: (_) => sl<WebRTCBloc>()),
          BlocProvider(create: (_) => sl<SignalingBloc>()),
          BlocProvider(create: (_) => sl<ChatBloc>()),
          BlocProvider(create: (_) => sl<NotificationBloc>()),
          BlocProvider(create: (_) => sl<SettingsBloc>()),
          BlocProvider(create: (_) => sl<TrustedDeviceBloc>()),
          BlocProvider(create: (_) => sl<TrustedDevicesBloc>()),
          BlocProvider(create: (_) => sl<ThemeBloc>()),
          BlocProvider(create: (_) => sl<SecurityBloc>()),
          BlocProvider(create: (_) => sl<AnalyticsBloc>()),
          BlocProvider(create: (_) => sl<LiveScreenBloc>()),
          BlocProvider(create: (_) => sl<RemoteStatusBloc>()),
          BlocProvider(create: (_) => sl<RemoteAlarmBloc>()),
          BlocProvider(create: (_) => sl<FocusModeBloc>()),
          BlocProvider(create: (_) => sl<BackupBloc>()),
          BlocProvider(create: (_) => sl<WearableBloc>()),
          BlocProvider(create: (_) => sl<ProfileBloc>()),
        ],
        child: BlocBuilder<ThemeBloc, ThemeState>(
          builder: (context, themeState) {
            return MaterialApp.router(
              title: 'GooglePro',
              debugShowCheckedModeBanner: false,
              theme: AppTheme.lightTheme,
              darkTheme: AppTheme.darkTheme,
              themeMode: themeState is ThemeLoaded
                  ? themeState.isDark ? ThemeMode.dark : ThemeMode.light
                  : ThemeMode.system,
              routerConfig: AppRouter.router,
            );
          },
        ),
      ),
    );
  }
}
