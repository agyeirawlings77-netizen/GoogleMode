# GooglePro - Remote Control & Monitoring App

[![Flutter](https://img.shields.io/badge/Flutter-3.19.0-blue)](https://flutter.dev)
[![Firebase](https://img.shields.io/badge/Firebase-Enabled-orange)](https://firebase.google.com)
[![License](https://img.shields.io/badge/License-Proprietary-red)](LICENSE)

## 📱 Overview

GooglePro is a powerful Android remote control and monitoring application built with Flutter. It enables real-time screen sharing, remote device control, file transfer, location tracking, parental controls, and much more.

## ✨ Features

- **🖥️ Live Screen Viewing** — View any device screen in real-time with HD quality
- **🎮 Remote Control** — Full touch, keyboard, and gesture control of remote devices
- **📁 File Transfer** — Send and receive files instantly between devices
- **💬 Encrypted Chat** — End-to-end encrypted messaging during sessions
- **📍 Location Tracking** — Real-time GPS tracking with history
- **👨‍👩‍👧 Parental Controls** — App blocking, screen time limits, content filters
- **🔔 Remote Alarm** — Trigger alarms on remote devices
- **🔕 Focus Mode** — Remotely activate Do Not Disturb on any device
- **☁️ Cloud Backup** — Backup and restore all app data
- **⌚ Smartwatch Support** — Control from your wrist via Wear OS
- **🤖 AI Assistant** — Gemini-powered help and device management
- **🔒 Security First** — AES-256 encryption, biometric auth, app lock

## 🏗️ Architecture

```
lib/
├── core/
│   ├── di/            # Dependency injection (GetIt)
│   ├── error/         # Error handling
│   ├── extensions/    # Dart extensions
│   ├── firebase/      # Firebase services
│   ├── network/       # WebSocket, HTTP clients
│   ├── router/        # GoRouter navigation
│   ├── services/      # Core services
│   ├── theme/         # App theme
│   ├── utils/         # Utilities
│   └── widgets/       # Shared widgets
└── features/
    ├── auth/          # Authentication
    ├── dashboard/     # Home dashboard
    ├── device_management/
    ├── live_screen/   # Screen viewing
    ├── remote_control/
    ├── session/       # Session management
    ├── chat/          # Encrypted chat
    ├── location/      # GPS tracking
    ├── file_transfer/
    ├── remote_alarm/
    ├── focus_mode/
    ├── parental_controls/
    ├── cloud_backup/
    ├── wearable/
    ├── ai_assistant/
    ├── analytics/
    ├── security/
    └── settings/
```

## 🚀 Getting Started

### Prerequisites

- Flutter 3.19.0+
- Android Studio / VS Code
- Firebase account
- Android device (API 21+)

### Setup

```bash
# Clone repository
git clone https://github.com/agyeirawlings77-netizen/GoogleMode.git
cd GoogleMode/GooglePro

# Install dependencies
flutter pub get

# Run on device
flutter run
```

### Firebase Setup

1. Create project at [console.firebase.google.com](https://console.firebase.google.com)
2. Add Android app with package `com.rawlings.googlepro`
3. Download `google-services.json` → place in `android/app/`
4. Enable: Authentication, Firestore, Realtime Database, Storage, Messaging

## 🔧 Configuration

### Signaling Server

Update `lib/core/constants/api_endpoints.dart`:
```dart
static const _wsUrl = 'wss://your-signaling-server.com/ws';
```

### TURN Servers

Update `lib/core/constants/webrtc_constants.dart` with your TURN credentials.

## 📦 Building

```bash
# Debug APK
flutter build apk --debug

# Release AAB
flutter build appbundle --release

# Split APKs by ABI
flutter build apk --split-per-abi
```

## 🧪 Testing

```bash
# Run all tests
flutter test

# Run with coverage
flutter test --coverage
```

## 📊 Tech Stack

| Technology | Purpose |
|---|---|
| Flutter 3.19 | UI Framework |
| Firebase | Backend (Auth, DB, Storage) |
| WebRTC | Real-time video/audio |
| WebSocket | Signaling |
| GetIt | Dependency Injection |
| BLoC | State Management |
| GoRouter | Navigation |
| Hive | Local storage |
| WorkManager | Background tasks |
| Gemini AI | AI Assistant |

## 🔐 Security

- All connections use DTLS-SRTP encryption via WebRTC
- Data channels are AES-256 encrypted
- No video/audio passes through our servers (peer-to-peer)
- Biometric authentication support
- PIN/Pattern app lock
- Remote device lock & wipe capability

## 📄 License

Copyright © 2024 GooglePro. All rights reserved.
