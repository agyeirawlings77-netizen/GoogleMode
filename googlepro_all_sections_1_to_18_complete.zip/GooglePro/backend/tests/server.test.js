// backend/tests/server.test.js
'use strict';

const request = require('supertest');

// Mock Firebase before requiring app
jest.mock('../src/config/firebase_config', () => ({
  initializeFirebase: jest.fn(),
  getFirestore: jest.fn(() => ({
    collection: jest.fn(() => ({
      doc: jest.fn(() => ({
        get: jest.fn(() => Promise.resolve({ exists: false, data: () => ({}) })),
        set: jest.fn(() => Promise.resolve()),
        update: jest.fn(() => Promise.resolve()),
        delete: jest.fn(() => Promise.resolve()),
      })),
      where: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      limit: jest.fn(() => ({
        get: jest.fn(() => Promise.resolve({ docs: [] })),
      })),
      get: jest.fn(() => Promise.resolve({ docs: [] })),
    })),
  })),
  getDatabase: jest.fn(() => ({
    ref: jest.fn(() => ({
      set: jest.fn(() => Promise.resolve()),
      get: jest.fn(() => Promise.resolve({ val: () => null })),
      remove: jest.fn(() => Promise.resolve()),
      push: jest.fn(() => Promise.resolve()),
    })),
  })),
  getAuth: jest.fn(() => ({
    verifyIdToken: jest.fn(() => Promise.resolve({ uid: 'test_uid', email: 'test@test.com' })),
  })),
  getMessaging: jest.fn(() => ({
    send: jest.fn(() => Promise.resolve('message_id')),
    sendMulticast: jest.fn(() => Promise.resolve({ successCount: 1, failureCount: 0 })),
  })),
  getStorage: jest.fn(),
  admin: { firestore: { FieldValue: { delete: jest.fn() } } },
}));

const app = require('../src/app');

describe('GooglePro Server', () => {
  describe('GET /health', () => {
    it('should return 200 and health status', async () => {
      const res = await request(app).get('/health');
      expect(res.statusCode).toBe(200);
      expect(res.body).toHaveProperty('status', 'ok');
      expect(res.body).toHaveProperty('timestamp');
      expect(res.body).toHaveProperty('uptime');
    });
  });

  describe('404 handler', () => {
    it('should return 404 for unknown routes', async () => {
      const res = await request(app).get('/api/v1/unknown-route');
      expect(res.statusCode).toBe(404);
      expect(res.body).toHaveProperty('success', false);
    });
  });

  describe('Auth routes - no token', () => {
    it('GET /api/v1/auth/me without token should return 401', async () => {
      const res = await request(app).get('/api/v1/auth/me');
      expect(res.statusCode).toBe(401);
      expect(res.body).toHaveProperty('success', false);
    });

    it('POST /api/v1/auth/verify without token should return 401', async () => {
      const res = await request(app).post('/api/v1/auth/verify');
      expect(res.statusCode).toBe(401);
    });
  });

  describe('Device routes - no token', () => {
    it('GET /api/v1/devices without token should return 401', async () => {
      const res = await request(app).get('/api/v1/devices');
      expect(res.statusCode).toBe(401);
    });
  });

  describe('Signaling routes', () => {
    it('GET /api/v1/signaling/ice-servers without token should return 401', async () => {
      const res = await request(app).get('/api/v1/signaling/ice-servers');
      expect(res.statusCode).toBe(401);
    });
  });
});
