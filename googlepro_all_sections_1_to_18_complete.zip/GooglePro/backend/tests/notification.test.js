// backend/tests/notification.test.js
describe('Notification Model', () => {
  it('creates notification with defaults', () => {
    const notif = { userId: 'u1', title: 'Test', body: 'Body' };
    expect(notif.userId).toBe('u1');
    expect(notif.title).toBe('Test');
  });
  it('validates notification types', () => {
    const types = ['general', 'connection', 'alarm', 'file', 'session'];
    expect(types.includes('general')).toBe(true);
  });
});
