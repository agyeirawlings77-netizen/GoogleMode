// backend/tests/device.test.js
describe('Device Model', () => {
  it('creates device with required fields', () => {
    const device = { deviceId: 'test_123', userId: 'user_abc', deviceName: 'Test Phone' };
    expect(device.deviceId).toBe('test_123');
    expect(device.deviceName).toBe('Test Phone');
  });
  it('validates device fields', () => {
    const types = ['android', 'ios', 'wear_os'];
    expect(types.includes('android')).toBe(true);
  });
  it('handles missing optional fields', () => {
    const device = { deviceId: 'd1', userId: 'u1', deviceName: 'Phone' };
    expect(device.manufacturer).toBeUndefined();
    expect(device.model).toBeUndefined();
  });
});
