// backend/tests/signaling.test.js
'use strict';

const signalingService = require('../src/services/signaling_service');
const { getIceServers } = require('../src/config/ice_servers_config');

jest.mock('../src/config/firebase_config', () => ({
  getDatabase: jest.fn(() => ({
    ref: jest.fn(() => ({
      set: jest.fn(() => Promise.resolve()),
      push: jest.fn(() => Promise.resolve()),
      remove: jest.fn(() => Promise.resolve()),
      get: jest.fn(() => Promise.resolve({ val: () => null })),
    })),
  })),
}));

describe('SignalingService', () => {
  describe('getIceServersConfig', () => {
    it('should return ICE server config with stun and turn', () => {
      const config = signalingService.getIceServersConfig();
      expect(config).toHaveProperty('iceServers');
      expect(Array.isArray(config.iceServers)).toBe(true);
      expect(config.iceServers.length).toBeGreaterThan(0);
    });

    it('should include STUN server', () => {
      const config = getIceServers();
      const stunServer = config.iceServers.find(s =>
        s.urls && s.urls.toString().includes('stun'));
      expect(stunServer).toBeDefined();
    });

    it('should include TURN server with credentials', () => {
      const config = getIceServers();
      const turnServer = config.iceServers.find(s =>
        s.urls && s.urls.toString().includes('turn') && s.username);
      expect(turnServer).toBeDefined();
      expect(turnServer).toHaveProperty('username');
      expect(turnServer).toHaveProperty('credential');
    });
  });

  describe('sendOffer', () => {
    it('should send offer to Firebase', async () => {
      await expect(
        signalingService.sendOffer('device1', 'device2', { type: 'offer', sdp: 'test' }, 'session1')
      ).resolves.not.toThrow();
    });
  });

  describe('sendAnswer', () => {
    it('should send answer to Firebase', async () => {
      await expect(
        signalingService.sendAnswer('device2', 'device1', { type: 'answer', sdp: 'test' }, 'session1')
      ).resolves.not.toThrow();
    });
  });
});
