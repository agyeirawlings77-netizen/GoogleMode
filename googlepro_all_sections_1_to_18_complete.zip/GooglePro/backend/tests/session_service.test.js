// backend/tests/session_service.test.js
'use strict';

jest.mock('../src/config/firebase_config', () => ({
  getFirestore: jest.fn(() => ({
    collection: jest.fn(() => ({
      doc: jest.fn(() => ({
        get: jest.fn(() => Promise.resolve({
          exists: true,
          data: () => ({
            sessionId: 'session_001',
            status: 'active',
            initiatorUserId: 'user_001',
            targetUserId: 'user_002',
            sessionType: 'screen_share',
            startedAt: new Date(Date.now() - 60000).toISOString(),
          }),
        })),
        set: jest.fn(() => Promise.resolve()),
        update: jest.fn(() => Promise.resolve()),
        delete: jest.fn(() => Promise.resolve()),
      })),
      where: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      limit: jest.fn(() => ({
        get: jest.fn(() => Promise.resolve({ docs: [] })),
      })),
      get: jest.fn(() => Promise.resolve({ docs: [] })),
    })),
  })),
}));

const sessionService = require('../src/services/session_service');

describe('SessionService', () => {
  describe('createSession', () => {
    it('should create a session and return session data', async () => {
      const session = await sessionService.createSession({
        sessionType: 'screen_share',
        initiatorUserId: 'user_001',
        initiatorDeviceId: 'device_001',
        targetUserId: 'user_002',
        targetDeviceId: 'device_002',
      });
      expect(session).toHaveProperty('sessionId');
      expect(session).toHaveProperty('status', 'pending');
      expect(session).toHaveProperty('sessionType', 'screen_share');
    });
  });

  describe('getSession', () => {
    it('should return session data', async () => {
      const session = await sessionService.getSession('session_001');
      expect(session).not.toBeNull();
      expect(session).toHaveProperty('sessionId', 'session_001');
    });
  });

  describe('endSession', () => {
    it('should end session and calculate duration', async () => {
      const result = await sessionService.endSession('session_001', 'user_ended');
      expect(result).toHaveProperty('status', 'ended');
      expect(result).toHaveProperty('durationSeconds');
      expect(result.durationSeconds).toBeGreaterThanOrEqual(0);
    });
  });
});
