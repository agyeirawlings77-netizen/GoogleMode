// backend/tests/presence.test.js
describe('Presence', () => {
  it('tracks online devices', () => {
    const clients = new Map();
    clients.set('d1', { online: true });
    clients.set('d2', { online: false });
    const online = Array.from(clients.entries()).filter(([_,v]) => v.online).map(([k]) => k);
    expect(online).toContain('d1');
    expect(online).not.toContain('d2');
  });
});
