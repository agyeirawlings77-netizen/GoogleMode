// backend/tests/websocket.test.js
const WebSocket = require('ws');

describe('WebSocket Tests', () => {
  it('client map is initialized', () => {
    const clients = new Map();
    expect(clients.size).toBe(0);
  });

  it('routes messages between clients', () => {
    const clients = new Map();
    const mockWs = { readyState: WebSocket.OPEN, send: jest.fn() };
    clients.set('device_a', mockWs);
    const target = clients.get('device_a');
    expect(target).toBeDefined();
    if (target && target.readyState === WebSocket.OPEN) {
      target.send(JSON.stringify({ type: 'offer' }));
    }
    expect(mockWs.send).toHaveBeenCalledTimes(1);
  });
});
