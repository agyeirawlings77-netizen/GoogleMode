// backend/tests/device_service.test.js
'use strict';

jest.mock('../src/config/firebase_config', () => ({
  getFirestore: jest.fn(() => ({
    collection: jest.fn(() => ({
      doc: jest.fn(() => ({
        get: jest.fn(() => Promise.resolve({
          exists: true,
          data: () => ({
            deviceId: 'device_001',
            deviceName: 'Test Phone',
            userId: 'user_001',
            isOnline: true,
          }),
        })),
        set: jest.fn(() => Promise.resolve()),
        update: jest.fn(() => Promise.resolve()),
        delete: jest.fn(() => Promise.resolve()),
      })),
      where: jest.fn().mockReturnThis(),
      get: jest.fn(() => Promise.resolve({
        docs: [{
          data: () => ({
            deviceId: 'device_001',
            deviceName: 'Test Phone',
            userId: 'user_001',
          }),
        }],
      })),
    })),
  })),
  getDatabase: jest.fn(() => ({
    ref: jest.fn(() => ({
      set: jest.fn(() => Promise.resolve()),
      get: jest.fn(() => Promise.resolve({ val: () => ({ online: true }) })),
    })),
  })),
  admin: { firestore: { FieldValue: { delete: jest.fn() } } },
}));

const deviceService = require('../src/services/device_service');

describe('DeviceService', () => {
  describe('getDevice', () => {
    it('should return device data when device exists', async () => {
      const device = await deviceService.getDevice('device_001');
      expect(device).not.toBeNull();
      expect(device).toHaveProperty('deviceId', 'device_001');
    });
  });

  describe('registerDevice', () => {
    it('should register device and return device data', async () => {
      const deviceData = {
        deviceId: 'device_002', deviceName: 'New Phone',
        userId: 'user_001', deviceType: 'android',
      };
      const result = await deviceService.registerDevice(deviceData);
      expect(result).toHaveProperty('deviceId', 'device_002');
    });
  });

  describe('setPresence', () => {
    it('should set device presence', async () => {
      await expect(deviceService.setPresence('device_001', true))
        .resolves.not.toThrow();
    });
  });
});
