// backend/tests/api.test.js
const request = require('supertest');

describe('API Integration Tests', () => {
  let app;
  beforeAll(() => {
    // Mock Firebase
    jest.mock('firebase-admin', () => ({
      apps: [], initializeApp: jest.fn(), credential: { cert: jest.fn() },
      auth: () => ({ verifyIdToken: jest.fn().mockResolvedValue({ uid: 'test_uid' }) }),
      messaging: () => ({ send: jest.fn().mockResolvedValue('msg_id') }),
      firestore: () => ({}), database: () => ({}),
    }));
    app = require('../src/index').app;
  });

  it('GET /api/v1/health returns 200', async () => {
    const res = await request(app).get('/api/v1/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });

  it('POST /api/v1/signal without auth returns 401', async () => {
    const res = await request(app).post('/api/v1/signal').send({ toDeviceId: 'test', message: {} });
    expect(res.status).toBe(401);
  });
});
