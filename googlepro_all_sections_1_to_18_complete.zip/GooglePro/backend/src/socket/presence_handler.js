// backend/src/socket/presence_handler.js
'use strict';

const { SOCKET_EVENTS, ROOM_PREFIX } = require('../config/constants');
const { getDatabase } = require('../config/firebase_config');
const logger = require('../utils/logger');

module.exports = function presenceHandler(io, socket) {
  // Device comes online - broadcast to all
  socket.on(SOCKET_EVENTS.DEVICE_ONLINE, async (data) => {
    if (!socket.deviceId) return;
    try {
      const rtdb = getDatabase();
      await rtdb.ref(`presence/${socket.deviceId}`).set({
        isOnline: true,
        lastSeen: Date.now(),
        userId: socket.userId,
        deviceName: data?.deviceName || 'Unknown',
      });
      socket.broadcast.emit(SOCKET_EVENTS.DEVICE_ONLINE, {
        deviceId: socket.deviceId,
        userId: socket.userId,
        deviceName: data?.deviceName,
      });
      logger.debug(`Device online: ${socket.deviceId}`);
    } catch (e) {
      logger.error('Presence online error:', e.message);
    }
  });

  // Device status update
  socket.on(SOCKET_EVENTS.DEVICE_STATUS, async (data) => {
    if (!socket.deviceId) return;
    try {
      const rtdb = getDatabase();
      await rtdb.ref(`device_status/${socket.deviceId}`).set({
        ...data,
        deviceId: socket.deviceId,
        updatedAt: Date.now(),
      });
      // Broadcast to anyone watching this device
      socket.broadcast.emit(SOCKET_EVENTS.DEVICE_STATUS, {
        deviceId: socket.deviceId,
        ...data,
      });
    } catch (e) {
      logger.error('Status update error:', e.message);
    }
  });

  // Connection request to another device
  socket.on(SOCKET_EVENTS.CONNECTION_REQUEST, (data) => {
    const { targetDeviceId, sessionType } = data;
    if (!targetDeviceId) return;
    logger.debug(`Connection request from ${socket.deviceId} to ${targetDeviceId}`);
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.CONNECTION_REQUEST, {
      fromDeviceId: socket.deviceId,
      fromUserId: socket.userId,
      sessionType,
      timestamp: Date.now(),
    });
  });

  // Connection accepted
  socket.on(SOCKET_EVENTS.CONNECTION_ACCEPTED, (data) => {
    const { targetDeviceId, sessionId } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.CONNECTION_ACCEPTED, {
      fromDeviceId: socket.deviceId,
      sessionId,
    });
  });

  // Connection rejected
  socket.on(SOCKET_EVENTS.CONNECTION_REJECTED, (data) => {
    const { targetDeviceId, reason } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.CONNECTION_REJECTED, {
      fromDeviceId: socket.deviceId,
      reason,
    });
  });
};
