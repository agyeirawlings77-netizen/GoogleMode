// backend/src/socket/socket_manager.js
'use strict';

const { Server } = require('socket.io');
const { getAuth, getDatabase } = require('../config/firebase_config');
const { SOCKET_EVENTS, ROOM_PREFIX } = require('../config/constants');
const logger = require('../utils/logger');
const signalingHandler = require('./signaling_handler');
const presenceHandler = require('./presence_handler');
const sessionHandler = require('./session_handler');
const chatHandler = require('./chat_handler');
const remoteControlHandler = require('./remote_control_handler');

let io;

function initializeSocket(server) {
  io = new Server(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST'],
    },
    transports: ['websocket', 'polling'],
    pingTimeout: 60000,
    pingInterval: 25000,
  });

  // Auth middleware for socket
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token ||
        socket.handshake.headers.authorization?.split(' ')[1];
      if (!token) return next(new Error('Authentication required'));

      const decoded = await getAuth().verifyIdToken(token);
      socket.userId = decoded.uid;
      socket.userEmail = decoded.email;
      socket.deviceId = socket.handshake.auth.deviceId || socket.handshake.headers['x-device-id'];
      next();
    } catch (error) {
      logger.warn('Socket auth failed:', error.message);
      next(new Error('Authentication failed'));
    }
  });

  io.on('connection', (socket) => {
    logger.info(`Socket connected: ${socket.id} | User: ${socket.userId} | Device: ${socket.deviceId}`);

    // Join user and device rooms
    if (socket.userId) socket.join(`${ROOM_PREFIX.USER}${socket.userId}`);
    if (socket.deviceId) socket.join(`${ROOM_PREFIX.DEVICE}${socket.deviceId}`);

    // Register all handlers
    presenceHandler(io, socket);
    signalingHandler(io, socket);
    sessionHandler(io, socket);
    chatHandler(io, socket);
    remoteControlHandler(io, socket);

    // Disconnect handler
    socket.on('disconnect', async (reason) => {
      logger.info(`Socket disconnected: ${socket.id} | Reason: ${reason}`);
      if (socket.deviceId) {
        try {
          const rtdb = getDatabase();
          await rtdb.ref(`presence/${socket.deviceId}`).update({
            isOnline: false,
            lastSeen: Date.now(),
          });
          // Notify others that device went offline
          socket.broadcast.emit(SOCKET_EVENTS.DEVICE_OFFLINE, {
            deviceId: socket.deviceId,
            userId: socket.userId,
          });
        } catch (e) {
          logger.error('Disconnect cleanup error:', e.message);
        }
      }
    });

    socket.on('error', (error) => {
      logger.error(`Socket error for ${socket.id}:`, error.message);
    });
  });

  logger.info('✅ Socket.io initialized');
  return io;
}

function getIO() {
  if (!io) throw new Error('Socket.io not initialized');
  return io;
}

function emitToDevice(deviceId, event, data) {
  if (io) io.to(`${ROOM_PREFIX.DEVICE}${deviceId}`).emit(event, data);
}

function emitToUser(userId, event, data) {
  if (io) io.to(`${ROOM_PREFIX.USER}${userId}`).emit(event, data);
}

module.exports = { initializeSocket, getIO, emitToDevice, emitToUser };
