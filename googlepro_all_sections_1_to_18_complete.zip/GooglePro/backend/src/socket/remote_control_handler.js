// backend/src/socket/remote_control_handler.js
'use strict';

const { SOCKET_EVENTS, ROOM_PREFIX } = require('../config/constants');
const logger = require('../utils/logger');

module.exports = function remoteControlHandler(io, socket) {
  // Relay touch input to target device
  socket.on(SOCKET_EVENTS.REMOTE_TOUCH, (data) => {
    const { targetDeviceId, x, y, action, pressure, size } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.REMOTE_TOUCH, {
      x, y, action, pressure, size,
      fromDeviceId: socket.deviceId,
      timestamp: Date.now(),
    });
  });

  // Relay key input to target device
  socket.on(SOCKET_EVENTS.REMOTE_KEY, (data) => {
    const { targetDeviceId, keyCode, action, metaState } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.REMOTE_KEY, {
      keyCode, action, metaState,
      fromDeviceId: socket.deviceId,
      timestamp: Date.now(),
    });
  });

  // Relay general remote input
  socket.on(SOCKET_EVENTS.REMOTE_INPUT, (data) => {
    const { targetDeviceId, inputType, inputData } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.REMOTE_INPUT, {
      inputType, inputData,
      fromDeviceId: socket.deviceId,
      timestamp: Date.now(),
    });
  });

  // Relay alarm trigger
  socket.on(SOCKET_EVENTS.TRIGGER_ALARM, (data) => {
    const { targetDeviceId, alarmType, duration, volume } = data;
    if (!targetDeviceId) return;
    logger.info(`Alarm trigger from ${socket.deviceId} to ${targetDeviceId}`);
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.TRIGGER_ALARM, {
      alarmType, duration, volume,
      fromDeviceId: socket.deviceId,
      timestamp: Date.now(),
    });
  });

  // Relay alarm stop
  socket.on(SOCKET_EVENTS.STOP_ALARM, (data) => {
    const { targetDeviceId } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.STOP_ALARM, {
      fromDeviceId: socket.deviceId,
    });
  });

  // Relay focus mode start
  socket.on(SOCKET_EVENTS.FOCUS_MODE_START, (data) => {
    const { targetDeviceId, config } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.FOCUS_MODE_START, {
      config, fromDeviceId: socket.deviceId,
    });
  });

  // Relay focus mode stop
  socket.on(SOCKET_EVENTS.FOCUS_MODE_STOP, (data) => {
    const { targetDeviceId } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.FOCUS_MODE_STOP, {
      fromDeviceId: socket.deviceId,
    });
  });
};
