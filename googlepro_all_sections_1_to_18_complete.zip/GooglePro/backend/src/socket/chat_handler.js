// backend/src/socket/chat_handler.js
'use strict';

const { SOCKET_EVENTS, ROOM_PREFIX } = require('../config/constants');
const { getFirestore } = require('../config/firebase_config');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

module.exports = function chatHandler(io, socket) {
  socket.on(SOCKET_EVENTS.CHAT_MESSAGE, async (data) => {
    const { targetDeviceId, targetUserId, message, messageType } = data;
    if (!message) return;

    const messageData = {
      messageId: uuidv4(),
      fromUserId: socket.userId,
      fromDeviceId: socket.deviceId,
      targetUserId, targetDeviceId,
      message, messageType: messageType || 'text',
      timestamp: Date.now(),
      isRead: false,
    };

    // Save to Firestore
    try {
      const db = getFirestore();
      await db.collection('chat_messages').add(messageData);
    } catch (e) {
      logger.error('Chat message save error:', e.message);
    }

    // Relay to target
    if (targetDeviceId) {
      io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.CHAT_MESSAGE, messageData);
    } else if (targetUserId) {
      io.to(`${ROOM_PREFIX.USER}${targetUserId}`).emit(SOCKET_EVENTS.CHAT_MESSAGE, messageData);
    }
  });

  socket.on(SOCKET_EVENTS.TYPING, (data) => {
    const { targetDeviceId, isTyping } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.TYPING, {
      fromDeviceId: socket.deviceId,
      fromUserId: socket.userId,
      isTyping,
    });
  });

  socket.on(SOCKET_EVENTS.CHAT_READ, (data) => {
    const { targetDeviceId, messageId } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.CHAT_READ, {
      messageId, fromDeviceId: socket.deviceId,
    });
  });
};
