// backend/src/socket/session_handler.js
'use strict';

const { SOCKET_EVENTS, ROOM_PREFIX } = require('../config/constants');
const logger = require('../utils/logger');

module.exports = function sessionHandler(io, socket) {
  socket.on(SOCKET_EVENTS.SESSION_STARTED, (data) => {
    const { targetDeviceId, sessionId, sessionType } = data;
    if (!targetDeviceId) return;
    logger.info(`Session started: ${sessionId} | type: ${sessionType}`);
    socket.join(`${ROOM_PREFIX.SESSION}${sessionId}`);
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.SESSION_STARTED, {
      sessionId, sessionType,
      fromDeviceId: socket.deviceId,
      fromUserId: socket.userId,
    });
  });

  socket.on(SOCKET_EVENTS.SESSION_ENDED, (data) => {
    const { targetDeviceId, sessionId } = data;
    logger.info(`Session ended: ${sessionId}`);
    socket.leave(`${ROOM_PREFIX.SESSION}${sessionId}`);
    if (targetDeviceId) {
      io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.SESSION_ENDED, {
        sessionId, fromDeviceId: socket.deviceId,
      });
    }
  });

  socket.on(SOCKET_EVENTS.SESSION_REQUEST, (data) => {
    const { targetDeviceId, sessionType } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.SESSION_REQUEST, {
      sessionType, fromDeviceId: socket.deviceId, fromUserId: socket.userId,
    });
  });

  socket.on(SOCKET_EVENTS.SESSION_ACCEPTED, (data) => {
    const { targetDeviceId, sessionId } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.SESSION_ACCEPTED, {
      sessionId, fromDeviceId: socket.deviceId,
    });
  });

  socket.on(SOCKET_EVENTS.SESSION_REJECTED, (data) => {
    const { targetDeviceId, reason } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.SESSION_REJECTED, {
      reason, fromDeviceId: socket.deviceId,
    });
  });
};
