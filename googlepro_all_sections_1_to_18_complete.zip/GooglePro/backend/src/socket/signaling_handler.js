// backend/src/socket/signaling_handler.js
'use strict';

const { SOCKET_EVENTS, ROOM_PREFIX } = require('../config/constants');
const { getIceServers } = require('../config/ice_servers_config');
const logger = require('../utils/logger');

module.exports = function signalingHandler(io, socket) {
  // Relay WebRTC offer to target device
  socket.on(SOCKET_EVENTS.OFFER, (data) => {
    const { targetDeviceId, sessionId, sdp } = data;
    if (!targetDeviceId || !sdp) return;
    logger.debug(`Offer from ${socket.deviceId} to ${targetDeviceId}`);
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.OFFER, {
      sdp,
      sessionId,
      fromDeviceId: socket.deviceId,
      fromUserId: socket.userId,
    });
  });

  // Relay WebRTC answer to target device
  socket.on(SOCKET_EVENTS.ANSWER, (data) => {
    const { targetDeviceId, sessionId, sdp } = data;
    if (!targetDeviceId || !sdp) return;
    logger.debug(`Answer from ${socket.deviceId} to ${targetDeviceId}`);
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.ANSWER, {
      sdp,
      sessionId,
      fromDeviceId: socket.deviceId,
      fromUserId: socket.userId,
    });
  });

  // Relay ICE candidate to target device
  socket.on(SOCKET_EVENTS.ICE_CANDIDATE, (data) => {
    const { targetDeviceId, sessionId, candidate } = data;
    if (!targetDeviceId || !candidate) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.ICE_CANDIDATE, {
      candidate,
      sessionId,
      fromDeviceId: socket.deviceId,
    });
  });

  // Signal call end
  socket.on(SOCKET_EVENTS.CALL_ENDED, (data) => {
    const { targetDeviceId, sessionId } = data;
    if (!targetDeviceId) return;
    io.to(`${ROOM_PREFIX.DEVICE}${targetDeviceId}`).emit(SOCKET_EVENTS.CALL_ENDED, {
      sessionId,
      fromDeviceId: socket.deviceId,
    });
  });

  // Get ICE servers via socket
  socket.on('get_ice_servers', (callback) => {
    if (typeof callback === 'function') {
      callback({ success: true, data: getIceServers() });
    }
  });
};
