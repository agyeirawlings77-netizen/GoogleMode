// backend/src/validators/notification_validator.js
'use strict';

const Joi = require('joi');

const sendNotificationSchema = Joi.object({
  targetUserId: Joi.string().required(),
  targetDeviceId: Joi.string().optional(),
  title: Joi.string().min(1).max(100).required(),
  body: Joi.string().min(1).max(500).required(),
  type: Joi.string()
    .valid('connection_request', 'session_started', 'session_ended',
           'file_transfer', 'alarm', 'battery_alert', 'general')
    .default('general'),
  data: Joi.object().optional(),
  imageUrl: Joi.string().uri().optional(),
});

const sendToDeviceSchema = Joi.object({
  fcmToken: Joi.string().required(),
  title: Joi.string().required(),
  body: Joi.string().required(),
  data: Joi.object().optional(),
});

function validateSendNotification(data) {
  return sendNotificationSchema.validate(data, { abortEarly: false });
}

function validateSendToDevice(data) {
  return sendToDeviceSchema.validate(data, { abortEarly: false });
}

module.exports = { validateSendNotification, validateSendToDevice };
