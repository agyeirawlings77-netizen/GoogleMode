// backend/src/validators/device_validator.js
'use strict';

const Joi = require('joi');

const registerDeviceSchema = Joi.object({
  deviceId: Joi.string().min(1).max(200).required(),
  deviceName: Joi.string().min(1).max(100).required(),
  deviceType: Joi.string().valid('android', 'ios', 'windows', 'mac', 'linux').default('android'),
  fcmToken: Joi.string().allow(null, '').optional(),
  androidVersion: Joi.string().allow('').optional(),
  manufacturer: Joi.string().allow('').optional(),
  model: Joi.string().allow('').optional(),
});

const updateDeviceSchema = Joi.object({
  deviceName: Joi.string().min(1).max(100).optional(),
  fcmToken: Joi.string().allow(null, '').optional(),
  isOnline: Joi.boolean().optional(),
}).min(1);

function validateRegisterDevice(data) {
  return registerDeviceSchema.validate(data, { abortEarly: false });
}

function validateUpdateDevice(data) {
  return updateDeviceSchema.validate(data, { abortEarly: false });
}

module.exports = { validateRegisterDevice, validateUpdateDevice };
