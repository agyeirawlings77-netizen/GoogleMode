// backend/src/validators/auth_validator.js
'use strict';

const Joi = require('joi');

const registerDeviceSchema = Joi.object({
  deviceId: Joi.string().min(1).max(200).required(),
  deviceName: Joi.string().min(1).max(100).required(),
  deviceType: Joi.string().valid('android', 'ios', 'web').default('android'),
  fcmToken: Joi.string().optional().allow(null, ''),
  manufacturer: Joi.string().optional().allow(''),
  model: Joi.string().optional().allow(''),
  osVersion: Joi.string().optional().allow(''),
});

const refreshFcmSchema = Joi.object({
  deviceId: Joi.string().required(),
  fcmToken: Joi.string().required(),
});

function validateRegisterDevice(data) {
  return registerDeviceSchema.validate(data, { abortEarly: false });
}

function validateRefreshFcm(data) {
  return refreshFcmSchema.validate(data, { abortEarly: false });
}

module.exports = { validateRegisterDevice, validateRefreshFcm };
