// backend/src/validators/session_validator.js
'use strict';

const Joi = require('joi');

const createSessionSchema = Joi.object({
  sessionType: Joi.string()
    .valid('screen_share', 'remote_control', 'voice_call', 'file_transfer')
    .required(),
  initiatorDeviceId: Joi.string().required(),
  targetDeviceId: Joi.string().required(),
  targetUserId: Joi.string().required(),
  config: Joi.object().optional(),
});

const endSessionSchema = Joi.object({
  reason: Joi.string()
    .valid('completed', 'user_ended', 'error', 'timeout', 'rejected')
    .default('user_ended'),
  durationSeconds: Joi.number().integer().min(0).optional(),
  metrics: Joi.object().optional(),
});

function validateCreateSession(data) {
  return createSessionSchema.validate(data, { abortEarly: false });
}

function validateEndSession(data) {
  return endSessionSchema.validate(data, { abortEarly: false });
}

module.exports = { validateCreateSession, validateEndSession };
