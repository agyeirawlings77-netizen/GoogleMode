// backend/src/utils/id_generator.js
'use strict';

const { v4: uuidv4 } = require('uuid');

function generateSessionId() {
  return `session_${uuidv4().replace(/-/g, '').substring(0, 16)}_${Date.now()}`;
}

function generateTransferId() {
  return `transfer_${uuidv4().replace(/-/g, '').substring(0, 12)}_${Date.now()}`;
}

function generateNotificationId() {
  return `notif_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
}

function generateRoomId(deviceId1, deviceId2) {
  const sorted = [deviceId1, deviceId2].sort();
  return `room_${sorted[0]}_${sorted[1]}`;
}

module.exports = {
  generateSessionId,
  generateTransferId,
  generateNotificationId,
  generateRoomId,
  uuid: uuidv4,
};
