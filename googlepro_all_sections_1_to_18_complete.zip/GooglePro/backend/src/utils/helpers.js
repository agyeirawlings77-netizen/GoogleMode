// backend/src/utils/helpers.js
const generateSessionId = () => `session_${Date.now()}_${Math.random().toString(36).substr(2,9)}`;
const generateRequestId = () => `req_${Date.now()}_${Math.random().toString(36).substr(2,9)}`;
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
const isExpired = (timestamp, ttlMs) => Date.now() - timestamp > ttlMs;
const sanitize = (str) => typeof str === 'string' ? str.replace(/[<>"'&]/g, '') : '';
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

module.exports = { generateSessionId, generateRequestId, sleep, isExpired, sanitize, clamp };
