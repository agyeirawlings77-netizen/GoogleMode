// backend/src/utils/validators.js
const validateDeviceId = (id) => typeof id === 'string' && id.length > 0 && id.length < 256;
const validateUserId = (id) => typeof id === 'string' && id.length > 0 && id.length < 128;
const validateSessionType = (t) => ['screenShare', 'remoteControl', 'voiceCall', 'fileTransfer'].includes(t);
const validateCommand = (c) => typeof c === 'string' && c.length > 0 && c.length < 64;

const requireFields = (fields) => (req, res, next) => {
  const missing = fields.filter(f => !req.body[f]);
  if (missing.length) return res.status(400).json({ error: `Missing required fields: ${missing.join(', ')}` });
  next();
};

module.exports = { validateDeviceId, validateUserId, validateSessionType, validateCommand, requireFields };
