// backend/src/utils/date_helper.js
'use strict';

function nowIso() {
  return new Date().toISOString();
}

function nowMs() {
  return Date.now();
}

function addSeconds(seconds) {
  return new Date(Date.now() + seconds * 1000).toISOString();
}

function addDays(days) {
  return new Date(Date.now() + days * 86400000).toISOString();
}

function diffSeconds(dateStr) {
  return Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
}

function formatDuration(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

module.exports = { nowIso, nowMs, addSeconds, addDays, diffSeconds, formatDuration };
