// backend/src/utils/response_helper.js
'use strict';

function successResponse(res, data, statusCode = 200, message = '') {
  return res.status(statusCode).json({
    success: true,
    ...(message && { message }),
    data,
  });
}

function errorResponse(res, error, statusCode = 500) {
  return res.status(statusCode).json({
    success: false,
    error: typeof error === 'string' ? error : error.message,
  });
}

function paginatedResponse(res, data, total, page, pageSize) {
  return res.status(200).json({
    success: true,
    data,
    pagination: {
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize),
      hasNext: page * pageSize < total,
      hasPrev: page > 1,
    },
  });
}

module.exports = { successResponse, errorResponse, paginatedResponse };
