// backend/src/utils/firebaseAdmin.js
const admin = require('firebase-admin');

let initialized = false;

function initialize() {
  if (initialized || admin.apps.length) { initialized = true; return; }
  try {
    const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT || '{}');
    if (!sa.project_id) { console.warn('No Firebase SA — running without auth'); return; }
    admin.initializeApp({ credential: admin.credential.cert(sa) });
    initialized = true;
    console.log(`Firebase initialized: ${sa.project_id}`);
  } catch (e) { console.error('Firebase init error:', e.message); }
}

function getDb() { return admin.apps.length ? admin.firestore() : null; }
function getRtdb() { return admin.apps.length ? admin.database() : null; }
function getAuth() { return admin.apps.length ? admin.auth() : null; }
function getMessaging() { return admin.apps.length ? admin.messaging() : null; }

module.exports = { initialize, getDb, getRtdb, getAuth, getMessaging };
