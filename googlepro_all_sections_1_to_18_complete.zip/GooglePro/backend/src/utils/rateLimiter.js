// backend/src/utils/rateLimiter.js
const requests = new Map();

const rateLimiter = (maxRequests = 100, windowMs = 60000) => (req, res, next) => {
  const key = req.uid || req.ip || 'anonymous';
  const now = Date.now();
  const windowStart = now - windowMs;

  const userRequests = (requests.get(key) || []).filter(t => t > windowStart);
  if (userRequests.length >= maxRequests) {
    return res.status(429).json({ error: 'Rate limit exceeded. Please try again later.' });
  }

  userRequests.push(now);
  requests.set(key, userRequests);
  next();
};

// Cleanup old entries every 5 minutes
setInterval(() => {
  const cutoff = Date.now() - 300000;
  requests.forEach((times, key) => {
    const fresh = times.filter(t => t > cutoff);
    if (fresh.length === 0) requests.delete(key);
    else requests.set(key, fresh);
  });
}, 300000);

module.exports = { rateLimiter };
