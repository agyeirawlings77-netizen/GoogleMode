// backend/src/services/device_service.js
'use strict';

const { getFirestore, getDatabase } = require('../config/firebase_config');
const logger = require('../utils/logger');

class DeviceService {
  async getDevicesByUser(userId) {
    const db = getFirestore();
    const snap = await db.collection('devices')
      .where('userId', '==', userId).get();
    return snap.docs.map(d => d.data());
  }

  async getDevice(deviceId) {
    const db = getFirestore();
    const doc = await db.collection('devices').doc(deviceId).get();
    return doc.exists ? doc.data() : null;
  }

  async registerDevice(deviceData) {
    const db = getFirestore();
    await db.collection('devices').doc(deviceData.deviceId).set(deviceData, { merge: true });
    return deviceData;
  }

  async updateDevice(deviceId, updates) {
    const db = getFirestore();
    await db.collection('devices').doc(deviceId).update({
      ...updates, updatedAt: new Date().toISOString(),
    });
  }

  async removeDevice(deviceId, userId) {
    const db = getFirestore();
    const device = await this.getDevice(deviceId);
    if (!device || device.userId !== userId) return false;
    await db.collection('devices').doc(deviceId).delete();
    await db.collection('users').doc(userId).update({
      [`devices.${deviceId}`]: require('firebase-admin').firestore.FieldValue.delete(),
    });
    return true;
  }

  async trustDevice(userId, deviceId) {
    const db = getFirestore();
    const trustedRef = db.collection('trusted_devices').doc(`${userId}_${deviceId}`);
    await trustedRef.set({
      userId, deviceId, trustedAt: new Date().toISOString(), isActive: true,
    });
  }

  async untrustDevice(userId, deviceId) {
    const db = getFirestore();
    await db.collection('trusted_devices').doc(`${userId}_${deviceId}`).delete();
  }

  async getTrustedDevices(userId) {
    const db = getFirestore();
    const snap = await db.collection('trusted_devices')
      .where('userId', '==', userId)
      .where('isActive', '==', true).get();
    return snap.docs.map(d => d.data());
  }

  async setPresence(deviceId, online) {
    const rtdb = getDatabase();
    await rtdb.ref(`presence/${deviceId}`).set({
      online, lastSeen: Date.now(), deviceId,
    });
  }

  async getPresence(deviceId) {
    const rtdb = getDatabase();
    const snap = await rtdb.ref(`presence/${deviceId}`).get();
    return snap.val();
  }
}

module.exports = new DeviceService();
