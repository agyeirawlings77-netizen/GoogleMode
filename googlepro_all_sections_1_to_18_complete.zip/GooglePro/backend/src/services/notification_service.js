// backend/src/services/notification_service.js
'use strict';

const { getFirestore, getMessaging } = require('../config/firebase_config');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

class NotificationService {
  async sendToUser(userId, { title, body, data = {} }) {
    try {
      const db = getFirestore();
      const snap = await db.collection('devices')
        .where('userId', '==', userId).get();
      const tokens = snap.docs
        .map(d => d.data().fcmToken)
        .filter(Boolean);
      if (tokens.length === 0) return { sent: 0 };
      const messaging = getMessaging();
      const result = await messaging.sendEachForMulticast({
        tokens, notification: { title, body }, data,
      });
      await this._saveNotification(userId, { title, body, data });
      return { sent: result.successCount, failed: result.failureCount };
    } catch (error) {
      logger.error('NotificationService.sendToUser error:', error.message);
      throw error;
    }
  }

  async sendToDevice(deviceId, { title, body, data = {} }) {
    try {
      const db = getFirestore();
      const doc = await db.collection('devices').doc(deviceId).get();
      if (!doc.exists) return { sent: 0 };
      const fcmToken = doc.data().fcmToken;
      if (!fcmToken) return { sent: 0 };
      const messaging = getMessaging();
      await messaging.send({ token: fcmToken, notification: { title, body }, data });
      return { sent: 1 };
    } catch (error) {
      logger.error('NotificationService.sendToDevice error:', error.message);
      throw error;
    }
  }

  async _saveNotification(userId, { title, body, data }) {
    try {
      const db = getFirestore();
      await db.collection('notifications').add({
        notificationId: uuidv4(),
        userId, title, body, data,
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    } catch (e) {
      logger.error('Save notification error:', e.message);
    }
  }
}

module.exports = new NotificationService();
