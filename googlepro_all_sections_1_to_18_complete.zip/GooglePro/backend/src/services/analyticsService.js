// backend/src/services/analyticsService.js
const admin = require('firebase-admin');

async function getUserStats(userId) {
  if (!admin.apps.length) return null;
  try {
    const [devSnap, sessSnap, ftSnap] = await Promise.all([
      admin.firestore().collection('devices').where('userId', '==', userId).get(),
      admin.firestore().collection('sessions').where('initiatorUserId', '==', userId).get(),
      admin.firestore().collection('file_transfers').where('initiatorUserId', '==', userId).get(),
    ]);
    const sessions = sessSnap.docs.map(d => d.data());
    const totalMinutes = sessions.reduce((s, d) => s + Math.floor((d.durationSeconds || 0) / 60), 0);
    const byType = sessions.reduce((acc, s) => { acc[s.sessionType] = (acc[s.sessionType] || 0) + 1; return acc; }, {});
    return {
      totalDevices: devSnap.size, totalSessions: sessions.length,
      totalMinutes, totalFileTransfers: ftSnap.size, sessionsByType: byType,
    };
  } catch (e) { console.error('Analytics error:', e.message); return null; }
}

async function logEvent(userId, eventName, params = {}) {
  if (!admin.apps.length) return;
  try {
    await admin.firestore().collection('analytics_events').add({
      userId, eventName, params, timestamp: admin.firestore.FieldValue.serverTimestamp(),
    });
  } catch (_) {}
}

module.exports = { getUserStats, logEvent };
