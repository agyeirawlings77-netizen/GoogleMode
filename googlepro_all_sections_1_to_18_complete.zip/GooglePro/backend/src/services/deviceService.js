// backend/src/services/deviceService.js
const admin = require('firebase-admin');

async function getDevice(deviceId) {
  if (!admin.apps.length) return null;
  const doc = await admin.firestore().collection('devices').doc(deviceId).get();
  return doc.exists ? doc.data() : null;
}

async function getUserDevices(userId) {
  if (!admin.apps.length) return [];
  const snap = await admin.firestore().collection('devices')
    .where('userId', '==', userId).orderBy('registeredAt', 'desc').get();
  return snap.docs.map(d => d.data());
}

async function updateDevicePresence(deviceId, isOnline) {
  if (!admin.apps.length) return;
  const updates = { isOnline, lastSeenAt: admin.firestore.FieldValue.serverTimestamp() };
  await admin.firestore().collection('devices').doc(deviceId).update(updates);
}

async function sendCommandToDevice(deviceId, command, payload = {}) {
  if (!admin.apps.length) return;
  await admin.database().ref(`remote_commands/${deviceId}`).set({
    action: command, payload,
    timestamp: admin.database.ServerValue.TIMESTAMP,
  });
}

async function getFcmToken(deviceId) {
  const device = await getDevice(deviceId);
  return device?.fcmToken ?? null;
}

module.exports = { getDevice, getUserDevices, updateDevicePresence, sendCommandToDevice, getFcmToken };
