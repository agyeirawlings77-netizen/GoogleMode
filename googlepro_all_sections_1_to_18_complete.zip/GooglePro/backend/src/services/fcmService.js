// backend/src/services/fcmService.js
const admin = require('firebase-admin');

async function sendNotification({ token, title, body, data = {}, priority = 'high' }) {
  if (!token || !admin.apps.length) return null;
  try {
    return await admin.messaging().send({
      token,
      notification: { title, body },
      data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])),
      android: { priority, notification: { channelId: 'googlepro_general', sound: 'default' } },
    });
  } catch (e) {
    console.error('FCM error:', e.message);
    return null;
  }
}

async function sendConnectionRequest({ targetFcmToken, callerName, callerDeviceId, requestId }) {
  return sendNotification({
    token: targetFcmToken,
    title: '📱 Connection Request',
    body: `${callerName} wants to view your screen`,
    data: { type: 'connection_request', callerDeviceId, requestId },
    priority: 'high',
  });
}

async function sendAlarmNotification({ targetFcmToken, senderName }) {
  return sendNotification({
    token: targetFcmToken,
    title: '🔔 Remote Alarm',
    body: `${senderName} triggered a remote alarm`,
    data: { type: 'remote_alarm' },
    priority: 'high',
  });
}

async function sendFileNotification({ targetFcmToken, fileName, senderName }) {
  return sendNotification({
    token: targetFcmToken,
    title: '📁 File Received',
    body: `${senderName} sent you ${fileName}`,
    data: { type: 'file_received', fileName },
  });
}

async function sendMulticastNotification({ tokens, title, body, data = {} }) {
  if (!tokens?.length || !admin.apps.length) return null;
  try {
    return await admin.messaging().sendMulticast({
      tokens, notification: { title, body },
      data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])),
      android: { priority: 'high' },
    });
  } catch (e) { console.error('Multicast error:', e.message); return null; }
}

module.exports = { sendNotification, sendConnectionRequest, sendAlarmNotification, sendFileNotification, sendMulticastNotification };
