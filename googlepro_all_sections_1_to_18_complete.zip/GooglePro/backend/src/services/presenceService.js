// backend/src/services/presenceService.js
const admin = require('firebase-admin');

async function setOnline(deviceId, userId) {
  if (!admin.apps.length) return;
  try {
    const ref = admin.database().ref(`presence/${deviceId}`);
    await ref.set({ online: true, userId, lastSeen: admin.database.ServerValue.TIMESTAMP });
    await ref.onDisconnect().update({ online: false, lastSeen: admin.database.ServerValue.TIMESTAMP });
  } catch (e) { console.error('Presence setOnline:', e.message); }
}

async function setOffline(deviceId) {
  if (!admin.apps.length) return;
  try {
    await admin.database().ref(`presence/${deviceId}`).update({ online: false, lastSeen: admin.database.ServerValue.TIMESTAMP });
  } catch (_) {}
}

async function isOnline(deviceId) {
  if (!admin.apps.length) return false;
  try {
    const snap = await admin.database().ref(`presence/${deviceId}/online`).get();
    return snap.val() === true;
  } catch (_) { return false; }
}

module.exports = { setOnline, setOffline, isOnline };
