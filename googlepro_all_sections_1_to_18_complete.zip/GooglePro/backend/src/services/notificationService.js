// backend/src/services/notificationService.js
const admin = require('firebase-admin');

async function sendPushNotification({ token, title, body, data = {}, priority = 'high' }) {
  if (!token || !admin.apps.length) return null;
  try {
    const message = {
      token,
      notification: { title, body },
      data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])),
      android: { priority: priority === 'high' ? 'high' : 'normal', notification: { channelId: 'googlepro_general' } },
    };
    const result = await admin.messaging().send(message);
    return result;
  } catch (e) {
    console.error('FCM error:', e.message);
    return null;
  }
}

async function sendMulticast({ tokens, title, body, data = {} }) {
  if (!tokens?.length || !admin.apps.length) return null;
  try {
    const message = {
      tokens,
      notification: { title, body },
      data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])),
      android: { priority: 'high' },
    };
    return await admin.messaging().sendMulticast(message);
  } catch (e) {
    console.error('FCM multicast error:', e.message);
    return null;
  }
}

async function sendConnectionRequest({ targetFcmToken, callerDeviceId, callerName, requestId }) {
  return sendPushNotification({
    token: targetFcmToken,
    title: 'Connection Request',
    body: `${callerName} wants to connect`,
    data: { type: 'connection_request', callerDeviceId, requestId },
    priority: 'high',
  });
}

module.exports = { sendPushNotification, sendMulticast, sendConnectionRequest };
