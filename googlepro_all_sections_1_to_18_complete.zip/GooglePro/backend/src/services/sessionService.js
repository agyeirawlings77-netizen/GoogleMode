// backend/src/services/sessionService.js
const admin = require('firebase-admin');

async function createSession(data) {
  if (!admin.apps.length) return data;
  await admin.firestore().collection('sessions').doc(data.sessionId).set({
    ...data, status: 'pending', createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  return data;
}

async function updateStatus(sessionId, status, extra = {}) {
  if (!admin.apps.length) return;
  await admin.firestore().collection('sessions').doc(sessionId).update({
    status, ...extra, updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });
}

module.exports = { createSession, updateStatus };
