// backend/src/services/session_service.js
'use strict';

const { getFirestore } = require('../config/firebase_config');
const { generateSessionId } = require('../utils/id_generator');
const { nowIso } = require('../utils/date_helper');

class SessionService {
  async createSession(data) {
    const db = getFirestore();
    const sessionId = generateSessionId();
    const session = {
      sessionId,
      sessionType: data.sessionType,
      initiatorDeviceId: data.initiatorDeviceId,
      initiatorUserId: data.initiatorUserId,
      targetDeviceId: data.targetDeviceId,
      targetUserId: data.targetUserId,
      status: 'pending',
      config: data.config || {},
      createdAt: nowIso(),
      startedAt: null,
      endedAt: null,
      durationSeconds: 0,
      metrics: {},
    };
    await db.collection('sessions').doc(sessionId).set(session);
    return session;
  }

  async getSession(sessionId) {
    const db = getFirestore();
    const doc = await db.collection('sessions').doc(sessionId).get();
    return doc.exists ? doc.data() : null;
  }

  async startSession(sessionId) {
    const db = getFirestore();
    await db.collection('sessions').doc(sessionId).update({
      status: 'active', startedAt: nowIso(),
    });
  }

  async endSession(sessionId, reason, metrics = {}) {
    const db = getFirestore();
    const session = await this.getSession(sessionId);
    if (!session) return null;

    const startedAt = session.startedAt ? new Date(session.startedAt) : new Date();
    const durationSeconds = Math.floor((Date.now() - startedAt.getTime()) / 1000);

    await db.collection('sessions').doc(sessionId).update({
      status: 'ended', endedAt: nowIso(),
      reason: reason || 'user_ended',
      durationSeconds, metrics,
    });

    return { ...session, status: 'ended', durationSeconds };
  }

  async getUserSessions(userId, limit = 20) {
    const db = getFirestore();
    const snap = await db.collection('sessions')
      .where('initiatorUserId', '==', userId)
      .orderBy('createdAt', 'desc').limit(limit).get();
    return snap.docs.map(d => d.data());
  }

  async getActiveSessions(userId) {
    const db = getFirestore();
    const snap = await db.collection('sessions')
      .where('initiatorUserId', '==', userId)
      .where('status', '==', 'active').get();
    return snap.docs.map(d => d.data());
  }

  async deleteSession(sessionId, userId) {
    const db = getFirestore();
    const session = await this.getSession(sessionId);
    if (!session) return false;
    if (session.initiatorUserId !== userId && session.targetUserId !== userId) return false;
    await db.collection('sessions').doc(sessionId).delete();
    return true;
  }
}

module.exports = new SessionService();
