// backend/src/services/signaling_service.js
'use strict';

const { getDatabase } = require('../config/firebase_config');
const { getIceServers } = require('../config/ice_servers_config');
const logger = require('../utils/logger');

class SignalingService {
  async sendOffer(fromDeviceId, toDeviceId, sdp, sessionId) {
    const rtdb = getDatabase();
    await rtdb.ref(`signaling/${toDeviceId}/offer`).set({
      sdp, fromDeviceId, sessionId,
      timestamp: Date.now(),
    });
    logger.info(`Offer sent from ${fromDeviceId} to ${toDeviceId}`);
  }

  async sendAnswer(fromDeviceId, toDeviceId, sdp, sessionId) {
    const rtdb = getDatabase();
    await rtdb.ref(`signaling/${toDeviceId}/answer`).set({
      sdp, fromDeviceId, sessionId,
      timestamp: Date.now(),
    });
    logger.info(`Answer sent from ${fromDeviceId} to ${toDeviceId}`);
  }

  async sendIceCandidate(fromDeviceId, toDeviceId, candidate, sessionId) {
    const rtdb = getDatabase();
    const ref = rtdb.ref(`signaling/${toDeviceId}/candidates`);
    await ref.push({
      candidate, fromDeviceId, sessionId,
      timestamp: Date.now(),
    });
  }

  async clearSignaling(deviceId) {
    const rtdb = getDatabase();
    await rtdb.ref(`signaling/${deviceId}`).remove();
  }

  getIceServersConfig() {
    return getIceServers();
  }
}

module.exports = new SignalingService();
