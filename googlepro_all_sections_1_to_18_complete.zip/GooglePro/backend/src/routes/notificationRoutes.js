// backend/src/routes/notificationRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { sendToDevice, sendToTopic } = require('../controllers/notificationController');
const { sendConnectionRequest, sendAlarmNotification, sendFileNotification } = require('../services/fcmService');

router.use(auth);

router.post('/send', sendToDevice);
router.post('/topic', sendToTopic);

router.post('/connection-request', async (req, res) => {
  const { targetFcmToken, callerName, callerDeviceId, requestId } = req.body;
  if (!targetFcmToken) return res.status(400).json({ error: 'Missing targetFcmToken' });
  try {
    await sendConnectionRequest({ targetFcmToken, callerName: callerName || 'Unknown', callerDeviceId: callerDeviceId || '', requestId: requestId || '' });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/alarm', async (req, res) => {
  const { targetFcmToken, senderName } = req.body;
  if (!targetFcmToken) return res.status(400).json({ error: 'Missing targetFcmToken' });
  try {
    await sendAlarmNotification({ targetFcmToken, senderName: senderName || 'Someone' });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/file', async (req, res) => {
  const { targetFcmToken, fileName, senderName } = req.body;
  if (!targetFcmToken) return res.status(400).json({ error: 'Missing targetFcmToken' });
  try {
    await sendFileNotification({ targetFcmToken, fileName: fileName || 'File', senderName: senderName || 'Someone' });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
