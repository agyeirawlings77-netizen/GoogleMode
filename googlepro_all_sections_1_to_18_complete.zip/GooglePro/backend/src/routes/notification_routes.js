// backend/src/routes/notification_routes.js
'use strict';

const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth_middleware');
const notificationController = require('../controllers/notification_controller');

router.use(authenticateToken);

router.post('/send', notificationController.sendNotification);
router.post('/send-to-device', notificationController.sendToDevice);
router.get('/', notificationController.getNotifications);
router.put('/:notificationId/read', notificationController.markRead);
router.delete('/:notificationId', notificationController.deleteNotification);
router.delete('/clear/all', notificationController.clearAll);

module.exports = router;
