// backend/src/routes/session_routes.js
'use strict';

const express = require('express');
const router = express.Router();
const sessionController = require('../controllers/session_controller');
const { authenticateToken } = require('../middleware/auth_middleware');

router.use(authenticateToken);

router.post('/', sessionController.createSession);
router.get('/', sessionController.getSessions);
router.get('/:sessionId', sessionController.getSession);
router.put('/:sessionId/end', sessionController.endSession);
router.delete('/:sessionId', sessionController.deleteSession);
router.get('/history/list', sessionController.getSessionHistory);
router.get('/active/list', sessionController.getActiveSessions);

module.exports = router;
