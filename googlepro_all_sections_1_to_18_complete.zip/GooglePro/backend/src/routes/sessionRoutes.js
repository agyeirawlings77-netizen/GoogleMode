// backend/src/routes/sessionRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { createSession, endSession, getActiveSessions } = require('../controllers/sessionController');
router.use(auth);
router.post('/', createSession);
router.patch('/:sessionId/end', endSession);
router.get('/active', getActiveSessions);
module.exports = router;
