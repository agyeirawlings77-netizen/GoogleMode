// backend/src/routes/file_routes.js
'use strict';

const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth_middleware');
const fileController = require('../controllers/file_controller');

router.use(authenticateToken);

router.post('/upload-url', fileController.getUploadUrl);
router.post('/transfer-request', fileController.createTransferRequest);
router.put('/transfer/:transferId/accept', fileController.acceptTransfer);
router.put('/transfer/:transferId/reject', fileController.rejectTransfer);
router.put('/transfer/:transferId/complete', fileController.completeTransfer);
router.get('/transfers', fileController.getTransferHistory);

module.exports = router;
