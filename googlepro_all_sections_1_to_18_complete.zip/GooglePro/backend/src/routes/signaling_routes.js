// backend/src/routes/signaling_routes.js
'use strict';

const express = require('express');
const router = express.Router();
const signalingController = require('../controllers/signaling_controller');
const { authenticateToken } = require('../middleware/auth_middleware');

router.use(authenticateToken);

// GET /api/v1/signaling/ice-servers - Get ICE server config
router.get('/ice-servers', signalingController.getIceServers);

// POST /api/v1/signaling/offer - Send WebRTC offer
router.post('/offer', signalingController.sendOffer);

// POST /api/v1/signaling/answer - Send WebRTC answer
router.post('/answer', signalingController.sendAnswer);

// POST /api/v1/signaling/ice-candidate - Send ICE candidate
router.post('/ice-candidate', signalingController.sendIceCandidate);

// POST /api/v1/signaling/call-end - Signal call end
router.post('/call-end', signalingController.signalCallEnd);

module.exports = router;
