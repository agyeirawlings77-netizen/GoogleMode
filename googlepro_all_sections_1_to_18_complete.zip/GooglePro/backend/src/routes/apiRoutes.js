// backend/src/routes/apiRoutes.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');
const { getDeviceStatus, sendCommand } = require('../controllers/deviceController');
const { sendSignal, broadcastToUser } = require('../controllers/signalingController');
const { sendConnectionRequest } = require('../services/notificationService');

// Health check (no auth)
router.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// All routes below require auth
router.use(authMiddleware);

// Device routes
router.get('/devices/:deviceId/status', getDeviceStatus);
router.post('/devices/:deviceId/command', sendCommand);

// Signaling routes
router.post('/signal', (req, res, next) => {
  const clients = req.app.locals.clients || new Map();
  sendSignal(clients)(req, res, next);
});

router.post('/broadcast', (req, res, next) => {
  const clients = req.app.locals.clients || new Map();
  broadcastToUser(clients)(req, res, next);
});

// Notification routes
router.post('/notify/connection', async (req, res) => {
  const { targetFcmToken, callerDeviceId, callerName, requestId } = req.body;
  if (!targetFcmToken) return res.status(400).json({ error: 'Missing targetFcmToken' });
  try {
    await sendConnectionRequest({ targetFcmToken, callerDeviceId, callerName, requestId });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Online devices
router.get('/devices/online', (req, res) => {
  const clients = req.app.locals.clients || new Map();
  res.json({ devices: Array.from(clients.keys()), count: clients.size });
});

// Session routes
router.post('/sessions', async (req, res) => {
  const { targetDeviceId, sessionType } = req.body;
  if (!targetDeviceId) return res.status(400).json({ error: 'Missing targetDeviceId' });
  const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  res.json({ sessionId, targetDeviceId, sessionType: sessionType || 'screenShare', createdAt: new Date() });
});

module.exports = router;
