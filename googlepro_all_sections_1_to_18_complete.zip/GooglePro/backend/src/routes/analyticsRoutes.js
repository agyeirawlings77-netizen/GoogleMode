// backend/src/routes/analyticsRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { getUserStats, logEvent } = require('../services/analyticsService');

router.use(auth);

router.get('/stats', async (req, res) => {
  try {
    const db = require('firebase-admin').apps.length ? require('firebase-admin').firestore() : null;
    const stats = await getUserStats(req.uid);
    res.json(stats || { totalDevices: 0, totalSessions: 0, totalMinutes: 0, totalFileTransfers: 0 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/event', async (req, res) => {
  const { eventName, params } = req.body;
  if (!eventName) return res.status(400).json({ error: 'Missing eventName' });
  try {
    const db = require('firebase-admin').apps.length ? require('firebase-admin').firestore() : null;
    await logEvent(db, req.uid, eventName, params);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
