// backend/src/routes/deviceRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { getDeviceStatus, sendCommand } = require('../controllers/deviceController');
router.use(auth);
router.get('/:deviceId/status', getDeviceStatus);
router.post('/:deviceId/command', sendCommand);
module.exports = router;
