// backend/src/routes/fileRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { getUploadUrl, notifyFileReceived } = require('../controllers/fileController');
router.use(auth);
router.post('/upload-url', getUploadUrl);
router.post('/notify', notifyFileReceived);
module.exports = router;
