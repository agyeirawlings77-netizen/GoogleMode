// backend/src/routes/status_routes.js
'use strict';

const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth_middleware');
const statusController = require('../controllers/status_controller');

router.use(authenticateToken);

router.get('/:deviceId', statusController.getDeviceStatus);
router.post('/broadcast', statusController.broadcastStatus);
router.get('/:deviceId/history', statusController.getStatusHistory);

module.exports = router;
