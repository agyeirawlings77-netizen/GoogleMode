// backend/src/routes/auth_routes.js
'use strict';

const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth_controller');
const { authenticateToken } = require('../middleware/auth_middleware');

// POST /api/v1/auth/verify - Verify Firebase token & get user profile
router.post('/verify', authenticateToken, authController.verifyToken);

// POST /api/v1/auth/register-device - Register device after login
router.post('/register-device', authenticateToken, authController.registerDevice);

// POST /api/v1/auth/logout - Logout & update presence
router.post('/logout', authenticateToken, authController.logout);

// GET /api/v1/auth/me - Get current user info
router.get('/me', authenticateToken, authController.getMe);

// POST /api/v1/auth/refresh-fcm - Update FCM token
router.post('/refresh-fcm', authenticateToken, authController.refreshFcmToken);

module.exports = router;
