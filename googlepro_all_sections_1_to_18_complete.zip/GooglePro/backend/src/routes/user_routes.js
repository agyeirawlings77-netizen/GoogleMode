// backend/src/routes/user_routes.js
'use strict';

const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth_middleware');
const userController = require('../controllers/user_controller');

router.use(authenticateToken);

router.get('/profile', userController.getProfile);
router.put('/profile', userController.updateProfile);
router.delete('/account', userController.deleteAccount);
router.get('/linked-devices', userController.getLinkedDevices);
router.delete('/linked-devices/:deviceId', userController.removeLinkedDevice);

module.exports = router;
