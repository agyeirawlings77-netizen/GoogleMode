// backend/src/routes/device_routes.js
'use strict';

const express = require('express');
const router = express.Router();
const deviceController = require('../controllers/device_controller');
const { authenticateToken } = require('../middleware/auth_middleware');

// All device routes require authentication
router.use(authenticateToken);

// GET /api/v1/devices - Get all devices for user
router.get('/', deviceController.getDevices);

// POST /api/v1/devices - Register new device
router.post('/', deviceController.registerDevice);

// GET /api/v1/devices/:deviceId - Get device by ID
router.get('/:deviceId', deviceController.getDevice);

// PUT /api/v1/devices/:deviceId - Update device
router.put('/:deviceId', deviceController.updateDevice);

// DELETE /api/v1/devices/:deviceId - Remove device
router.delete('/:deviceId', deviceController.removeDevice);

// GET /api/v1/devices/:deviceId/status - Get device status
router.get('/:deviceId/status', deviceController.getDeviceStatus);

// POST /api/v1/devices/:deviceId/trust - Mark device as trusted
router.post('/:deviceId/trust', deviceController.trustDevice);

// DELETE /api/v1/devices/:deviceId/trust - Remove trust
router.delete('/:deviceId/trust', deviceController.untrustDevice);

// GET /api/v1/devices/trusted/list - Get all trusted devices
router.get('/trusted/list', deviceController.getTrustedDevices);

module.exports = router;
