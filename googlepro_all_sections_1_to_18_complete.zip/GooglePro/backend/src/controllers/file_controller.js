// backend/src/controllers/file_controller.js
'use strict';

const { getFirestore, getStorage } = require('../config/firebase_config');
const { HTTP_STATUS } = require('../config/constants');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

async function getUploadUrl(req, res) {
  try {
    const { uid } = req.user;
    const { fileName, contentType, targetDeviceId } = req.body;
    if (!fileName || !contentType) return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'fileName and contentType required' });
    const transferId = uuidv4();
    const path = `transfers/${uid}/${transferId}/${fileName}`;
    const bucket = getStorage().bucket();
    const file = bucket.file(path);
    const [url] = await file.getSignedUrl({ action: 'write', expires: Date.now() + 15 * 60 * 1000, contentType });
    return res.status(HTTP_STATUS.OK).json({ success: true, data: { uploadUrl: url, transferId, path } });
  } catch (error) {
    logger.error('getUploadUrl error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function createTransferRequest(req, res) {
  try {
    const { uid } = req.user;
    const { targetDeviceId, fileName, fileSize, fileType, transferId } = req.body;
    const db = getFirestore();
    const transfer = { transferId: transferId || uuidv4(), fromUserId: uid, targetDeviceId, fileName, fileSize: fileSize || 0, fileType: fileType || 'unknown', status: 'pending', createdAt: new Date().toISOString() };
    await db.collection('file_transfers').doc(transfer.transferId).set(transfer);
    return res.status(HTTP_STATUS.CREATED).json({ success: true, data: transfer });
  } catch (error) {
    logger.error('createTransferRequest error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function acceptTransfer(req, res) {
  try {
    const { transferId } = req.params;
    const db = getFirestore();
    await db.collection('file_transfers').doc(transferId).update({ status: 'accepted', acceptedAt: new Date().toISOString() });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Transfer accepted' });
  } catch (error) {
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function rejectTransfer(req, res) {
  try {
    const { transferId } = req.params;
    const db = getFirestore();
    await db.collection('file_transfers').doc(transferId).update({ status: 'rejected', rejectedAt: new Date().toISOString() });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Transfer rejected' });
  } catch (error) {
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function completeTransfer(req, res) {
  try {
    const { transferId } = req.params;
    const db = getFirestore();
    await db.collection('file_transfers').doc(transferId).update({ status: 'completed', completedAt: new Date().toISOString() });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Transfer completed' });
  } catch (error) {
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getTransferHistory(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const snap = await db.collection('file_transfers').where('fromUserId', '==', uid).orderBy('createdAt', 'desc').limit(50).get();
    return res.status(HTTP_STATUS.OK).json({ success: true, data: snap.docs.map(d => d.data()) });
  } catch (error) {
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

module.exports = { getUploadUrl, createTransferRequest, acceptTransfer, rejectTransfer, completeTransfer, getTransferHistory };
