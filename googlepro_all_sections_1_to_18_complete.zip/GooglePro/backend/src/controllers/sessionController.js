// backend/src/controllers/sessionController.js
const admin = require('firebase-admin');

const createSession = async (req, res) => {
  const { targetDeviceId, targetUserId, targetDeviceName, sessionType = 'screenShare' } = req.body;
  if (!targetDeviceId || !targetUserId) return res.status(400).json({ error: 'Missing required fields' });
  try {
    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    if (admin.apps.length) {
      await admin.firestore().collection('sessions').doc(sessionId).set({
        sessionId, initiatorUserId: req.uid, targetDeviceId, targetUserId,
        targetDeviceName: targetDeviceName || 'Device',
        sessionType, status: 'pending',
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
    res.json({ sessionId, status: 'pending', createdAt: new Date().toISOString() });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

const endSession = async (req, res) => {
  const { sessionId } = req.params;
  const { durationSeconds } = req.body;
  try {
    if (admin.apps.length) {
      await admin.firestore().collection('sessions').doc(sessionId).update({
        status: 'ended', durationSeconds,
        endedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

const getActiveSessions = async (req, res) => {
  try {
    if (!admin.apps.length) return res.json({ sessions: [] });
    const snap = await admin.firestore().collection('sessions')
      .where('initiatorUserId', '==', req.uid).where('status', '==', 'active').get();
    res.json({ sessions: snap.docs.map(d => d.data()) });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

module.exports = { createSession, endSession, getActiveSessions };
