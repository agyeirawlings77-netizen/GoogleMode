// backend/src/controllers/notificationController.js
const admin = require('firebase-admin');

const sendToDevice = async (req, res) => {
  const { token, title, body, data = {} } = req.body;
  if (!token) return res.status(400).json({ error: 'Missing token' });
  try {
    if (!admin.apps.length) return res.json({ success: true, mock: true });
    const result = await admin.messaging().send({
      token,
      notification: { title, body },
      data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])),
      android: { priority: 'high' },
    });
    res.json({ success: true, messageId: result });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

const sendToTopic = async (req, res) => {
  const { topic, title, body } = req.body;
  if (!topic) return res.status(400).json({ error: 'Missing topic' });
  try {
    if (!admin.apps.length) return res.json({ success: true, mock: true });
    const result = await admin.messaging().sendToTopic(topic, { notification: { title, body } });
    res.json({ success: true, messageId: result.messageId });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

module.exports = { sendToDevice, sendToTopic };
