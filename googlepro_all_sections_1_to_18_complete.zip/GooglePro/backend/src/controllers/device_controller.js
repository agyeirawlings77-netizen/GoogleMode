// backend/src/controllers/device_controller.js
'use strict';

const { getFirestore, getDatabase } = require('../config/firebase_config');
const { HTTP_STATUS } = require('../config/constants');
const logger = require('../utils/logger');

async function getDevices(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const snap = await db.collection('devices').where('userId', '==', uid).get();
    const devices = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    return res.status(HTTP_STATUS.OK).json({ success: true, data: devices });
  } catch (error) {
    logger.error('getDevices error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function registerDevice(req, res) {
  try {
    const { uid } = req.user;
    const { deviceId, deviceName, deviceType, fcmToken, androidVersion, manufacturer, model } = req.body;
    if (!deviceId || !deviceName) {
      return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'deviceId and deviceName required' });
    }
    const db = getFirestore();
    const deviceData = {
      deviceId, deviceName, deviceType: deviceType || 'android',
      fcmToken: fcmToken || null, androidVersion: androidVersion || '',
      manufacturer: manufacturer || '', model: model || '',
      userId: uid, isOnline: true,
      registeredAt: new Date().toISOString(),
      lastSeenAt: new Date().toISOString(),
    };
    await db.collection('devices').doc(deviceId).set(deviceData, { merge: true });
    return res.status(HTTP_STATUS.CREATED).json({ success: true, data: deviceData });
  } catch (error) {
    logger.error('registerDevice error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getDevice(req, res) {
  try {
    const { deviceId } = req.params;
    const db = getFirestore();
    const doc = await db.collection('devices').doc(deviceId).get();
    if (!doc.exists) return res.status(HTTP_STATUS.NOT_FOUND).json({ success: false, error: 'Device not found' });
    return res.status(HTTP_STATUS.OK).json({ success: true, data: doc.data() });
  } catch (error) {
    logger.error('getDevice error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function updateDevice(req, res) {
  try {
    const { deviceId } = req.params;
    const db = getFirestore();
    await db.collection('devices').doc(deviceId).update({ ...req.body, updatedAt: new Date().toISOString() });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Device updated' });
  } catch (error) {
    logger.error('updateDevice error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function removeDevice(req, res) {
  try {
    const { deviceId } = req.params;
    const db = getFirestore();
    await db.collection('devices').doc(deviceId).delete();
    const rtdb = getDatabase();
    await rtdb.ref(`presence/${deviceId}`).remove();
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Device removed' });
  } catch (error) {
    logger.error('removeDevice error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getDeviceStatus(req, res) {
  try {
    const { deviceId } = req.params;
    const rtdb = getDatabase();
    const snap = await rtdb.ref(`device_status/${deviceId}`).get();
    if (!snap.exists()) return res.status(HTTP_STATUS.NOT_FOUND).json({ success: false, error: 'Status not found' });
    return res.status(HTTP_STATUS.OK).json({ success: true, data: snap.val() });
  } catch (error) {
    logger.error('getDeviceStatus error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function trustDevice(req, res) {
  try {
    const { uid } = req.user;
    const { deviceId } = req.params;
    const db = getFirestore();
    await db.collection('trusted_devices').doc(`${uid}_${deviceId}`).set({
      userId: uid, deviceId, trustedAt: new Date().toISOString(), isActive: true,
    });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Device trusted' });
  } catch (error) {
    logger.error('trustDevice error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function untrustDevice(req, res) {
  try {
    const { uid } = req.user;
    const { deviceId } = req.params;
    const db = getFirestore();
    await db.collection('trusted_devices').doc(`${uid}_${deviceId}`).delete();
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Trust removed' });
  } catch (error) {
    logger.error('untrustDevice error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getTrustedDevices(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const snap = await db.collection('trusted_devices').where('userId', '==', uid).where('isActive', '==', true).get();
    const trusted = snap.docs.map(d => d.data());
    return res.status(HTTP_STATUS.OK).json({ success: true, data: trusted });
  } catch (error) {
    logger.error('getTrustedDevices error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

module.exports = { getDevices, registerDevice, getDevice, updateDevice, removeDevice, getDeviceStatus, trustDevice, untrustDevice, getTrustedDevices };
