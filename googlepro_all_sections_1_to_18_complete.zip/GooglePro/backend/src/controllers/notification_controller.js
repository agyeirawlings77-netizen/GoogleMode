// backend/src/controllers/notification_controller.js
'use strict';

const { getFirestore, getMessaging } = require('../config/firebase_config');
const { HTTP_STATUS } = require('../config/constants');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

async function sendNotification(req, res) {
  try {
    const { uid } = req.user;
    const { targetUserId, title, body, data } = req.body;
    if (!targetUserId || !title) return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'targetUserId and title required' });
    const db = getFirestore();
    const snap = await db.collection('devices').where('userId', '==', targetUserId).get();
    const tokens = snap.docs.map(d => d.data().fcmToken).filter(Boolean);
    if (tokens.length === 0) return res.status(HTTP_STATUS.OK).json({ success: true, message: 'No FCM tokens found' });
    const messaging = getMessaging();
    await messaging.sendEachForMulticast({ tokens, notification: { title, body }, data: data || {} });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: `Notification sent to ${tokens.length} device(s)` });
  } catch (error) {
    logger.error('sendNotification error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function sendToDevice(req, res) {
  try {
    const { deviceId, title, body, data } = req.body;
    if (!deviceId || !title) return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'deviceId and title required' });
    const db = getFirestore();
    const doc = await db.collection('devices').doc(deviceId).get();
    if (!doc.exists) return res.status(HTTP_STATUS.NOT_FOUND).json({ success: false, error: 'Device not found' });
    const fcmToken = doc.data().fcmToken;
    if (!fcmToken) return res.status(HTTP_STATUS.OK).json({ success: true, message: 'No FCM token for device' });
    const messaging = getMessaging();
    await messaging.send({ token: fcmToken, notification: { title, body }, data: data || {} });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Notification sent to device' });
  } catch (error) {
    logger.error('sendToDevice error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getNotifications(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const snap = await db.collection('notifications').where('userId', '==', uid).orderBy('createdAt', 'desc').limit(50).get();
    return res.status(HTTP_STATUS.OK).json({ success: true, data: snap.docs.map(d => ({ id: d.id, ...d.data() })) });
  } catch (error) {
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function markRead(req, res) {
  try {
    const { notificationId } = req.params;
    const db = getFirestore();
    await db.collection('notifications').doc(notificationId).update({ isRead: true, readAt: new Date().toISOString() });
    return res.status(HTTP_STATUS.OK).json({ success: true });
  } catch (error) {
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function deleteNotification(req, res) {
  try {
    const { notificationId } = req.params;
    const db = getFirestore();
    await db.collection('notifications').doc(notificationId).delete();
    return res.status(HTTP_STATUS.OK).json({ success: true });
  } catch (error) {
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function clearAll(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const snap = await db.collection('notifications').where('userId', '==', uid).get();
    const batch = db.batch();
    snap.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();
    return res.status(HTTP_STATUS.OK).json({ success: true, message: `Cleared ${snap.size} notifications` });
  } catch (error) {
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

module.exports = { sendNotification, sendToDevice, getNotifications, markRead, deleteNotification, clearAll };
