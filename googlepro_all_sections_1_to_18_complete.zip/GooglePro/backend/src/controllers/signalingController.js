// backend/src/controllers/signalingController.js

const sendSignal = (connectedClients) => async (req, res) => {
  const { toDeviceId, message } = req.body;
  if (!toDeviceId || !message) {
    return res.status(400).json({ error: 'Missing toDeviceId or message' });
  }

  const target = connectedClients.get(toDeviceId);
  if (!target) {
    return res.status(404).json({ error: `Device ${toDeviceId} is not connected` });
  }

  try {
    const WebSocket = require('ws');
    if (target.readyState !== WebSocket.OPEN) {
      return res.status(503).json({ error: 'Device connection is not open' });
    }
    target.send(JSON.stringify({ ...message, fromUserId: req.uid, timestamp: Date.now() }));
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

const broadcastToUser = (connectedClients) => async (req, res) => {
  const { targetUserId, message } = req.body;
  if (!targetUserId || !message) {
    return res.status(400).json({ error: 'Missing targetUserId or message' });
  }

  const WebSocket = require('ws');
  let sent = 0;
  connectedClients.forEach((ws, deviceId) => {
    if (ws.userId === targetUserId && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ ...message, fromUserId: req.uid, timestamp: Date.now() }));
      sent++;
    }
  });

  res.json({ success: true, sent });
};

module.exports = { sendSignal, broadcastToUser };
