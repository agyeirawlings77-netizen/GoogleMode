// backend/src/controllers/deviceController.js
const admin = require('firebase-admin');
const db = admin.firestore ? admin.firestore() : null;
const rtdb = admin.database ? admin.database() : null;

const getOnlineDevices = (connectedClients) => async (req, res) => {
  try {
    const online = Array.from(connectedClients.keys());
    res.json({ devices: online, count: online.length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

const getDeviceStatus = async (req, res) => {
  const { deviceId } = req.params;
  try {
    if (!rtdb) return res.status(503).json({ error: 'Database not initialized' });
    const snap = await rtdb.ref(`device_status/${deviceId}`).get();
    if (!snap.exists()) return res.status(404).json({ error: 'Device not found' });
    res.json(snap.val());
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

const sendCommand = async (req, res) => {
  const { deviceId } = req.params;
  const { command, payload } = req.body;
  if (!command) return res.status(400).json({ error: 'Missing command' });

  try {
    if (!rtdb) return res.status(503).json({ error: 'Database not initialized' });
    await rtdb.ref(`remote_commands/${deviceId}`).set({
      command, payload: payload || {},
      timestamp: admin.database.ServerValue.TIMESTAMP,
      sentBy: req.uid,
    });
    res.json({ success: true, command, deviceId });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

module.exports = { getOnlineDevices, getDeviceStatus, sendCommand };
