// backend/src/controllers/status_controller.js
'use strict';

const { getDatabase } = require('../config/firebase_config');
const { HTTP_STATUS } = require('../config/constants');
const logger = require('../utils/logger');

async function getDeviceStatus(req, res) {
  try {
    const { deviceId } = req.params;
    const rtdb = getDatabase();
    const snap = await rtdb.ref(`device_status/${deviceId}`).get();
    if (!snap.exists()) return res.status(HTTP_STATUS.NOT_FOUND).json({ success: false, error: 'No status found' });
    return res.status(HTTP_STATUS.OK).json({ success: true, data: snap.val() });
  } catch (error) {
    logger.error('getDeviceStatus error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function broadcastStatus(req, res) {
  try {
    const deviceId = req.headers['x-device-id'];
    if (!deviceId) return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'X-Device-Id required' });
    const rtdb = getDatabase();
    await rtdb.ref(`device_status/${deviceId}`).set({ ...req.body, updatedAt: Date.now() });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Status broadcast' });
  } catch (error) {
    logger.error('broadcastStatus error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getStatusHistory(req, res) {
  return res.status(HTTP_STATUS.OK).json({ success: true, data: [] });
}

module.exports = { getDeviceStatus, broadcastStatus, getStatusHistory };
