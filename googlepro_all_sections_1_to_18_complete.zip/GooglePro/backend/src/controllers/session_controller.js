// backend/src/controllers/session_controller.js
'use strict';

const { getFirestore } = require('../config/firebase_config');
const { HTTP_STATUS } = require('../config/constants');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

async function createSession(req, res) {
  try {
    const { uid } = req.user;
    const { targetDeviceId, targetUserId, sessionType } = req.body;
    if (!targetDeviceId || !sessionType) {
      return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'targetDeviceId and sessionType required' });
    }
    const db = getFirestore();
    const sessionId = uuidv4();
    const session = {
      sessionId, sessionType,
      initiatorUserId: uid,
      targetDeviceId, targetUserId: targetUserId || '',
      status: 'pending',
      startedAt: new Date().toISOString(),
      endedAt: null,
      durationSeconds: 0,
    };
    await db.collection('sessions').doc(sessionId).set(session);
    return res.status(HTTP_STATUS.CREATED).json({ success: true, data: session });
  } catch (error) {
    logger.error('createSession error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getSessions(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const snap = await db.collection('sessions')
      .where('initiatorUserId', '==', uid)
      .orderBy('startedAt', 'desc').limit(50).get();
    const sessions = snap.docs.map(d => d.data());
    return res.status(HTTP_STATUS.OK).json({ success: true, data: sessions });
  } catch (error) {
    logger.error('getSessions error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getSession(req, res) {
  try {
    const { sessionId } = req.params;
    const db = getFirestore();
    const doc = await db.collection('sessions').doc(sessionId).get();
    if (!doc.exists) return res.status(HTTP_STATUS.NOT_FOUND).json({ success: false, error: 'Session not found' });
    return res.status(HTTP_STATUS.OK).json({ success: true, data: doc.data() });
  } catch (error) {
    logger.error('getSession error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function endSession(req, res) {
  try {
    const { sessionId } = req.params;
    const db = getFirestore();
    const doc = await db.collection('sessions').doc(sessionId).get();
    if (!doc.exists) return res.status(HTTP_STATUS.NOT_FOUND).json({ success: false, error: 'Session not found' });
    const session = doc.data();
    const endedAt = new Date().toISOString();
    const startedAt = new Date(session.startedAt);
    const durationSeconds = Math.floor((new Date() - startedAt) / 1000);
    await db.collection('sessions').doc(sessionId).update({ status: 'ended', endedAt, durationSeconds });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Session ended', durationSeconds });
  } catch (error) {
    logger.error('endSession error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function deleteSession(req, res) {
  try {
    const { sessionId } = req.params;
    const db = getFirestore();
    await db.collection('sessions').doc(sessionId).delete();
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Session deleted' });
  } catch (error) {
    logger.error('deleteSession error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getSessionHistory(req, res) {
  try {
    const { uid } = req.user;
    const { limit = 20, page = 1 } = req.query;
    const db = getFirestore();
    const snap = await db.collection('sessions')
      .where('initiatorUserId', '==', uid)
      .where('status', '==', 'ended')
      .orderBy('startedAt', 'desc')
      .limit(parseInt(limit)).get();
    const sessions = snap.docs.map(d => d.data());
    return res.status(HTTP_STATUS.OK).json({ success: true, data: sessions, page: parseInt(page) });
  } catch (error) {
    logger.error('getSessionHistory error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getActiveSessions(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const snap = await db.collection('sessions')
      .where('initiatorUserId', '==', uid)
      .where('status', '==', 'active').get();
    const sessions = snap.docs.map(d => d.data());
    return res.status(HTTP_STATUS.OK).json({ success: true, data: sessions });
  } catch (error) {
    logger.error('getActiveSessions error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

module.exports = { createSession, getSessions, getSession, endSession, deleteSession, getSessionHistory, getActiveSessions };
