// backend/src/controllers/auth_controller.js
'use strict';

const { getFirestore, getDatabase } = require('../config/firebase_config');
const { HTTP_STATUS } = require('../config/constants');
const logger = require('../utils/logger');

async function verifyToken(req, res) {
  try {
    const { uid, email, name, picture } = req.user;
    const db = getFirestore();

    // Upsert user in Firestore
    await db.collection('users').doc(uid).set({
      uid,
      email,
      displayName: name || '',
      avatarUrl: picture || null,
      lastLoginAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }, { merge: true });

    const userDoc = await db.collection('users').doc(uid).get();
    return res.status(HTTP_STATUS.OK).json({
      success: true,
      data: { uid, ...userDoc.data() },
    });
  } catch (error) {
    logger.error('verifyToken error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function registerDevice(req, res) {
  try {
    const { uid } = req.user;
    const { deviceId, deviceName, deviceType, fcmToken, androidVersion } = req.body;

    if (!deviceId || !deviceName) {
      return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'deviceId and deviceName are required' });
    }

    const db = getFirestore();
    const deviceData = {
      deviceId,
      deviceName,
      deviceType: deviceType || 'android',
      fcmToken: fcmToken || null,
      androidVersion: androidVersion || '',
      userId: uid,
      isOnline: true,
      registeredAt: new Date().toISOString(),
      lastSeenAt: new Date().toISOString(),
    };

    await db.collection('devices').doc(deviceId).set(deviceData, { merge: true });

    // Update presence in Realtime DB
    const rtdb = getDatabase();
    await rtdb.ref(`presence/${deviceId}`).set({
      isOnline: true,
      lastSeen: Date.now(),
      userId: uid,
    });

    return res.status(HTTP_STATUS.CREATED).json({ success: true, data: deviceData });
  } catch (error) {
    logger.error('registerDevice error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function logout(req, res) {
  try {
    const { uid } = req.user;
    const deviceId = req.headers['x-device-id'];
    const db = getFirestore();
    const rtdb = getDatabase();

    if (deviceId) {
      await db.collection('devices').doc(deviceId).update({
        isOnline: false,
        lastSeenAt: new Date().toISOString(),
      });
      await rtdb.ref(`presence/${deviceId}`).update({
        isOnline: false,
        lastSeen: Date.now(),
      });
    }

    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Logged out successfully' });
  } catch (error) {
    logger.error('logout error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getMe(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const doc = await db.collection('users').doc(uid).get();
    if (!doc.exists) {
      return res.status(HTTP_STATUS.NOT_FOUND).json({ success: false, error: 'User not found' });
    }
    return res.status(HTTP_STATUS.OK).json({ success: true, data: doc.data() });
  } catch (error) {
    logger.error('getMe error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function refreshFcmToken(req, res) {
  try {
    const deviceId = req.headers['x-device-id'];
    const { fcmToken } = req.body;
    if (!deviceId || !fcmToken) {
      return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'deviceId header and fcmToken required' });
    }
    const db = getFirestore();
    await db.collection('devices').doc(deviceId).update({ fcmToken, updatedAt: new Date().toISOString() });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'FCM token updated' });
  } catch (error) {
    logger.error('refreshFcmToken error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

module.exports = { verifyToken, registerDevice, logout, getMe, refreshFcmToken };
