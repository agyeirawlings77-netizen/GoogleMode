// backend/src/controllers/fileController.js
const admin = require('firebase-admin');

const getUploadUrl = async (req, res) => {
  const { fileName, contentType, targetUserId } = req.body;
  if (!fileName) return res.status(400).json({ error: 'Missing fileName' });
  try {
    const path = `file_transfers/${req.uid}/${Date.now()}_${fileName}`;
    const transferId = `ft_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    res.json({ transferId, path, message: 'Upload directly to Firebase Storage using the Flutter SDK' });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

const notifyFileReceived = async (req, res) => {
  const { transferId, targetFcmToken, fileName, fileSize } = req.body;
  if (!targetFcmToken) return res.status(400).json({ error: 'Missing targetFcmToken' });
  try {
    if (admin.apps.length) {
      await admin.messaging().send({
        token: targetFcmToken,
        notification: { title: 'File Received', body: `${fileName} (${Math.round(fileSize/1024)}KB)` },
        data: { type: 'file_transfer', transferId: transferId || '', fileName: fileName || '' },
      });
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

module.exports = { getUploadUrl, notifyFileReceived };
