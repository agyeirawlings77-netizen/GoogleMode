// backend/src/controllers/signaling_controller.js
'use strict';

const { getDatabase } = require('../config/firebase_config');
const { getIceServers } = require('../config/ice_servers_config');
const { HTTP_STATUS } = require('../config/constants');
const logger = require('../utils/logger');

async function getIceServersHandler(req, res) {
  try {
    const config = getIceServers();
    return res.status(HTTP_STATUS.OK).json({ success: true, data: config });
  } catch (error) {
    logger.error('getIceServers error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function sendOffer(req, res) {
  try {
    const { uid } = req.user;
    const { targetDeviceId, sessionId, sdp } = req.body;
    if (!targetDeviceId || !sessionId || !sdp) {
      return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'targetDeviceId, sessionId and sdp required' });
    }
    const rtdb = getDatabase();
    await rtdb.ref(`signaling/${targetDeviceId}/offer`).set({
      sdp, sessionId, fromUserId: uid,
      timestamp: Date.now(),
    });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Offer sent' });
  } catch (error) {
    logger.error('sendOffer error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function sendAnswer(req, res) {
  try {
    const { uid } = req.user;
    const { targetDeviceId, sessionId, sdp } = req.body;
    if (!targetDeviceId || !sessionId || !sdp) {
      return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'targetDeviceId, sessionId and sdp required' });
    }
    const rtdb = getDatabase();
    await rtdb.ref(`signaling/${targetDeviceId}/answer`).set({
      sdp, sessionId, fromUserId: uid,
      timestamp: Date.now(),
    });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Answer sent' });
  } catch (error) {
    logger.error('sendAnswer error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function sendIceCandidate(req, res) {
  try {
    const { targetDeviceId, sessionId, candidate } = req.body;
    if (!targetDeviceId || !sessionId || !candidate) {
      return res.status(HTTP_STATUS.BAD_REQUEST).json({ success: false, error: 'targetDeviceId, sessionId and candidate required' });
    }
    const rtdb = getDatabase();
    await rtdb.ref(`signaling/${targetDeviceId}/candidates`).push({
      candidate, sessionId, timestamp: Date.now(),
    });
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'ICE candidate sent' });
  } catch (error) {
    logger.error('sendIceCandidate error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function signalCallEnd(req, res) {
  try {
    const { targetDeviceId, sessionId } = req.body;
    const rtdb = getDatabase();
    await rtdb.ref(`signaling/${targetDeviceId}`).remove();
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Call end signaled' });
  } catch (error) {
    logger.error('signalCallEnd error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

module.exports = { getIceServers: getIceServersHandler, sendOffer, sendAnswer, sendIceCandidate, signalCallEnd };
