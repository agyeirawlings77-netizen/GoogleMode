// backend/src/controllers/user_controller.js
'use strict';

const { getFirestore, getAuth } = require('../config/firebase_config');
const { HTTP_STATUS } = require('../config/constants');
const logger = require('../utils/logger');

async function getProfile(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const doc = await db.collection('users').doc(uid).get();
    if (!doc.exists) return res.status(HTTP_STATUS.NOT_FOUND).json({ success: false, error: 'Profile not found' });
    return res.status(HTTP_STATUS.OK).json({ success: true, data: doc.data() });
  } catch (error) {
    logger.error('getProfile error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function updateProfile(req, res) {
  try {
    const { uid } = req.user;
    const { displayName, bio, phone, country, timezone } = req.body;
    const db = getFirestore();
    const updates = { updatedAt: new Date().toISOString() };
    if (displayName !== undefined) updates.displayName = displayName;
    if (bio !== undefined) updates.bio = bio;
    if (phone !== undefined) updates.phone = phone;
    if (country !== undefined) updates.country = country;
    if (timezone !== undefined) updates.timezone = timezone;
    await db.collection('users').doc(uid).update(updates);
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Profile updated' });
  } catch (error) {
    logger.error('updateProfile error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function deleteAccount(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    await db.collection('users').doc(uid).delete();
    await db.collection('devices').where('userId', '==', uid).get()
      .then(snap => Promise.all(snap.docs.map(d => d.ref.delete())));
    await getAuth().deleteUser(uid);
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Account deleted' });
  } catch (error) {
    logger.error('deleteAccount error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function getLinkedDevices(req, res) {
  try {
    const { uid } = req.user;
    const db = getFirestore();
    const snap = await db.collection('devices').where('userId', '==', uid).get();
    const devices = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    return res.status(HTTP_STATUS.OK).json({ success: true, data: devices });
  } catch (error) {
    logger.error('getLinkedDevices error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

async function removeLinkedDevice(req, res) {
  try {
    const { deviceId } = req.params;
    const db = getFirestore();
    await db.collection('devices').doc(deviceId).delete();
    return res.status(HTTP_STATUS.OK).json({ success: true, message: 'Device removed' });
  } catch (error) {
    logger.error('removeLinkedDevice error:', error);
    return res.status(HTTP_STATUS.INTERNAL_ERROR).json({ success: false, error: error.message });
  }
}

module.exports = { getProfile, updateProfile, deleteAccount, getLinkedDevices, removeLinkedDevice };
