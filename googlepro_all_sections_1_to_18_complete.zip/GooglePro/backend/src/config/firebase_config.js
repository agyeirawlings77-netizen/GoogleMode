// backend/src/config/firebase_config.js
'use strict';

const admin = require('firebase-admin');
const logger = require('../utils/logger');

let isInitialized = false;

function initializeFirebase() {
  if (isInitialized) return;

  try {
    const serviceAccount = {
      type: 'service_account',
      project_id: process.env.FIREBASE_PROJECT_ID || 'pro-c76ee',
      client_email: process.env.FIREBASE_CLIENT_EMAIL,
      private_key: (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n'),
    };

    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      databaseURL: process.env.FIREBASE_DATABASE_URL ||
        'https://pro-c76ee-default-rtdb.firebaseio.com',
      storageBucket: 'pro-c76ee.firebasestorage.app',
    });

    isInitialized = true;
    logger.info('✅ Firebase Admin initialized successfully');
  } catch (error) {
    logger.error('❌ Firebase initialization failed:', error.message);
    // In development, continue without Firebase
    if (process.env.NODE_ENV === 'production') {
      process.exit(1);
    }
  }
}

function getFirestore() {
  return admin.firestore();
}

function getDatabase() {
  return admin.database();
}

function getAuth() {
  return admin.auth();
}

function getMessaging() {
  return admin.messaging();
}

function getStorage() {
  return admin.storage();
}

module.exports = {
  initializeFirebase,
  getFirestore,
  getDatabase,
  getAuth,
  getMessaging,
  getStorage,
  admin,
};
