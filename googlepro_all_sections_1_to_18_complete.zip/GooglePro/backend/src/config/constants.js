// backend/src/config/constants.js
'use strict';

module.exports = {
  // App
  APP_NAME: 'GooglePro',
  APP_VERSION: '1.0.0',

  // Socket events
  SOCKET_EVENTS: {
    // Connection
    CONNECT: 'connect',
    DISCONNECT: 'disconnect',
    JOIN_ROOM: 'join_room',
    LEAVE_ROOM: 'leave_room',

    // Signaling
    OFFER: 'offer',
    ANSWER: 'answer',
    ICE_CANDIDATE: 'ice_candidate',
    CALL_ENDED: 'call_ended',

    // Device presence
    DEVICE_ONLINE: 'device_online',
    DEVICE_OFFLINE: 'device_offline',
    DEVICE_STATUS: 'device_status',

    // Session
    SESSION_STARTED: 'session_started',
    SESSION_ENDED: 'session_ended',
    SESSION_REQUEST: 'session_request',
    SESSION_ACCEPTED: 'session_accepted',
    SESSION_REJECTED: 'session_rejected',

    // Connection request
    CONNECTION_REQUEST: 'connection_request',
    CONNECTION_ACCEPTED: 'connection_accepted',
    CONNECTION_REJECTED: 'connection_rejected',

    // Remote control
    REMOTE_INPUT: 'remote_input',
    REMOTE_TOUCH: 'remote_touch',
    REMOTE_KEY: 'remote_key',

    // Chat
    CHAT_MESSAGE: 'chat_message',
    CHAT_READ: 'chat_read',
    TYPING: 'typing',

    // Alarm
    TRIGGER_ALARM: 'trigger_alarm',
    STOP_ALARM: 'stop_alarm',

    // Focus mode
    FOCUS_MODE_START: 'focus_mode_start',
    FOCUS_MODE_STOP: 'focus_mode_stop',

    // Error
    ERROR: 'error',
    UNAUTHORIZED: 'unauthorized',
  },

  // Room prefixes
  ROOM_PREFIX: {
    DEVICE: 'device:',
    USER: 'user:',
    SESSION: 'session:',
  },

  // Session types
  SESSION_TYPES: {
    SCREEN_SHARE: 'screen_share',
    REMOTE_CONTROL: 'remote_control',
    VOICE_CALL: 'voice_call',
    FILE_TRANSFER: 'file_transfer',
  },

  // HTTP Status codes
  HTTP_STATUS: {
    OK: 200,
    CREATED: 201,
    NO_CONTENT: 204,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    NOT_FOUND: 404,
    CONFLICT: 409,
    UNPROCESSABLE: 422,
    TOO_MANY_REQUESTS: 429,
    INTERNAL_ERROR: 500,
    SERVICE_UNAVAILABLE: 503,
  },

  // Token expiry
  TOKEN_EXPIRY: {
    ACCESS: '7d',
    REFRESH: '30d',
  },

  // Pagination
  DEFAULT_PAGE_SIZE: 20,
  MAX_PAGE_SIZE: 100,
};
