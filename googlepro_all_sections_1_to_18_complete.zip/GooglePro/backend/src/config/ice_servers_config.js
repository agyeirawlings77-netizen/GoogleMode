// backend/src/config/ice_servers_config.js
'use strict';

function getIceServers() {
  return {
    iceServers: [
      {
        urls: process.env.STUN_URL || 'stun:relay.metered.ca:80',
      },
      {
        urls: process.env.TURN_URL || 'turn:relay.metered.ca:80',
        username: process.env.TURN_USERNAME || 'adf231e2b5e252e24c33b810',
        credential: process.env.TURN_CREDENTIAL || 'W6dyxkfDTN4XQHKM',
      },
      {
        urls: 'turn:relay.metered.ca:443',
        username: process.env.TURN_USERNAME || 'adf231e2b5e252e24c33b810',
        credential: process.env.TURN_CREDENTIAL || 'W6dyxkfDTN4XQHKM',
      },
      {
        urls: 'turn:relay.metered.ca:443?transport=tcp',
        username: process.env.TURN_USERNAME || 'adf231e2b5e252e24c33b810',
        credential: process.env.TURN_CREDENTIAL || 'W6dyxkfDTN4XQHKM',
      },
    ],
    iceCandidatePoolSize: 10,
    sdpSemantics: 'unified-plan',
  };
}

module.exports = { getIceServers };
