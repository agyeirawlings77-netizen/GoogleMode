// backend/src/server.js
'use strict';

require('dotenv').config();
const http = require('http');
const app = require('./app');
const { initializeSocket } = require('./socket/socket_manager');
const { initializeFirebase } = require('./config/firebase_config');
const logger = require('./utils/logger');

const PORT = process.env.PORT || 3000;

// Initialize Firebase Admin
initializeFirebase();

// Create HTTP server
const server = http.createServer(app);

// Initialize Socket.io
initializeSocket(server);

// Start server
server.listen(PORT, () => {
  logger.info(`🚀 GooglePro Server running on port ${PORT}`);
  logger.info(`📡 WebSocket ready on port ${PORT}`);
  logger.info(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    logger.info('Server closed.');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT received. Shutting down gracefully...');
  server.close(() => {
    logger.info('Server closed.');
    process.exit(0);
  });
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  process.exit(1);
});

module.exports = server;
