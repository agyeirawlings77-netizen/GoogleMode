// backend/src/index.js
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const helmet = require('helmet');
const admin = require('firebase-admin');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });

// Middleware
app.use(helmet());
app.use(cors({ origin: '*' }));
app.use(express.json());

// Firebase Admin SDK
const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT || '{}');
if (serviceAccount.project_id) {
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
}

// WebSocket clients map: deviceId -> WebSocket
const clients = new Map();

// Auth middleware
async function verifyToken(token) {
  try {
    if (!token || !admin.apps.length) return null;
    const decoded = await admin.auth().verifyIdToken(token);
    return decoded;
  } catch (e) {
    return null;
  }
}

wss.on('connection', async (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const deviceId = url.searchParams.get('deviceId');
  const token = url.searchParams.get('token');

  if (!deviceId) { ws.close(4001, 'Missing deviceId'); return; }

  // Optional auth check
  if (token) {
    const user = await verifyToken(token);
    if (!user) { ws.close(4003, 'Unauthorized'); return; }
    ws.userId = user.uid;
  }

  ws.deviceId = deviceId;
  ws.isAlive = true;
  clients.set(deviceId, ws);
  console.log(`[WS] Connected: ${deviceId}`);

  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());
      if (msg.type === 'ping') { ws.send(JSON.stringify({ type: 'pong' })); return; }

      const targetId = msg.toDeviceId;
      if (targetId) {
        const target = clients.get(targetId);
        if (target && target.readyState === WebSocket.OPEN) {
          msg.fromDeviceId = deviceId;
          target.send(JSON.stringify(msg));
        } else {
          ws.send(JSON.stringify({ type: 'error', message: `Device ${targetId} not connected` }));
        }
      }
    } catch (e) {
      console.error('[WS] Message error:', e.message);
    }
  });

  ws.on('close', () => {
    clients.delete(deviceId);
    console.log(`[WS] Disconnected: ${deviceId}`);
  });

  ws.on('error', (e) => console.error(`[WS] Error ${deviceId}:`, e.message));

  ws.send(JSON.stringify({ type: 'connected', deviceId }));
});

// Heartbeat
const interval = setInterval(() => {
  wss.clients.forEach((ws) => {
    if (!ws.isAlive) { ws.terminate(); return; }
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);

wss.on('close', () => clearInterval(interval));

// REST endpoints
app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'ok', connectedClients: clients.size, uptime: process.uptime() });
});

app.get('/api/v1/devices/online', (req, res) => {
  const online = Array.from(clients.keys());
  res.json({ devices: online, count: online.length });
});

app.post('/api/v1/signal', async (req, res) => {
  const { toDeviceId, message } = req.body;
  if (!toDeviceId || !message) return res.status(400).json({ error: 'Missing toDeviceId or message' });

  const target = clients.get(toDeviceId);
  if (!target || target.readyState !== WebSocket.OPEN) {
    return res.status(404).json({ error: 'Device not connected' });
  }

  target.send(JSON.stringify(message));
  res.json({ success: true });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`GooglePro Signaling Server running on port ${PORT}`));

module.exports = { app, server };
