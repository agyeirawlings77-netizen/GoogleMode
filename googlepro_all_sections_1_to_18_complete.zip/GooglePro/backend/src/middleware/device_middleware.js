// backend/src/middleware/device_middleware.js
'use strict';

const { HTTP_STATUS } = require('../config/constants');

/**
 * Validates X-Device-Id header is present
 */
function requireDeviceId(req, res, next) {
  const deviceId = req.headers['x-device-id'];
  if (!deviceId) {
    return res.status(HTTP_STATUS.BAD_REQUEST).json({
      success: false,
      error: 'X-Device-Id header is required',
    });
  }
  req.deviceId = deviceId;
  next();
}

module.exports = { requireDeviceId };
