// backend/src/middleware/error_handler.js
'use strict';

const logger = require('../utils/logger');
const { HTTP_STATUS } = require('../config/constants');

function errorHandler(err, req, res, next) {
  logger.error(`Error: ${err.message}`, {
    stack: err.stack,
    path: req.path,
    method: req.method,
    ip: req.ip,
  });

  // Validation errors
  if (err.name === 'ValidationError') {
    return res.status(HTTP_STATUS.BAD_REQUEST).json({
      success: false,
      error: 'Validation failed',
      details: err.details || err.message,
    });
  }

  // JWT errors
  if (err.name === 'JsonWebTokenError') {
    return res.status(HTTP_STATUS.UNAUTHORIZED).json({
      success: false,
      error: 'Invalid token',
    });
  }

  // Firebase errors
  if (err.code && err.code.startsWith('auth/')) {
    return res.status(HTTP_STATUS.UNAUTHORIZED).json({
      success: false,
      error: err.message,
      code: err.code,
    });
  }

  // CORS error
  if (err.message === 'Not allowed by CORS') {
    return res.status(HTTP_STATUS.FORBIDDEN).json({
      success: false,
      error: 'CORS error: Origin not allowed',
    });
  }

  // Default internal server error
  const statusCode = err.statusCode || HTTP_STATUS.INTERNAL_ERROR;
  res.status(statusCode).json({
    success: false,
    error: process.env.NODE_ENV === 'production'
      ? 'Internal server error'
      : err.message,
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
  });
}

module.exports = { errorHandler };
