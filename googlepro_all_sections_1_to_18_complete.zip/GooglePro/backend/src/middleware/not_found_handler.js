// backend/src/middleware/not_found_handler.js
'use strict';

const { HTTP_STATUS } = require('../config/constants');

function notFoundHandler(req, res) {
  res.status(HTTP_STATUS.NOT_FOUND).json({
    success: false,
    error: `Route not found: ${req.method} ${req.path}`,
  });
}

module.exports = { notFoundHandler };
