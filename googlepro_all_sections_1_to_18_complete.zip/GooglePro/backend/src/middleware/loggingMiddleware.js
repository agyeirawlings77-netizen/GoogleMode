// backend/src/middleware/loggingMiddleware.js
const loggingMiddleware = (req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    const level = res.statusCode >= 500 ? 'ERROR' : res.statusCode >= 400 ? 'WARN' : 'INFO';
    console.log(`[${new Date().toISOString()}] [${level}] ${req.method} ${req.originalUrl} ${res.statusCode} ${duration}ms uid=${req.uid || 'anonymous'}`);
  });
  next();
};
module.exports = loggingMiddleware;
