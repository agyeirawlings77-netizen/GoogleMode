// backend/src/models/notificationModel.js
const admin = require('firebase-admin');

class NotificationModel {
  constructor({ userId, title, body, type = 'general', data = {} }) {
    this.userId = userId; this.title = title; this.body = body; this.type = type; this.data = data;
    this.isRead = false;
  }

  toFirestore() {
    return {
      userId: this.userId, title: this.title, body: this.body,
      type: this.type, data: this.data, isRead: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    };
  }

  static async create(db, notif) {
    if (!db) return null;
    const ref = db.collection('notifications').doc();
    const model = new NotificationModel(notif);
    await ref.set(model.toFirestore());
    return { id: ref.id, ...model.toFirestore() };
  }

  static async markRead(db, notifId) {
    if (!db) return;
    await db.collection('notifications').doc(notifId).update({ isRead: true });
  }

  static async getUserNotifications(db, userId, limit = 50) {
    if (!db) return [];
    const snap = await db.collection('notifications').where('userId', '==', userId).orderBy('createdAt', 'desc').limit(limit).get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  }
}

module.exports = NotificationModel;
