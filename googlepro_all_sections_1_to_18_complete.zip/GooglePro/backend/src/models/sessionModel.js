// backend/src/models/sessionModel.js
const admin = require('firebase-admin');

class SessionModel {
  constructor({ sessionId, initiatorDeviceId, initiatorUserId, targetDeviceId, targetUserId, targetDeviceName, sessionType = 'screenShare', status = 'pending' }) {
    this.sessionId = sessionId;
    this.initiatorDeviceId = initiatorDeviceId;
    this.initiatorUserId = initiatorUserId;
    this.targetDeviceId = targetDeviceId;
    this.targetUserId = targetUserId;
    this.targetDeviceName = targetDeviceName;
    this.sessionType = sessionType;
    this.status = status;
    this.createdAt = admin.firestore.FieldValue.serverTimestamp();
  }

  toFirestore() {
    return {
      sessionId: this.sessionId,
      initiatorDeviceId: this.initiatorDeviceId,
      initiatorUserId: this.initiatorUserId,
      targetDeviceId: this.targetDeviceId,
      targetUserId: this.targetUserId,
      targetDeviceName: this.targetDeviceName,
      sessionType: this.sessionType,
      status: this.status,
      createdAt: this.createdAt,
    };
  }

  static async create(db, data) {
    const ref = db.collection('sessions').doc();
    const model = new SessionModel({ ...data, sessionId: ref.id });
    await ref.set(model.toFirestore());
    return model;
  }

  static async updateStatus(db, sessionId, status, extra = {}) {
    await db.collection('sessions').doc(sessionId).update({
      status,
      ...extra,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }

  static async end(db, sessionId, durationSeconds) {
    await SessionModel.updateStatus(db, sessionId, 'ended', {
      endedAt: admin.firestore.FieldValue.serverTimestamp(),
      durationSeconds,
    });
  }
}

module.exports = SessionModel;
