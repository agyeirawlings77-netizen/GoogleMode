// backend/src/models/session_model.js
'use strict';

class SessionModel {
  constructor(data) {
    this.sessionId = data.sessionId;
    this.sessionType = data.sessionType;
    this.initiatorUserId = data.initiatorUserId;
    this.targetDeviceId = data.targetDeviceId;
    this.targetUserId = data.targetUserId || '';
    this.status = data.status || 'pending';
    this.startedAt = data.startedAt || new Date().toISOString();
    this.endedAt = data.endedAt || null;
    this.durationSeconds = data.durationSeconds || 0;
    this.metadata = data.metadata || {};
  }

  toMap() {
    return {
      sessionId: this.sessionId,
      sessionType: this.sessionType,
      initiatorUserId: this.initiatorUserId,
      targetDeviceId: this.targetDeviceId,
      targetUserId: this.targetUserId,
      status: this.status,
      startedAt: this.startedAt,
      endedAt: this.endedAt,
      durationSeconds: this.durationSeconds,
      metadata: this.metadata,
    };
  }

  static fromFirestore(doc) {
    return new SessionModel({ sessionId: doc.id, ...doc.data() });
  }
}

module.exports = { SessionModel };
