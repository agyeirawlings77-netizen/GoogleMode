// backend/src/models/deviceModel.js
const admin = require('firebase-admin');

class DeviceModel {
  constructor({ deviceId, userId, deviceName, deviceType = 'android', manufacturer, model, androidVersion, fcmToken, isOnline = false }) {
    this.deviceId = deviceId; this.userId = userId; this.deviceName = deviceName;
    this.deviceType = deviceType; this.manufacturer = manufacturer; this.model = model;
    this.androidVersion = androidVersion; this.fcmToken = fcmToken; this.isOnline = isOnline;
  }

  toFirestore() {
    return {
      deviceId: this.deviceId, userId: this.userId, deviceName: this.deviceName,
      deviceType: this.deviceType, manufacturer: this.manufacturer || null,
      model: this.model || null, androidVersion: this.androidVersion || null,
      fcmToken: this.fcmToken || null, isOnline: this.isOnline,
      registeredAt: admin.firestore.FieldValue.serverTimestamp(),
    };
  }

  static async findById(db, deviceId) {
    if (!db) return null;
    const doc = await db.collection('devices').doc(deviceId).get();
    return doc.exists ? doc.data() : null;
  }

  static async findByUserId(db, userId) {
    if (!db) return [];
    const snap = await db.collection('devices').where('userId', '==', userId).get();
    return snap.docs.map(d => d.data());
  }

  static async updatePresence(db, deviceId, isOnline) {
    if (!db) return;
    await db.collection('devices').doc(deviceId).update({ isOnline, lastSeenAt: admin.firestore.FieldValue.serverTimestamp() });
  }
}

module.exports = DeviceModel;
