// backend/src/models/user_model.js
'use strict';

class UserModel {
  constructor(data = {}) {
    this.uid = data.uid || '';
    this.email = data.email || '';
    this.displayName = data.displayName || '';
    this.avatarUrl = data.avatarUrl || null;
    this.bio = data.bio || '';
    this.phone = data.phone || null;
    this.emailVerified = data.emailVerified || false;
    this.twoFactorEnabled = data.twoFactorEnabled || false;
    this.country = data.country || null;
    this.timezone = data.timezone || null;
    this.createdAt = data.createdAt || new Date().toISOString();
    this.updatedAt = data.updatedAt || new Date().toISOString();
    this.devices = data.devices || {};
    this.preferences = data.preferences || {};
  }

  toMap() {
    return {
      uid: this.uid,
      email: this.email,
      displayName: this.displayName,
      avatarUrl: this.avatarUrl,
      bio: this.bio,
      phone: this.phone,
      emailVerified: this.emailVerified,
      twoFactorEnabled: this.twoFactorEnabled,
      country: this.country,
      timezone: this.timezone,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
      devices: this.devices,
      preferences: this.preferences,
    };
  }

  static fromMap(data) {
    return new UserModel(data);
  }

  get initials() {
    const parts = this.displayName.trim().split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    }
    return this.displayName.length > 0
      ? this.displayName[0].toUpperCase()
      : '?';
  }
}

module.exports = UserModel;
