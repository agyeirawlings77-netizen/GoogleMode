// backend/src/models/device_model.js
'use strict';

class DeviceModel {
  constructor(data) {
    this.deviceId = data.deviceId;
    this.deviceName = data.deviceName;
    this.deviceType = data.deviceType || 'android';
    this.userId = data.userId;
    this.fcmToken = data.fcmToken || null;
    this.androidVersion = data.androidVersion || '';
    this.manufacturer = data.manufacturer || '';
    this.model = data.model || '';
    this.isOnline = data.isOnline || false;
    this.registeredAt = data.registeredAt || new Date().toISOString();
    this.lastSeenAt = data.lastSeenAt || new Date().toISOString();
  }

  toMap() {
    return {
      deviceId: this.deviceId,
      deviceName: this.deviceName,
      deviceType: this.deviceType,
      userId: this.userId,
      fcmToken: this.fcmToken,
      androidVersion: this.androidVersion,
      manufacturer: this.manufacturer,
      model: this.model,
      isOnline: this.isOnline,
      registeredAt: this.registeredAt,
      lastSeenAt: this.lastSeenAt,
    };
  }
}

module.exports = { DeviceModel };
