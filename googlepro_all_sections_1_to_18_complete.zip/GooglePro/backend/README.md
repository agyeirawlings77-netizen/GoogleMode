# GooglePro Backend Server

WebRTC Signaling + REST API server for the GooglePro remote monitoring app.

## Stack
- **Node.js** + Express.js
- **Socket.io** for WebSocket signaling
- **Firebase Admin SDK** (Firestore, Realtime DB, FCM, Storage)
- **TURN/STUN**: relay.metered.ca

## Setup

```bash
cd backend
cp .env.example .env
# Fill in your Firebase credentials in .env
npm install
npm run dev
```

## Production Deploy (Render.com)
This server is deployed at: `https://googlepro-signaling.onrender.com`

```bash
npm start
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /health | Health check |
| POST | /api/v1/auth/verify | Verify Firebase token |
| POST | /api/v1/auth/register-device | Register device |
| POST | /api/v1/auth/logout | Logout |
| GET | /api/v1/auth/me | Get current user |
| GET | /api/v1/devices | Get all devices |
| POST | /api/v1/devices | Register device |
| GET | /api/v1/devices/:id | Get device |
| DELETE | /api/v1/devices/:id | Remove device |
| POST | /api/v1/devices/:id/trust | Trust device |
| GET | /api/v1/signaling/ice-servers | Get ICE config |
| POST | /api/v1/signaling/offer | Send SDP offer |
| POST | /api/v1/signaling/answer | Send SDP answer |
| POST | /api/v1/sessions | Create session |
| GET | /api/v1/sessions/history/list | Session history |
| POST | /api/v1/notifications/send | Send notification |

## WebSocket Events

| Event | Direction | Description |
|-------|-----------|-------------|
| offer | client→server | Send WebRTC offer |
| answer | client→server | Send WebRTC answer |
| ice_candidate | client→server | Send ICE candidate |
| session_request | client→server | Request screen share |
| session_accepted | server→client | Session accepted |
| device_online | server→client | Device came online |
| chat_message | bidirectional | Chat message |
| remote_input | client→server | Remote touch/key |
| trigger_alarm | client→server | Trigger remote alarm |

## Environment Variables
See `.env.example` for all required variables.
